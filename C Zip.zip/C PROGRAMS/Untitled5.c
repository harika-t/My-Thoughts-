#include<stdio.h>
main()
{float sum,avg,n,i;
printf("enter n value");
scanf("%f",&n);
sum=0;
i=1;
while(i<=n)
{
	sum=sum+i;
	i=i+1;
	avg=sum/n;
}
printf("avg of %f numbers is %f",n,avg);
}
