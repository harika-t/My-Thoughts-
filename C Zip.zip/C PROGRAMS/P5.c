#include<stdio.h>
main()
{ int i,n,x;
printf("Enter number n:");
scanf("%d",&n);
if(n==2)
{
	printf("The number %d is prime",n);
}
else
{
	for(i=1;i<=n;i=i+1)
{
		
	if(n%i==0)
	count+

	{
			printf("not a prime");
	}
	else
	{
		printf("prime");
	}

	}
}
}
