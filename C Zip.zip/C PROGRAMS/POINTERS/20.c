#include<stdio.h>
void main()
{
	int a[100],b[100],i,j,m,n,sum;
	printf("TIRUVEEDHULA HARIKA\nS170007\nCSE  1D\n");
	printf("Enter the number of elements:");
	scanf("%d",&m);
	printf("Enter the elements into the array:\n");

	for(i=0;i<m;i++)
	{
		scanf("%d",&a[i]);
	}
	printf("Enter position upto which cumulative sum is required:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		if(i==0)
		b[i]=a[i];
		else
		{sum=0;
		b[i]=b[i-1]+a[i];

	}
	}
	printf("The cumulative sum of array is ");
	for(i=0;i<n;i++)
	{
		printf("%d",sum);
	}
}
