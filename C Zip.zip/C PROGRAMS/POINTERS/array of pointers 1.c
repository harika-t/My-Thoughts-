#include<stdio.h>
main()
{int a=10,b=20,c=30,d=8,*p,*q,*r,*s,*ptr[4];
p=&a;
q=&b;
r=&c;
s=&d;
printf("%d",*p);
printf("%d",*q);
printf("%d",*r);
printf("%d",*s);
}
