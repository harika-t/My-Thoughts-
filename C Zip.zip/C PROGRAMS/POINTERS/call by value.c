#include<stdio.h>
main()
{int a=10,b=20,sum();
sum(a,b);
printf("a=%d,b=%d",a,b);
}
int sum(int a,int b)
{a=20;
b=10;
}
