#include<stdio.h>
main()
{int a=5,b=10,c=20,d=30,*p[4],i;
p[0]=&a;
p[1]=&b;
p[2]=&c;
p[3]=&d;
printf("Elements are:\n");
for(i=0;i<=3;i++)
{
	printf("%d\n",*p[i]);
}
}
