#include<stdio.h>
main()
{
   int num1=10,num2=20 ;
   void swap(int *,int *);
   printf("Before swap: num1 = %d,num2 = %d",num1,num2);
   swap(&num1,&num2); 
   printf("\nAfter swap: num1 = %d,num2 = %d",num1,num2);
}
void swap(int *a, int *b)  
{
   int temp;
   temp=*a;
   *a=*b;
   *b=temp ;
}
