#include<stdio.h>
main()
{int count=0;
char str[50],*ptr;
ptr=str;
printf("Enter a string:");
gets(str);
while(*ptr!='\0')
{
  count++;
  *ptr++;
}
printf("Length is %d",count);
}
