#include<stdio.h>
struct addition
{
	int a,b;
}sum;
main()
{int add(int,int);
printf("Enter value of a:");
scanf("%d",&sum.a);
printf("Enter value of b:");
scanf("%d",&sum.b);
printf("The sum of two numbers is %d",add(sum.a,sum.b));
}
int add(int a,int b)
{
	return a+b;
}
