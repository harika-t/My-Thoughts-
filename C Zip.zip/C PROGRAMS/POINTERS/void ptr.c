#include<stdio.h>
main()
{int a=5;
float b=23.16;
void *ptr;
ptr=&a;
printf("a=%d",*((int*)ptr));
ptr=&b;
printf("\nb=%f",*((float*)ptr));
}
