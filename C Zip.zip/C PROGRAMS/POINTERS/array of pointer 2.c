#include<stdio.h>
main()
{int a[]={10,15,20},*p[3],i;
for(i=0;i<=3;i++)
{
	printf("\n%d",&a[i]);
}
p=a;
printf("\nThe elements are:");
for(i=0;i<=3;i++)
{
	printf("\n%d",*p[i]);
    
}
}
