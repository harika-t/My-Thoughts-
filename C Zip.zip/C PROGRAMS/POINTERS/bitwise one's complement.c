#include<stdio.h>
main()
{int a=25;
	printf("%d",~a);
}
