#include<stdio.h>
main()
{int a[100],n,i;
void modify(int *,int);
printf("Enter number of elements:");
scanf("%d",&n);
printf("Enter elements:\n");
for(i=0;i<n;i++)
{
	scanf("%d",&a[i]);
}
printf("\nBefore modification the elements are:");
for(i=0;i<n;i++)
{
	printf("\n%d",a[i]);
}
modify(a,n);
printf("\nAfter modification the elements are:");
for(i=0;i<n;i++)
{
	printf("\n%d",a[i]);
}
}
void modify(int a[20],int n)
{
	a[1]=20;
	a[3]=40;
}

