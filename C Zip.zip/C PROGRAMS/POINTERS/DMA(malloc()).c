#include<stdio.h>
#include<stdlib.h>
main()
{int *a;
a=(int *)malloc(100);
printf("Enter a value:");
scanf("%d",a);
printf("%d",*a);
}
