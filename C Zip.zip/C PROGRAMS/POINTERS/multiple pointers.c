#include<stdio.h>
main()
{int a=5,p,q,r;
p=&a;
q=&p;
r=&q;

}
