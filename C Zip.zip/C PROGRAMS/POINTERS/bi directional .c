#include<stdio.h>
main()
{int sum(),a=20,b=40,result;
result=sum(&a,&b);
printf("The sum is %d",result);
}
int sum(int *p,int *q)
{int result;
result=*p+*q;
return result;
}
