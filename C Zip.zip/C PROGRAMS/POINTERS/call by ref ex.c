#include<stdio.h>
main()
{int *p,i=10;
void addone();
p=&i;
addone(p);
printf("%d",*p);
}
void addone(int *p)
{
    (*p)++;
}
