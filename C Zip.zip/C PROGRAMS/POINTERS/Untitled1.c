#include <stdio.h>
int main( void )
{
  int  a ;
  int *pa ;
  pa  = &a ;
  *pa = 77 ;
  printf("a=%d   *pa=%d\n", a, *pa );
  a=36;
  int* ptr;
  ptr=&a;
  printf("%u %u",*&ptr,&*ptr);
  int x=20,*y,*z;
  y=&x;
  z=y;
  *y++;
  *z++;
  x++;
  printf("x=%d,y=%d,z=%d",x,y,z);
  return 0;


}

