#include<stdio.h>
main()
{int n,i,a[20],*p;
p=&a[i];
printf("Enter number of elements:");
scanf("%d",&n);
printf("Enter elements:\n");
for(i=0;i<n;i++)
{
	scanf("%d",p+i);
}
printf("The array is:\n");
for(i=0;i<n;i++)
{
	printf("%d\n",*(p+i));
}
}
