#include<stdio.h>
main()
{int a[4]={10,20,30,40},*p[4],i;
p[0]=&a[0];
p[1]=&a[1];
p[2]=&a[2];
p[3]=&a[3];
printf("Elements are:\n");
for(i=0;i<=3;i++)
{
	printf("%d\n",*p[i]);
}
}
