#include<stdio.h>
#include<stdlib.h>
main()
{int *a;
a=(int *)malloc(sizeof(int));
printf("Enter a value:");
scanf("%d",a);
printf("%d",*a);
}
