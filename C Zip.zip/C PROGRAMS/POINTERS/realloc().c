#include<stdio.h>
#include<stdlib.h>
main()
{int *a,n,i,m;
printf("Enter n:");
scanf("%d",&n);
a=(int *)calloc(4,sizeof(int));
printf("Enter elements:\n");
for(i=0;i<n;i++)
{
	scanf("%d",a+i);
}
printf("Entered elements are:\n");
for(i=0;i<n;i++)
{
	printf("%d\n",*(a+i));
}
printf("Enter new size:");
scanf("%d",&m);
a=(int *)realloc(a,m*sizeof(int));
printf("Updated elements are:");
for(i=0;i<m;i++)
{
	printf("\n%d",*(a+i));
}
printf("\nEnter new elements:\n");
for(i=0;i<m;i++)
{
	scanf("%d",a+i);
}
printf("\nUpdated elements are:");
for(i=0;i<m;i++)
{
	printf("\n%d",*(a+i));
}
}
