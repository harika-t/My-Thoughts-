#include<stdio.h>
main()
{int a[3]={10,20,30};
int *const ptr=a;
printf("Value is %d",*ptr);
printf("\nAddress is %d",ptr);
ptr++;
printf("\nNew address is %d",ptr);
}
