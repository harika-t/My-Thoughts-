#include<stdio.h>
#include<stdlib.h>
main()
{int *a,n,i;
printf("Enter n:");
scanf("%d",&n);
a=(int *)malloc(n*sizeof(int));
printf("Enter elements:\n");
for(i=0;i<n;i++)
{
	scanf("%d",a+i);
}
printf("Entered elements are:\n");
for(i=0;i<n;i++)
{
	printf("%d\n",*(a+i));
}
}
