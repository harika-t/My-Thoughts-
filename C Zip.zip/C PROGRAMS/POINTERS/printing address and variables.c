#include<stdio.h>
main()
{int a=5;
int *b;
b=&a;
printf("%d",a);
printf("\n%d",&a);
printf("\n%d",b);
printf("\n%d",*b);
printf("\n%d",&b);
}
