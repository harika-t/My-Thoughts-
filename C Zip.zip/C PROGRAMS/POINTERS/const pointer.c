#include<stdio.h>
main()
{int a=10;
int* ptr=&a;
printf("Value of ptr is %d",*ptr);
printf("\nAddress of ptr is %p",ptr);
*ptr=11;
printf("\nNow ptr is %d",*ptr);
}
