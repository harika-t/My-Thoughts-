#include<stdio.h>
main()
{int a[100],n,i,sum(int *,int),result;
printf("Enter number of elements:");
scanf("%d",&n);
printf("Enter elements:\n");
for(i=0;i<n;i++)
{
	scanf("%d",&a[i]);
}
result=sum(a,n);
printf("The sum of the array is %d",result);
}
int sum(int a[20],int n)
{
	int i,result=0;
	for(i=0;i<n;i++)
	{
		result+=a[i];
	}
	return result;
}
