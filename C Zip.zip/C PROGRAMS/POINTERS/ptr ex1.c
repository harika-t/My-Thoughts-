#include<stdio.h>
main()
{int a,*p,**q,***r;
a=3000;
p=&a;
q=&p;
r=&q;
printf("a=%d",a);
printf("\n*p=%d",*p);
printf("\n**q=%d",**q);
printf("\n***r=%d",***r);
}
