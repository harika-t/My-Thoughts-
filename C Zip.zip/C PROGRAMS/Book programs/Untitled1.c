#include<stdio.h>
main()
{ int a[]={1,3,5,7,9};
printf("%d",sizeof(a[2]));
}
