#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *link;
};
struct node *front=NULL;
struct node *rear=NULL;
void display()
{
	struct node *temp=front;
	if(front==NULL)
	{
		printf("No nodes to display\n");
	}
	else
	{
		while(temp!=NULL)
		{
			printf("%d\n",temp->data);
			temp=temp->link;
		}
	}
}
void insert()
{
	struct node *temp;
	temp=(struct node*)malloc(sizeof(struct node));
	printf("Enter node data:");
	scanf("%d",&temp->data);
	temp->link=NULL;
	if(front==NULL&&rear==NULL)
	{
		front=temp;
		rear=temp;
	}
	else
	{
		rear->link=temp;
		rear=temp;
	}
	display();
}
void delete1()
{
	struct node*temp=front;
	if(front==NULL)
	{
		printf("No nodes to delete\n");
	}
	else
	{
		printf("Element deleted=%d\n",temp->data);
		front=front->link;
		temp->link=NULL;;
		free(temp);
	}
	display();
}
main()
{
	int ch;
	printf("1-Insert\n2-Delete\n3-Display\n4-Exit\n");
	while(1)
	{
		printf("Enter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:insert();
			break;
			case 2:delete1();
			break;
			case 3:display();
			break;
			case 4:exit(0);
			break;
			default:printf("Invalid Choice\n");
		}
	}
}
