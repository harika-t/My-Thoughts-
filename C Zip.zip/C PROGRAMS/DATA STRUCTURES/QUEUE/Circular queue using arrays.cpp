#include<stdio.h>
#include<stdlib.h>
#define MAX 5
int queue[MAX];
int front=-1,rear=-1;
void display()
{
	int i;
	if(front==-1&&rear==-1)
	{
		printf("Circular Queue is empty\n");
	}
	else
	{
		if(front<rear)
		{
			for(i=front;i<=rear;i++)
			{
				printf("%d\n",queue[i]);
			}
		}
		else
		{
			for(i=front;i<MAX;i++)
			{
				printf("%d\n",queue[i]);
			}
			for(i=0;i<=rear;i++)
			{
				printf("%d\n",queue[i]);
			}
		}
	}
}
void insert()
{
	int n;
	printf("Enter element to insert:");
	scanf("%d",&n);
	if((front==0&&rear==MAX-1)||(front==rear+1))
	{
		printf("Circular Queue is full\n");
	}
	else if(front==-1&&rear==-1)
	{
		front++;
		rear++;
		queue[rear]=n;
	}
	else if(rear==MAX-1&&front!=0)
	{
		rear=0;
		queue[rear]=n;
	}
	else
	{
		rear++;
		queue[rear]=n;
	}
	display();
	
}
void delete1()
{
	int ele;
	if(front==-1&&rear==-1)
	{
		printf("Circular Queue is empty\n");
	}
	else if(front==rear)
	{
		ele=queue[front];
		printf("Element deleted=%d\n",ele);
		front=rear=-1;
	}
	else if(front==MAX-1)
	{
		ele=queue[front];
		printf("Element deleted=%d\n",ele);
		front=0;
	}
	else
	{
		ele=queue[front];
		printf("Element deleted=%d\n",ele);
		front++;
	}
	display();
}
main()
{
	int ch;
	printf("1-Insert\n2-Delete\n3-Display\n4-Exit\n");
	while(1)
	{
		printf("Enter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:insert();
			break;
			case 2:delete1();
			break;
			case 3:display();
			break;
			case 4:exit(0);
			break;
			default:printf("Invalid choice\n");
		}
	}
}


