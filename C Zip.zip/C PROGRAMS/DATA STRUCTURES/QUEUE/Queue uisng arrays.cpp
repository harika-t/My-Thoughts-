#include<stdio.h>
#include<stdlib.h>
#define MAX 5
int queue[MAX],front=-1,rear=-1;
void display()
{
	int i;
	if(front==-1&&rear==-1)
	printf("Queue is empty\n");
	else
	{
		printf("Queue elements are:\n");
		for(i=front;i<=rear;i++)
		printf("%d\n",queue[i]);
	}
}
void insert()
{
	int x;
	printf("Enter element to insert:");
	scanf("%d",&x);
	if(rear==MAX-1)
	printf("Queue is full\n");
	else if(front==-1&&rear==-1)
	{
		front++;
		rear++;
		queue[rear]=x;
		display();
	}
	else
	{
		rear++;
		queue[rear]=x;
		display();
	}
}
void delete1()
{
	if(front==-1&&rear==-1)
	printf("Queue is empty\n");
	else if(front==rear)
	{
	  front=rear=-1;
	  display();
    }
	else
	{
	  front++;
	  display();
    }
}

main()
{
	int ch;
	printf("1.Insert\n2.Display\n3.Delete\n4.Exit\n");
	while(1)
	{
		printf("Enter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:insert();
			break;
			case 2:display();
			break;
			case 3:delete1();
			break;
			case 4:exit(0);
			break;
			default:printf("Invalid choice\n");
			}	
	}
}
