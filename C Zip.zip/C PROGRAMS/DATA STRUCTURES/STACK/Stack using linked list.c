#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *link;
};
struct node *top=NULL;
void traverse()
{
	struct node *temp;
	if(top==NULL)
	printf("Stack is empty\n");
	else
	{
		temp=top;
		printf("Elements in the stack are:\n");
		while(temp!=NULL)
		{
			printf("%d\n",temp->data);
			temp=temp->link;
		}
	}
}
void push()
{
	struct node *temp;
	temp=(struct node*)malloc(sizeof(struct node));
	printf("Enter node data:");
	scanf("%d",&temp->data);
	temp->link=top;
	top=temp;
	traverse();
}
void pop()
{
	struct node *temp;
	temp=top;
	if(temp==NULL)
	printf("No nodes to delete\n");
	else
	{
		printf("Element deleting is %d\n",temp->data);
		top=top->link;
		temp->link=NULL;
		free(temp);
	}
	traverse();
}
int length()
{
	struct node *temp=top;
	int count=0;
	while(temp!=NULL)
	{
		count++;
		temp=temp->link;
	}
	return count;
}
void peak()
{
	struct node *temp=top;
	if(temp==NULL)
	printf("No nodes to display\n");
	else
	printf("Element at the top is %d\n",temp->data);
}
main()
{
	int ch;
	printf("Stack operations are:\n1.Push\n2.Pop\n3.Peak\n4.Traverse\n5.Length\n6.Exit\n");
	while(1)
	{
		printf("Enter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:push();
			break;
			case 2:pop();
			break;
			case 3:peak();
			break;
			case 4:traverse();
			break;
			case 5:printf("Length of the stack is %d\n",length());
			break;
			case 6:exit(0);
			break;
			default:printf("Invalid choice\n");
		}
	}
}
