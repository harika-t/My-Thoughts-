#include<stdio.h>
#include<stdlib.h>
#define CAPACITY 5
int stack[CAPACITY],top=-1;
void traverse()
{
	if(isempty())
	printf("No elements are there in the stack\n");
	else
	{
		int i;
		printf("Stack elements are:\n");
		for(i=top;i>=0;i--)
		{
			printf("Stack[%d]=%d\n",i,stack[i]);
		}
	}
}
int isfull()
{
	if(top==CAPACITY-1)
	return 1;
	else
	return 0;
}
int isempty()
{
	if(top==-1)
	return 1;
	else
	return 0;
}
void push(int ele)
{
	if(isfull())
	printf("Stack is full\n");
	else
	{
		top++;
		stack[top]=ele;
	}
	traverse();
}
int pop()
{
	if(isempty())
	return 0;
	else
	return stack[top--];
}
void peak()
{
	if(isempty())
	printf("Stack is empty\n");
	else
	printf("Element at the top is %d\n",stack[top]);
}

main()
{
	int ch,ele,del;
	printf("Stack operations are:\n1.Push\n2.Pop\n3.Peak\n4.Traverse\n5.Quit\n");
	while(1)
	{
		printf("Enter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:printf("Enter a number:");
			scanf("%d",&ele);
			push(ele);
			break;
			case 2:del=pop();
			if(del==0)
			printf("Stack is empty\n");
			else
			printf("Element deleted is %d\n",del);
			break;
			case 3:peak();
			break;
			case 4:traverse();
			break;
			case 5:exit(0);
			break;
			default:printf("Invalid choice\n");
		}
	}
}
