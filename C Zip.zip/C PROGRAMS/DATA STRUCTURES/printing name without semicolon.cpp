#include<stdio.h>
main()
{
	if(printf("harika"))
	{
	}
}
