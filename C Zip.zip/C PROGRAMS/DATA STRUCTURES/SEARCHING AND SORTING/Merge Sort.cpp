#include<stdio.h>
void mergeSort(int [],int,int,int);
void partition(int [],int,int);
main()
{
	int arr[50],i,n;
	printf("Enter number of elements:");
	scanf("%d",&n);
	printf("Enter the elements:\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	}
	partition(arr,0,n-1);
	printf("After merge sort,the elements are:\n");
	for(i=0;i<n;i++)
	{
		printf("%d\t",arr[i]);
	}
}
void partition(int arr[],int low,int high)
{
	int mid;
	if(low<high)
	{
		mid=(low+high)/2;
		partition(arr,low,mid);
		partition(arr,mid+1,high);
		mergeSort(arr,low,mid,high);
	}
}
void mergeSort(int arr[],int low,int mid,int high)
{
	int i,mi,k,lo,temp[50];
	lo=low;
	i=low;
	mi=mid+1;
	while((lo<=mid)&&(mi<=high))
	{
		if(arr[lo]<=arr[mi])
		{
			temp[i]=arr[lo];
			lo++;
		}
		else
		{
			temp[i]=arr[mi];
			mi++;
		}
		i++;
	}
	if(lo>mid)
	{
		for(k=mi;k<=high;k++)
		{
			temp[i]=arr[k];
			i++;
		}
	}
	else
	{
		for(k=lo;k<=mid;k++)
		{
			temp[i]=arr[k];
			i++;
		}
	}
	for(k=low;k<=high;k++)
	{
		arr[k]=temp[k];
	}
}
