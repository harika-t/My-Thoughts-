#include<stdio.h>
main()
{
	int arr[100],key,i,n,count=0;
	printf("Enter the number of elements:");
	scanf("%d",&n);
	printf("Enter %d numbers:\n",n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	}
	printf("Enter the number to search:");
	scanf("%d",&key);
	for(i=0;i<n;i++)
	{
		if(arr[i]==key)
		{
			printf("%d is present at location %d\n",key,i+1);
			count++;
		}
	}
	if(count==0)
	{
		printf("%d is not present in array\n",key);
	}
	else
	{
		printf("%d is present %d times in array\n",key,count);
	}
}
