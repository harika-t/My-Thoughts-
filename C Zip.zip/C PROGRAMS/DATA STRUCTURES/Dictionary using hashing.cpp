#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int b;
int hsearch(int key,int d,int *ht,int *empty)
{
int i=key%(d);
int j=i;
int c=0;
do
{
if(empty[j]||(*(ht+j)==key))
return j;
c++;
j=(i+c)%(d);
}while(j!=i);
return 0;
}
int search(int key,int d,int *ht,int *empty)
{
b=hsearch(key,d,ht,empty);
if(empty[b]==1)
return -1;
else if(b==0)
return 1;
else
return b;
}
void insert(int key,int d,int *ht,int *empty)
{
b=hsearch(key,d,ht,empty);
if(empty[b])
{
empty[b]=0;
*(ht+b)=key;
printf("Element is inserted\n");
}
}

void delete1(int key,int d,int *ht,int *empty)
{
int b=hsearch(key,d,ht,empty);
*(ht+b)=0;
empty[b]=1;
printf("Element is deleted\n");
}
void display(int d,int *ht,int *empty)
{
int i;
printf("Hash table elements are:\n");
for(i=0;i<d;i++)
{
if(empty[i])
printf(" 0");
else
printf("%5d",*(ht+i));
}
printf("\n");
}
main()
{
int choice=1;
int key;
int d,i,s;
int *empty,*ht;
printf("Enter the size of hash table:");
scanf("%d",&d);
ht=(int *)malloc(d *sizeof(int));
empty=(int *)malloc(d *sizeof(int));
for(i=0;i<d;i++)
empty[i]=1;
printf("LINEAR PROBING");
printf("\n 1:Insert in hash table:");
printf("\n 2:Delete in hash table");
printf("\n 3:Search in hash table");
printf("\n 4:Display the hash table");
printf("\n 5:Exit\n");
while(1)
{
printf("Enter your choice:");
scanf("%d",&choice);
switch(choice)
{
case 1:printf("Enter the element:");
scanf("%d",&key);
insert(key,d,ht,empty);
break;
case 2:printf("Enter to remove from hash table:");
scanf("%d",&key);
delete1(key,d,ht,empty);
break;
case 3:printf("Enter the element to search:");
scanf("%d",&key);
s=search(key,d,ht,empty);
if(s==-1||s==0)
printf("Element is not found\n");
else
printf("Element is found at index %d\n",hsearch(key,d,ht,empty));
break;
case 4:display(d,ht,empty);
break;
case 5:exit(0);
}
}
}
 
