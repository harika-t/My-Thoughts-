#include<stdio.h>
#include<string.h>
main()
{
	int l,i,p;
	char a[50];
	printf("Enter the string:");
	scanf("%s",a);
	l=strlen(a);
	for(i=0;i<l;i++)
	{
		p=i+1;
		printf("%.*s\n",p,a);
	}
	for(i=l-2;i>=0;i--)
	{
		p=i+1;
		printf("%.*s\n",p,a);
	}
}
