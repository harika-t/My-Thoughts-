#include<stdio.h>
main()
{ int i;
 printf("ascii ==> character");
 for(i=-128;i<=127;i++)
printf("%d ==> %c",i,i);
}
	
	

