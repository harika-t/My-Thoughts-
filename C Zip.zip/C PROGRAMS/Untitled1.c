#include<stdio.h>
main()
{int a,b;
a=15;
b=10;
if(a==b)
{
	printf("a and b are equal");
}
else
{
	printf("a and b are not equal");
}
}
