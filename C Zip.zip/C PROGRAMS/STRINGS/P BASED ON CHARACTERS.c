#include<stdio.h>
main()
{ char name[20]="MomDad";
int i=0;
while(name[i]!='\0')
{
	printf("%c",name[i]);
	i++;
}
}
