#include<stdio.h>
#include<string.h>
main()
{ char a[50],b[50];
printf("Enter string a:");
gets(a);
printf("Enter string b:");
gets(b);
strcpy(b,a);
printf("Copied string is %s",b);
}
