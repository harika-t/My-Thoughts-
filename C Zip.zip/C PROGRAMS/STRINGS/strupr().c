#include<stdio.h>
#include<string.h>
main()
{ char a[20]={"harika"};
printf("String converted to upper case is %s",strupr(a));
}
