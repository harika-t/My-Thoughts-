#include<stdio.h>
#include<string.h>
main()
{ char name[25];
printf("Enter your name:");
gets(name);
puts("Hello!");
puts(name);
}
