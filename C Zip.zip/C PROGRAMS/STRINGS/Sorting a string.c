#include<stdio.h>
#include<string.h>
main()
{char a[50],temp,i,j,l;
printf("Enter a string:");
gets(a);
l=strlen(a);
for(i=0;i<l-1;i++)
{
	for(j=i+1;j<l;j++)
	{
		if(a[i]>a[j])
		{
			temp=a[i];
			a[i]=a[j];
			a[j]=temp;
		}
	}
}
printf("The sorted string is %s",a);
}
