#include<stdio.h>
main()
{char a[100];
puts("Enter string:");
gets(a);
puts(a);
}
