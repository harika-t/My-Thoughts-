#include<stdio.h>
#include<string.h>
main()
{ char ch1[10]={"Virat"},ch2[10]={"Kohli"};
int i,l1,l2;
l1=strlen(ch1);
l2=strlen(ch2);
for(i=0;i<l2;i++)
{
	ch1[l1+i]=ch2[i];
}printf("Combined string is %s",ch1);
}
