#include<stdio.h>
main()
{ char a[]="Virat Kohli";
int i=0;
while(a[i]!='\0')
{
	i++;
}
printf("The length of string is %d",i);
}
