#include<stdio.h>
#include<string.h>
main()
{ char a[10]={"Harika"};
 printf("a is %s\n",a);
 printf("Reversed a is %s",strrev(a));
}
