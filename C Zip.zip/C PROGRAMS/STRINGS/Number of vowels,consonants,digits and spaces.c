#include<stdio.h>
main()
{int i,vowel,consonant,digit,space;
char a[50];
vowel=consonant=digit=space=0;
printf("Enter a line of string:");
gets(a);
for(i=0;a[i]!='\0';i++)
{
	if(a[i]=='a'||a[i]=='e'||a[i]=='i'||a[i]=='o'||a[i]=='u'||a[i]=='A'||a[i]=='E'||a[i]=='I'||a[i]=='O'||a[i]=='U')
	vowel++;
	else if((a[i]>='a'&&a[i]<='z')||(a[i]>='A'&&a[i]<='Z'))
	consonant++;
	else if(a[i]>='0'&&a[i]<='9')
	digit++;
	else if(a[i]==' ')
	space++;
}
printf("Number of vowels are :%d",vowel);
printf("\nNumber of consonants are :%d",consonant);
printf("\nNumber of digits are :%d",digit);
printf("\nNumber of spaces are :%d",space);
}
