#include<stdio.h>
#include<string.h>
main()
{char a[50];
int l;
printf("Enter string:");
gets(a);
l=strlen(a);
printf("Length of the string is %d",l);
}
