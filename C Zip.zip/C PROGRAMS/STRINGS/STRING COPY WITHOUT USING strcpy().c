#include<stdio.h>
#include<string.h>
main()
{ char ch1[10],ch2[10]={"Harika"};
int i,l;
l=strlen(ch2);
for(i=0;i<l;i++)
{
	ch1[i]=ch2[i];
}printf("The copied string is %s",ch1);
}
