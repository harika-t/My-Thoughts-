#include<stdio.h>
main()
{char a[20],ch;
int i=0;
printf("Enter the string:");
ch=getchar();
while(ch!='+')
{a[i]=ch;
i++;
ch=getchar();
}
a[i]='\0';
printf("Entered string is:%s",a);
}
