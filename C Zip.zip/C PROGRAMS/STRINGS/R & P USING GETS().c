#include<stdio.h>
#include<string.h>
main()
{ char name[50];
printf("Enter your name:");
gets(name);
printf("Hello! %s",name);
}
