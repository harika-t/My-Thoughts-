#include<stdio.h>
#include<string.h>
main()
{ char a[]="Virat Kohli";
printf("Length of a is:%d",strlen(a));
}
