#include<stdio.h>
#define PI 3.14
#define NUMBER 10
main()
{ double aof,poc;
int i,r;
printf("Enter radius of the circle:");
scanf("%d",&r);
aof=PI*r*r;
poc=2*PI*r;
printf("Area of circle is %lf",aof);
printf("\nPerimeter of circle is %lf",poc);
for(i=1;i<NUMBER;i++)
{
	printf("\n%d",i);
}
}
