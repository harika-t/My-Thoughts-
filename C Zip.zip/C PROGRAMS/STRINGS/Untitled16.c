#include<stdio.h>
#include<string.h>
main()
{char s1[100],s2[100];
int i;
printf("Enter first string");
gets(s1);
printf("Enter second string");
gets(s2);
for(i=0;s1[i]!='\0';i++)
{
	if(s1[i]==s2[i])
	{
		printf("Both Strings are equal");
		printf("\nASCII value diff is %d",s1[i]-s2[i]);
		break;
	}
	else if(s1[i]<s2[i])
	{
		printf("First string is smaller");
		printf("\nASCII value diff is %d",s1[i]-s2[i]);
		break;
	}
	else
	{
		printf("First string is larger");
		printf("\nASCII value diff is %d",s1[i]-s2[i]);
		break;
	}
}
}
