#include<stdio.h>
#include<string.h>
main()
{ char a[20]={""};
char b[20]={" "};
int i;
i=strcmp(a,b);
printf("%d",i);
}
