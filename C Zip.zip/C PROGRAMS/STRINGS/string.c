#include<stdio.h>
main()
{char data[100];
printf("Enter a string:");
gets(data);
printf("Entered data is:");
puts(data);
}
