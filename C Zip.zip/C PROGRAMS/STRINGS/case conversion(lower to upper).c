#include<stdio.h>
main()
{ char a[50],b[50];
int i;
printf("Enter string a:");
gets(a);
for(i=0;a[i]!='\0';i++)
{
   a[i]=a[i]+32;
   printf("%c",a[i]);
}
printf("\nEnter string b:");
gets(b);
for(i=0;b[i]!='\0';i++)
{
   b[i]=b[i]-32;
   printf("%c",b[i]);
}
}
