#include<stdio.h>
#include<math.h>
main()
{
int a,b,c;
printf("Enter two numbers:");
scanf("%d%d",&a,&b);
c=pow(a,b);
printf("%d",c);
}
