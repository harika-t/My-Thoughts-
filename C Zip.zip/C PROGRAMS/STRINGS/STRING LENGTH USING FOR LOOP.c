#include<stdio.h>
main()
{ char a[20]="Virat Kohli";
int i;
for(i=0;a[i]!='\0';i++);
printf("Length of a is %d",i);
}
