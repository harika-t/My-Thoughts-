#include<stdio.h>
#include<string.h>
main()
{ char a[40]={"Mom"};
char b[20]={"Dad"};
strcat(a,b);
printf("b is %s\n",b);
printf("a is %s",a);
}
