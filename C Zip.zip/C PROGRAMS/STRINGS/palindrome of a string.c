#include<stdio.h>
#include<string.h>
main()
{ char a[20],temp,a1[20];
int i,j,k;
printf("Enter string:");
gets(a);
i=0;
j=strlen(a)-1;
strcpy(a1,a);
while(i<j)
{
    temp=a[i];
    a[i]=a[j];
    a[j]=temp;
    i++;
    j--;
} 
printf("The given string is %s\n",a1);
k=strcmp(a1,a);
if(k==0)
printf("%s is a palindrome",a1);
else
printf("%s is not a palindrome",a1);
}
