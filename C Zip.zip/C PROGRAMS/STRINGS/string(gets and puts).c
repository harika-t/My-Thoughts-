#include<stdio.h>
main()
{char d[100];
printf("Enter a string:");
gets(d);
printf("Entered data is:");
puts(d);
}
