#include<stdio.h>
main
