#include<stdio.h>
main()
{int n,i,count=0;
printf("Enter number:");
scanf("%d",&n);
for(i=1;i<=n;i++)
{
	if(n%i==0)
	{
		count++;
	}
}
if(count==2)
{
	printf("The number %d is prime",n);
}
else
{
	printf("The number %d is not prime",n);
}
}
