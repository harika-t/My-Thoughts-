#include<stdio.h>
main()

{
printf("%c",s);
}
