#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    char a[200],temp,a1[200];
int i,j,k,t,n1,h;
    scanf("%d",&t);
    for( h=1;h<=t;h++)
    {scanf("%d",&n1);
scanf("%s",a);

i=0;
j=strlen(a)-1;
strcpy(a1,a);
while(i<j)
{
    temp=a[i];
    a[i]=a[j];
    a[j]=temp;
    i++;
    j--;
} 
k=strcmp(a1,a);
if(k!=0)
printf("No\n");
else
printf("Yes\n");
    }
    return 0;
}

