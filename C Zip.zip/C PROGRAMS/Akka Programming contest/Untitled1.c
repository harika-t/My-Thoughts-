#include<stdio.h>
main()
{
int t;
scanf("%d",&t);
int n,ar[150],i,j,c=0;
	
while(t--)
{
	scanf("%d",&n);
	
	for( i=1;i<=n;i++)
	{
		scanf("%d",&ar[i]);
	}
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			if(ar[i]!=ar[j])
			{
				if(a[i]==a[j+1])
				printf("%d",j);
				break;
				else
				printf("%d",i);
				break;
			}
			
		}
	}
}
}
