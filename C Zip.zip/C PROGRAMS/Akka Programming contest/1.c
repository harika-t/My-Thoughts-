#include<stdio.h>
main()
{
int  n;
	scanf("%d",&n);
	if(n<0)
	printf("Incorrect input");
	else
	{
	if((n*n)%10==n)
	printf("Correct");
	else
	printf("Incorrect");
    }
}
