#include<stdio.h>
main()
{ int i,count,j,upper,lower;
printf("Enter lower and upper limits:");
scanf("%d%d",&lower,&upper);
for(i=lower;i<=upper;i++)
{ count=0;
 for(j=1;j<=i;j++)
 {
 	if(i%j==0)
 	count++;
 }
 if(count==2)
 {
 printf("%d\n",i);
 }
}
}
