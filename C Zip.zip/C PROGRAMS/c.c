#include <stdio.h>
int main(int argc,char *argv[])
{
    printf("Total arguments=%d",argc);
    printf("first argument=%s",argv[0]);
    return 0;
}
