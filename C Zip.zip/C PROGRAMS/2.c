#include<stdio.h>
struct node
{
	char x,y,z;
};
main()
{
	struct node p={'1','0','a'+2};
	struct node *q=&p;
	printf("%c%c",*((char *)q+1),*((char *)q+2));
}
