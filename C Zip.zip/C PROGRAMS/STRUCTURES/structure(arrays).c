#include<stdio.h>
struct student
{
	char sname[30];
	int sid;
	float smarks;
};
struct student s;
main()
{
	struct student s[100]={{"Ramakrishna",200,150.5},{"Naresh",220,250.5}};
	int i;
	for(i=0;i<2;i++)
	{
		printf("\nStudents %d details are:",i+1);
		printf("\nStudent's name is %s",s[i].sname);
		printf("\nStudent's ID is %d",s[i].sid);
		printf("\nStudent's  marks are %f",s[i].smarks);
	}
}
