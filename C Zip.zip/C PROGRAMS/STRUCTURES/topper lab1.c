#include<stdio.h>
struct student
{
	int regid;
	char name[30];
	float cgpa;
	struct address
	{
		char village[30];
		char dist[30];
		long int phno;
	}add;
};
main()
{
	struct student s[20];
	int n,i;
	printf("Enter number of students:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("Enter regid:");
		scanf("%d",&s[i].regid);
		printf("Enter name:");
		scanf("%s",s[i].name);
		printf("Enter cgpa:");
		scanf("%f",&s[i].cgpa);
		printf("Enter address:Village,district and phone number:");
		scanf("%s%s%ld",s[i].add.village,s[i].add.dist,&s[i].add.phno);
	}
	
	printf("\nStudent details are:\n");
	printf("Regid\tName\tCGPA\tAddress\n");
	for(i=0;i<n;i++)
	{
		printf("%d\t",s[i].regid);
		printf("%s\t",s[i].name);
		printf("%f\t",s[i].cgpa);
		printf("%s,%s,%ld",s[i].add.village,s[i].add.dist,s[i].add.phno);
		printf("\n");
	}
	int t,topper=s[0].cgpa;
	for(i=1;i<n;i++)
	{
		if(s[i].cgpa>topper)
		{
			topper=s[i].cgpa;
			t=i;
		}
	}
	printf("\nTopper student details are:\n");
	printf("Regid\tName\tCGPA\tAddress\n");
	printf("%d\t",s[t].regid);
	printf("%s\t",s[t].name);
	printf("%f\t",s[t].cgpa);
	printf("%s,%s,%ld",s[t].add.village,s[t].add.dist,s[t].add.phno);
} 
