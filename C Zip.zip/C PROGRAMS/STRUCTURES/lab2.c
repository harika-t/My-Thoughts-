#include<stdio.h>
struct student
{
	int regid;
	char name[20];
	float cgpa;
	struct address
	{
		char village[20];
		char dist[20];
		long int phno;
	}add;
	};
int main()
{
	struct student s[10];
	int n,i,flag=0,j;
	printf("Enter no. of students:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("Enter regid:");
		scanf("%d",&s[i].regid);
		printf("Enter name:");
		scanf("%s",s[i].name);
		printf("Enter cgpa:");
		scanf("%f",&s[i].cgpa);
		printf("Enter address--village,dist and phono:\n");
		scanf("%s%s%ld",s[i].add.village,s[i].add.dist,&s[i].add.phno);
	}
	
	printf("\nstudent details are:\n");
	printf("Regid\tName\tCGPA\t\tAddress\n");
	for(i=0;i<n;i++)
	{
	printf("%d\t",s[i].regid);
	printf("%s\t",s[i].name);
	printf("%f\t",s[i].cgpa);
	printf("%s,%s,%ld\n",s[i].add.village,s[i].add.dist,s[i].add.phno);
	}
	struct student t;
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
           {	
            if(s[j].regid>s[j+1].regid)
	        {
		      t=s[j];
		      s[j]=s[j+1];
		      s[j+1]=t;
	        }
          }
    }
	
		printf("\nAfter sorting student details are:\n");
	printf("Regid\tName\tCGPA\t\tAddress\n");
	for(i=0;i<n;i++)
	{
	printf("%d\t",s[i].regid);
	printf("%s\t",s[i].name);
	printf("%f\t",s[i].cgpa);
	printf("%s,%s,%ld\n",s[i].add.village,s[i].add.dist,s[i].add.phno);
	}
	
	
}
	

