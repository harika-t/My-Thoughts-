#include<stdio.h>
void main(int argc,char *argv[])
{
   printf("Total arguments:%d",argc);
   printf("\nFirst argument:%s",argv[0]);
   printf("\nSecond argument:%s",argv[1]);
   printf("\nThird argument:%s",argv[2]);
}
