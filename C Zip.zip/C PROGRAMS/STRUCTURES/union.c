#include<stdio.h>
union car
{
	char name[50];
	float price;
};
main()
{
	union car car1={"Benz",100000};
	printf("%s\n",car1.name);
	printf("%f",car1.price);
}
