#include<stdio.h>
struct student
{
	char sname[30];
	int sid;
	int sage;
};
struct student s;
main()
{
	struct student s[100]={{"Ramakrishna",200,150.5},{"Naresh",220,250.5}};
	int i;
	printf("Students details are:");
	for(i=0;i<2;i++)
	{
		printf("\nStudent's name is %s",s[i].sname);
		printf("\nStudent's ID is %d",s[i].sid);
		printf("\nStudent's  age is %d",s[i].sage);
	}
}
