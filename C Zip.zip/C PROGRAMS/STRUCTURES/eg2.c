#include<stdio.h>
struct student
{
	char *sname;
	int sid;
	int sage;
};
main()
{
	struct student s;
	s.sname="Harika";
	s.sid=170007;
	s.sage=18;
	printf("Student's name is %s",s.sname);
	printf("\nStudent's ID is %d",s.sid);
	printf("\nStudent's age is %d",s.sage);
}
