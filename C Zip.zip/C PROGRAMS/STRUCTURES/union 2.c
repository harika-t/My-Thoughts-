#include<stdio.h>
#include<string.h>
union employee
{
	int eid;
	float esal;
	char ename[20];
};
main()
{
	union employee e;


	strcpy(e.ename,"Rama");
	printf("e.ename:%s",e.ename);
	e.esal=50000;
	printf("e.esal:%f",e.esal);
	e.eid=7;	
	printf("e.eid:%d",e.eid);
}
