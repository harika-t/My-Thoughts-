#include<stdio.h>
union union_lob
{
	char name[32];
	float salary;
	int workers;
}u_lob;
struct struct_lob
{
	char name[50];
	float salary;
	int workers;
}s_lob;
main()
{
	printf("Size of union is %d",sizeof(u_lob));
	printf("Size of structure is %d",sizeof(s_lob));
}
