#include<stdio.h>
struct person
{
	char name[50];
	int age;
	float weight;
};
main()
{
	struct person *p,a;
	p=&a;
	printf("Enter name:");
	gets(p->name);
	printf("Enter age:");
	scanf("%d",&p->age);
	printf("Enter weight:");
	scanf("%f",&p->weight);
	printf("Person's details are:\n");
	printf("Name is %s",p->name);
	printf("\nAge is %d",(*p).age);
	printf("\nWeight is %f",p->weight);
}
