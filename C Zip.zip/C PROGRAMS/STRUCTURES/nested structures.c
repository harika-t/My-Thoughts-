#include<stdio.h>
struct student
{
	char name[50];
	int roll_number;
	struct dob
	{
		int dd;
		int mm;
		int yyyy;
	}dob;
};
main()
{
	struct student std;
	printf("Enter name:");
	gets(std.name);
	printf("Enter roll number:");
	scanf("%d",&std.roll_number);
	printf("Enter date of birth[dd mm yyy] format:");
	scanf("%d%d%d",&std.dob.dd,&std.dob.mm,&std.dob.yyyy);
	printf("\nName:%s\nRoll number:%d\nDate of Birth:%d-%d-%d",std.name,std.roll_number,std.dob.dd,std.dob.mm,std.dob.yyyy);
}
