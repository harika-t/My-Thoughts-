#include<stdio.h>
struct student
{
	char name[50];
	int roll;
	float marks;
}s;
main()
{
	printf("Enter information");
	printf("\nEnter name:");
	scanf("%s",s.name);
	printf("Enter roll number:");
	scanf("%d",&s.roll);
	printf("Enter marks:");
	scanf("%f",&s.marks);
	printf("Displaying informantion");
	printf("\nName:%s",s.name);
	printf("\nRoll number:%d",s.roll);
	printf("\nMarks:%f",s.marks);
}
