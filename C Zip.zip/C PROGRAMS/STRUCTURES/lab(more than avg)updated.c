#include<stdio.h>
struct student
{
	int regid;
	char name[20];
	float cgpa;
	struct address
	{
		char village[20];
		char dist[20];
		long int phno;
	}add;
	};
int main()
{
	struct student s[10];
	int n,i,flag=0;
	printf("Enter no of students:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("Enter regid:");
		scanf("%d",&s[i].regid);
		printf("Enter name:");
		scanf("%s",s[i].name);
		printf("Enter cgpa:");
		scanf("%f",&s[i].cgpa);
		printf("Enter address--village,dist and phono:\n");
		scanf("%s%s%ld",s[i].add.village,s[i].add.dist,&s[i].add.phno);
	}
	
	printf("\nStudent details are:\n");
	printf("Regid\tName\tCGPA\t\tAddress\n");
	for(i=0;i<n;i++)
	{
	printf("%d\t",s[i].regid);
	printf("%s\t",s[i].name);
	printf("%f\t",s[i].cgpa);
	printf("%s,%s,%ld\n",s[i].add.village,s[i].add.dist,s[i].add.phno);
	}
	float avg,sum=0;
	for(i=0;i<n;i++)
	{
		sum=sum+s[i].cgpa;
	}
	avg=sum/n;
	printf("Student phone numbers whose cgpa is gretaer than average cgpa are:\n");
	for(i=0;i<n;i++)
	{
	if(s[i].cgpa>avg)
	{
        printf("%ld\n",s[i].add.phno);
        flag=1;
	}
    }
	if(flag==0)
	printf("No student is available with above cgpa");
}
	

