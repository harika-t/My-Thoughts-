#include<stdio.h>
#include<stdlib.h>
struct node
{
	char name[50];
	int roll_number;
	char branch[10];
	int age;
	char gender[10];
	float gpa;
	struct node *link;
};
struct node *root=NULL;
int len;
void append()
{
	struct node *temp;
	temp=(struct node*)malloc(sizeof(struct node));
	printf("Enter your name:");
	scanf("%s",temp->name);
	printf("Enter your roll number:");
	scanf("%d",&temp->roll_number);
	printf("Enter the name of your branch:");
    scanf("%s",temp->branch);
    printf("Enter your age:");
    scanf("%d",&temp->age);
    printf("Enter your gender:");
    scanf("%s",temp->gender);
    printf("Enter your GPA:");
    scanf("%f",&temp->gpa);
	temp->link=NULL;
	if(root==NULL)
	{
		root=temp;
	}
	else
	{
		struct node *p;
		p=root;
		while(p->link!=NULL)
		{
			p=p->link;
		}
		p->link=temp;
	}
}
int length()
{
	int count=0;
	struct node *temp;
	temp=root;
	while(temp!=NULL)
	{
		count++;
		temp=temp->link;
	}
	return count;
}
void display()
{
	struct node *temp;
	temp=root;
	if(temp==NULL)
	{
		printf("No nodes to display\n");
	}
	else
	{
		while(temp!=NULL)
		{
			printf("Name:%s\n",temp->name);
			printf("Roll Number:%d\n",temp->roll_number);
			printf("Branch:%s\n",temp->branch);
			printf("Age:%d\n",temp->age);
			printf("Gender:%s\n",temp->gender);
			printf("GPA:%f\n",temp->gpa);
			temp=temp->link;
		}
	}
}
void addatbegin()
{
	struct node *temp;
	temp=(struct node*)malloc(sizeof(struct node));
	printf("Enter your name:");
	scanf("%s",temp->name);
	printf("Enter your roll number:");
	scanf("%d",&temp->roll_number);
	printf("Enter the name of your branch:");
    scanf("%s",temp->branch);
    printf("Enter your age:");
    scanf("%d",&temp->age);
    printf("Enter your gender:");
    scanf("%s",temp->gender);
    printf("Enter your GPA:");
    scanf("%f",&temp->gpa);
	temp->link=NULL;
if(root==NULL)
{
	root=temp;
}
else
{
	temp->link=root;
	root=temp;
}
}
void addatafter()
{
	struct node *temp,*p;
	int loc,i=1;
	printf("Enter location:");
	scanf("%d",&loc);
	if(loc>length())
	{
		printf("No nodes are present at the given location\n");
	}
	else
	{
		p=root;
		while(i<loc)
		{
			p=p->link;
			i++;
		}
		temp=(struct node *)malloc(sizeof(struct node));
		printf("Enter your name:");
	    scanf("%s",temp->name);
	    printf("Enter your roll number:");
	    scanf("%d",&temp->roll_number);
	    printf("Enter the name of your branch:");
        scanf("%s",temp->branch);
        printf("Enter your age:");
        scanf("%d",&temp->age);
        printf("Enter your gender:");
        scanf("%s",temp->gender);
        printf("Enter your GPA:");
        scanf("%f",&temp->gpa);
		temp->link=NULL;
		temp->link=p->link;
		p->link=temp;
	}
}
void Delete()
{
	struct node *temp;
	int loc;
	printf("Enter location to delete:");
	scanf("%d",&loc);
	if(loc>length())
	{
		printf("Invalid location\n");
	}
	else if(loc==1)
	{
		temp=root;
		root=temp->link;
		temp->link=NULL;
		free(temp);
	}
	else
	{
		int i=1;
		struct node *p=root,*q;
		while(i<loc-1)
		{
			p=p->link;
			i++;
		}
		q=p->link;
		p->link=q->link;
		q->link=NULL;
		free(q);
	}
}
main()
{
	int ch;
	printf("***Single linked list operations***\n");
	printf("1.Append\n");
	printf("2.Add at begin\n");
	printf("3.Add at after\n");
	printf("4.Length\n");
	printf("5.Display\n");
	printf("6.Delete\n");
	printf("7.Quit\n");
	while(1)
	{
		
		printf("Enter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:append();
			break;
			case 2:addatbegin();
			break;
			case 3:addatafter();
			break;
			case 4:printf("The length of the linked list is %d\n",length());
			break;
			case 5:display();
			break;
			case 6:Delete();
			break;
			case 7:exit(1);
			break;
			default:printf("Invalid choice\n");
		}
	}
}
