#include<stdio.h>
#include<stdlib.h>
struct node
{
	char name[50];
	int roll_number;
	char branch[10];
	int age;
	char gender[10];
	float gpa;
	struct node *right;
	struct node *left;
};
struct node *root=NULL;
void display()
{
	struct node *temp=root;
	if(temp==NULL)
	{
		printf("No nodes to display\n");
	}
	else
	{
		while(temp!=NULL)
		{
			printf("Name:%s\n",temp->name);
			printf("Roll Number:%d\n",temp->roll_number);
			printf("Branch:%s\n",temp->branch);
			printf("Age:%d\n",temp->age);
			printf("Gender:%s\n",temp->gender);
			printf("GPA:%f\n",temp->gpa);
			temp=temp->right;
		}
	}
}
void append()
{
	struct node *temp;
	temp=(struct node*)malloc(sizeof(struct node));
	printf("Enter your name:");
	scanf("%s",temp->name);
	printf("Enter your roll number:");
	scanf("%d",&temp->roll_number);
	printf("Enter the name of your branch:");
    scanf("%s",temp->branch);
    printf("Enter your age:");
    scanf("%d",&temp->age);
    printf("Enter your gender:");
    scanf("%s",temp->gender);
    printf("Enter your GPA:");
    scanf("%f",&temp->gpa);
	temp->right=NULL;
	temp->left=NULL;
	if(root==NULL)
	{
		root=temp;
	}
	else
	{
		struct node *p=root;
		while(p->right!=NULL)
		{
			p=p->right;
		}
		p->right=temp;
		temp->left=p;
	}
}
void addatbegin()
{
	struct node *temp;
	temp=(struct node*)malloc(sizeof(struct node));
	printf("Enter your name:");
	scanf("%s",temp->name);
	printf("Enter your roll number:");
	scanf("%d",&temp->roll_number);
	printf("Enter the name of your branch:");
    scanf("%s",temp->branch);
    printf("Enter your age:");
    scanf("%d",&temp->age);
    printf("Enter your gender:");
    scanf("%s",temp->gender);
    printf("Enter your GPA:");
    scanf("%f",&temp->gpa);
	temp->right=NULL;
	temp->left=NULL;
	if(root==NULL)
	{
		root=temp;
	}
	else
	{
		temp->right=root;
		root->left=temp;
		root=temp;
	}
}
int length()
{
	struct node *temp=root;
	int count=0;
	while(temp!=NULL)
	{
		count++;
		temp=temp->right;
	}
	return count;
}
void addatafter()
{
	struct node *temp,*p=root;
	int loc,i=1;
	printf("Enter the location:");
	scanf("%d",&loc);
	if(loc>length())
	{
		printf("Invalid location\n");
	}
	else
	{
		temp=(struct node*)malloc(sizeof(struct node));
		printf("Enter your name:");
	    scanf("%s",temp->name);
	    printf("Enter your roll number:");
	    scanf("%d",&temp->roll_number);
	    printf("Enter the name of your branch:");
        scanf("%s",temp->branch);
        printf("Enter your age:");
        scanf("%d",&temp->age);
        printf("Enter your gender:");
        scanf("%s",temp->gender);
        printf("Enter your GPA:");
        scanf("%f",&temp->gpa);
		temp->right=NULL;
		temp->left=NULL;
		while(i<loc)
		{
			p=p->right;
			i++;
		}
		temp->right=p->right;
		p->right->left=temp;
	    p->right=temp;
	    temp->left=p;
	}
}
void delet()
{
	struct node *temp;
	int loc;
	printf("Enter location:");
	scanf("%d",&loc);
	if(loc>length())
	{
		printf("Invalid location\n");
	}
	else if(loc==1)
    {
    	temp=root;
    	root=temp->right;
    	root->left=NULL;
    	free(temp);
	}
	else if(loc==length())
	{
		temp=root;
		while(temp->right!=NULL)
		{
			temp=temp->right;
		}
		temp->left->right=NULL;
		temp->left=NULL;
		free(temp);
	}
	else
	{
		struct node *p=root,*q;
		int i=1;
		while(i<loc-1)
		{
			p=p->right;
			i++;
		}
		q=p->right;
		p->right=q->right;
		q->right->left=p;
		free(q);
	}
}
main()
{
	int ch;
	printf("***Double linked list operations***\n1.Append\n2.Add at begin\n3.Add at after\n4.Length\n5.Display\n6.Delete\n7.Quit\n");
	
	while(1)
	{printf("Enter your choice:");
	scanf("%d",&ch);
		switch(ch)
		{
			case 1:append();
			break;
			case 2:addatbegin();
			break;
			case 3:addatafter();
			break;
			case 4:printf("The length of the double linked list is %d\n",length());
			break;
			case 5:display();
			break;
			case 6:delet();
			break;
			case 7:exit(1);
			break;
		    default:printf("Invalid choice\n");
		}
	}
}
