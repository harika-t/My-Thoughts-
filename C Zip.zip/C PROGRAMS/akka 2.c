#include<stdio.h>
int prime(int x)
{
	int i,c=0;
	for(i=2;i<=x;i++)
	{
		if(x%i==0)
		c++;
	}
	if(c==1)
	return 1;
	else
	return 0;
}
main()
{
	int d,p,duration,part,x,y,num,count,k,z;
	printf("Enter d:");
	scanf("%d",&d);
	printf("Enter p:");
	scanf("%d",&p);
	duration=d/p;
	y=duration-1;
	num=2;z=p;
	k=0;
	while(y>0)
	{count=0;
		x=num;
		while(p>0)
		{
			if(prime(num))
			{
				count++;
			}
			num=num+duration;
			p--;
		}
		p=z;
		if(count==z)
		k++;
		
		num=x;
		num++;
		y--;
	}printf("%d",k);
}
