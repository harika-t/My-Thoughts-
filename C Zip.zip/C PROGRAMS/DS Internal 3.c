#include<stdio.h>
#include<stdlib.h>
struct node
{
	struct node *left;
	int data;
	struct node *right;
};
struct node *root=NULL;
void create()
{
	struct node *temp;
	temp=(struct node*)malloc(sizeof(struct node));
	printf("Enter data:");
	scanf("%d",&temp->data);
	temp->left=NULL;
	temp->right=NULL;
	if(root==NULL)
	{
		root=temp;
	}
	else
	{
		struct node *p=root;
		struct node *parent;
		while(p)
		{   
			parent=p;
			if(temp->data<p->data)
			{
				p=p->left;
			}
			else
			{
				p=p->right;
			}
		}
	if(p==NULL)
	{
		if(temp->data>parent->data)
		{
			parent->right=temp;
		}
		else
		{
			parent->left=temp;
		}
	}
}
}
void small()
{
	printf("hi");
	struct node *t=root;
	if(t->left==NULL)
	{
		printf("Smallest value is %d",t->data);
	}
	else
	{struct node *p;
		while(t)
		{
			p=t->left;
			t=t->left;
		}
		printf("Smallest value is %d",p->data);
	}
}
main()
{
	int ch;
	printf("Enter -1 to stop entering integers\n");
	do
	{
		printf("Enter choice:");
		scanf("%d",&ch);
		if(ch!=-1)
		{
			create();
		}
	}while(ch!=-1);
	small();
}
