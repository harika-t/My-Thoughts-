#include <stdio.h> 
int main() 
{ 
    printf("\"hello\" \n world\n");
	printf("what are you\tdoing\n");
	printf("c\blanguage\n");
	printf("java language\r");
	printf("\a");
	printf("backslash-\\\n");
	printf("\'c++ language\'\n");
	printf("\vwelcome\n");
	printf("how much\?");
}
