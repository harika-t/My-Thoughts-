#include<stdio.h>
main()
{ int n,on,rn,r;
printf("Enter number:");
scanf("%d",&n);
on=n;
rn=0;
while(n!=0)
{
	r=n%10;
	rn=rn*10+r;
	n=n/10;
}
if(rn==on)
printf("%d is a palindrome",on);
else
printf("%d is not a palindrome",on);
}
