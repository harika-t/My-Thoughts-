#include<stdio.h>
main()
{ int i,count,j,number,n;
printf("Enter number:");
scanf("%d",&n);
for(i=2;i<n;i++)
{ count=0;
 if(n%i==0)
 {
 	count++;
 }
}
 if(count==0)
 {
 printf("%d is a prime number",n);
 }
 else
 printf("%d is not  a prime number",n);
}

