#include<stdio.h>
main()
{int r,c,n=2,i,count;
for(r=1;r<=4;r++)
{ for(c=1;c<=r;c++)
  { while(n!=30)
   { count=0;
    for(i=2;i<n;i++)
     { if(n%i==0)
      count++;
     }
if(count==0)
{printf("%d ",n++);
break;
}
else
{++n;
}
   }
  }printf("\n");
}
}
