#include<stdio.h>
main()
{ int n,i;
printf("Enter number:");
scanf("%d",&n);
for(i=n;i>=1;i--)
printf("\n%d",i);
}
