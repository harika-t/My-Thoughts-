#include<stdio.h>
main()
{ int i,rows,space,k,j;
printf("Enter rows:");
scanf("%d",&rows);
for(i=1;i<=rows;i++)
{
	for(space=i;space<rows;space++)
	{
		printf(" ");
	}
	
	for(k=1;k<=2*i-1;k++)
	{
	if(k%2==0)
		printf("5");
	else
	printf("*");	
   }

	printf("\n");
    


}
}
