#include<stdio.h>
main()
{ int i,n,c,a=0,b=1;
printf("Enter number:");
scanf("%d",&n);
printf("%d",a);
for(i=1;i<=n;i++)
{
	c=a+b;
	a=b;
	b=c;
	printf("\n%d",a);

}
}
