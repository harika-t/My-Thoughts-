#include<stdio.h>
main()
{ int m=10;
if(m==20,0)
 printf("I luv u %d",m);
 else
 printf("I hate u %d",m);
}
