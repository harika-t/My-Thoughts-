#include<stdio.h>
#include<conio.h>

void main(){
   char ch ;
   do
   {
       printf("Enter Y / N : ") ;
       scanf("%c", &ch) ;
       if(ch == 'Y')
       {
           printf("Okay!!! Repeat again !!!\n") ;
       }
       else
       {
           printf("Okay !!! Breaking the loop !!!") ;
           break ;
       }
   } while( 1 ) ; 
   getch() ;
}
