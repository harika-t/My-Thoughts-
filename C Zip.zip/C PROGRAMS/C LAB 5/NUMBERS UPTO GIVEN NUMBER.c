#include<stdio.h>
main()
{ int n,i;
printf("Enter number:");
scanf("%d",&n);
for(i=1;i<=n;i++)
printf("\n%d",i);
}
