#include<stdio.h>
main()
{int a=10,b=5; 
printf("%d",!(a>b));
printf("%d",a>b&&a!=b);
printf("%d",a<b||a!=b);
}
