#include<stdio.h>
main()
{ int i,rows,space,j;
printf("Enter rows:");
scanf("%d",&rows);
for(i=1;i<=rows;i++)
{
	for(j=1;j<=rows;j++)
	{
		printf("*");
	}
	printf("\n");

}
}
