#include<stdio.h>
main()
{ int r,n,temp=0,sum;
printf("Enter number:");
scanf("%d",&n);
sum=n;
while(n!=0)
{
	r=n%10;
	temp+=r*r*r;
	n=n/10;
}
if(temp==sum)
printf("%d is an armstrong number",sum);
else
printf("%d is not an armstrong number",sum);

}
