#include<stdio.h>
main()
{ int i,rows,space,k;
printf("Enter rows:");
scanf("%d",&rows);
for(i=1;i<rows;i++)
{
	for(space=i;space<rows;space++)
	{
		printf("   ");
	}
	for(k=1;k<=2*i-1;k++)
	{
		printf("*  ");
	}
	printf("\n");

}for(i=rows;i>=1;i--)
{
	for(space=i;space<rows;space++)
	{
		printf("   ");
	}
	for(k=1;k<=2*i-1;k++)
	{
		printf("*  ");
	}
	printf("\n");

}
}

