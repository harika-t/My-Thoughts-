#include<stdio.h>
main()
{int i,j,space,l=1,count=0,n,k=30;
printf("Enter n:");
scanf("%d",&n);
for(i=1;i<=n;i++)
{
	for(l=1;l<=k;l++)
	{ for(j=1;j<=l;j++)
	   {
		 if(l%j==0)
		{
		count++;
		if(count==2)
		{
		
		printf("%d",l);
	}
}
}printf("\n");
}

}
}
