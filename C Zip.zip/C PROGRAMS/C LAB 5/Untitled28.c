#include<stdio.h>
main()
{ int n,i,sum=0,j;
printf("n:");
scanf("%d",&n);
for(i=1;i<n;i++)
{if(n%i==0)
sum=sum+i;
}
if(sum==n)
{
printf("y");
}
else
printf("N");
}

