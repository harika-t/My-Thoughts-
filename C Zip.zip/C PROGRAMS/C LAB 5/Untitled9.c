#include<stdio.h>
main()
{ int i,j,n;
printf("Enter n:");
scanf("%d",&n);
 for(i=1;i<=2*i-1;i++)
 {
 	for(j=1;j<=i;j++)
 	{
	 printf("*");
 }
 printf("\n");
}
}
