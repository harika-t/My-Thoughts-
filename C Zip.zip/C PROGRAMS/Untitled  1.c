#include<stdio.h>
main()
{ int x,y=2,z=5;
x=y==z;
printf("%d",x);
}
