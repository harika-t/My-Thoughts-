#include<stdio.h>
main()
{int a,b,c;
printf("The value of a is");
scanf("%d",&a);
printf("The value of b is");
scanf("%d",&b);
c=a+b;
printf("the value of c is %d",c);
}
