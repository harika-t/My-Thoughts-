#include<stdio.h>
main()
{
	int x;
	x=(622,100,101);
	printf("%d",(*(char*)&x)*(x%3));
}
