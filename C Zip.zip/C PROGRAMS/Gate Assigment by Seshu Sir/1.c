#include<stdio.h>
#include<string.h>
main()
{
	char name[]="satellites";
	int len,size;
	len=strlen(name);
	size=sizeof(name);
	printf("%d",len*size);
	printf("\n%d\n%d",len,size);
}
