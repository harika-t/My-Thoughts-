#include<stdio.h>
main()
{
	printf("%c",622);
}
