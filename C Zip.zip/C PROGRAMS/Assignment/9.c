#include<stdio.h>
main()
{int d;
printf("TIRUVEEDHULA HARIKA\nS170007\nCSE-1D\n");
printf("Enter the number of days you are late for submission:");
scanf("%d",&d);
if(d<=5)
{
	printf("You have to pay a fine of 50 paise");
}
else if(d>=6&&d<=10)
{
	printf("You have to pay a fine of 1 rupee");
}
else if(d>10&&d<=30)
{
	printf("You have to pay a fine of 5 rupees");
}
else if(d>30)
{
	printf("Your membership is cancelled");
}
}
