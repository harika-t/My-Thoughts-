#include<stdio.h>
void main()
{
	int a,n;
	printf("TIRUVEEDHULA HARIKA\nS170007\nCSE  1D\n");
	printf("Enter n:");
	scanf("%d",&n);
	printf("The numbers which are not divisible by 3 and 5 are:");
	for(a=1;a<=n;a++)
	{
		if(a%3!=0&&a%5!=0)
		printf("\n%d",a);
	}
}
