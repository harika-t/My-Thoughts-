#include<stdio.h>
void main()
{int n;
printf("TIRUVEEDHULA HARIKA\nS170007\nCSE-1D\n");
printf("Enter input in kilometers:");
scanf("%d",&n);
printf("%d kilometers in meters is %d meters",n,(n*1000));
printf("\n%d kilometers in foot is %f foot",n,(n*3280.84));
printf("\n%d kilometers in inches is %f inches",n,(n*39370.1));
printf("\n%d kilometers in centimeters is %ld centimeters",n,(n*100000));
}
