#include<stdio.h>
void main()
{int n,num,rem,sum=0;
printf("TIRUVEEDHULA HARIKA\nS170007\nCSE-1D\n");
printf("Enter number of digits and number:");
scanf("%d%d",&n,&num);
while(num!=0)
{
	rem=num%10;
	sum=sum+rem;
	num=num/10;
}
printf("The sum %d digits is %d",n,sum);
}
