#include<stdio.h>
void main()
{int a,b,c;
printf("TIRUVEEDHULA HARIKA\nS170007\nCSE-1D\n");
printf("Enter the three sides of a triangle:");
scanf("%d%d%d",&a,&b,&c);
if(a==b&&b==c)
{
   printf("It's an equilateral triangle");
}
else if((a==b&&a!=c&&b!=c)||(b==c&&a!=b&&a!=c)||(c==a&&a!=b&&b!=c))
{
   printf("It's an isosceles triangle");
} 
else if((a*a+b*b==c*c)||(a*a+c*c==b*b)||(b*b+c*c==a*a));
{
  printf("It's a right angled triangle");
}
else
{
  printf("It's a scalene triangle");
}
}
