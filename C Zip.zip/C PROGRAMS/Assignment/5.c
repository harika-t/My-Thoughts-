#include<stdio.h>
void main()
{int a[50],n,i,max,min;
printf("TIRUVEEDHULA HARIKA\nS170007\nCSE-1D\n");
printf("Enter number of elements:");
scanf("%d",&n);
printf("Enter elements into array:\n");
for(i=0;i<n;i++)
{
	scanf("%d",&a[i]);
}
max=a[0];
for(i=0;i<n;i++)
{
	if(a[i]>max)
	{
		max=a[i];
	}
}
min=a[0];
for(i=0;i<n;i++)
{
	if(a[i]<min)
	{
		min=a[i];
	}
}
printf("The range of the given numbers is %d",(max-min));
}
