#include<stdio.h>
main()
{int a[50],i,n,sum=0,add=0;
printf("TIRUVEEDHULA HARIKA\nS170007\nCSE-1D\n");
printf("Enter number of elements:");
scanf("%d",&n);
printf("Enter elements into array:\n");
for(i=0;i<n;i++)
{
	scanf("%d",&a[i]);
}
for(i=0;i<n;i++)
{
	if(a[i]%2==0)
	sum+=a[i];
	else
	add+=a[i];
}	
printf("Sum of even numbers is %d",sum);
printf("\nSum of odd numbers is %d",add);
}
