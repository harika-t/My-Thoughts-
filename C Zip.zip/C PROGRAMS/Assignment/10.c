#include<stdio.h>
main()
{int a,b;
printf("Enter percentage of marks in A and B:");
scanf("%d%d",&a,&b);
if(a>=55&&b>=45)
{
	printf("You have passed the exam");
}
else if(a>=45&&a<=55&&b>=55)
{
	printf("You have passed the exam");
}
else if(a>=65&&b<=45)
{
	printf("You can reappear for B exam");
}
else
{
	printf("You have failed");
}
}
