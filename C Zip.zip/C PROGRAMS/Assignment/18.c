#include<stdio.h>
void main()
{
	int a[100],i,n,c,m,max,j;
	printf("TIRUVEEDHULA HARIKA\nS170007\nCSE  1D\n");
	printf("Enter the number of elements:");
	scanf("%d",&n);
	printf("Enter the elements:\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	m=2;
	for(i=0;i<n;i++)
	{
		c=1;
		for(j=i+1;j<n;j++)
		{
			if(a[i]==a[j])
			c++;
			if(c>=m)
			max=a[i];
		}
	}
	printf("The maximum times repeated element is %d",max);
}
