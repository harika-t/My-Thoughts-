#include<stdio.h>
main()
{
	int d=1,m=0,y,year,ye,cc,day,sum;
	printf("enter the year: ");
	scanf("%d",&y);
	year=y%100;
	ye=year/4;
	if(y>=1600&&y<=1699)
	{
		cc=6;
	}
	else if(y>=1700&&y<=1799)
	{
	    cc=4;
	}
	else if(y>=1800&&y<=1899)
	{
		cc=2;
	}
	else if(y>=1900&&y<=1999)
	{
		cc=0;
	}
	else if(y>=2000&&y<=2099)
	{
		cc=6;
	}
	sum=d+m+year+cc+ye;
day=sum%7;
if(y%4==0)

switch(day)
{
	case 1:printf("Sun");
	break;
	case 2:printf("Mon");
	break;
	case 3:printf("Tue");
	break;
	case 4:printf("Wed");
	break;
	case 5:printf("Thur");
	break;
	case 6:printf("Fri");
	break;
	case 7:printf("Sat");
	break;
}	
else
{
	switch(day)
{
	case 0:printf("Sun");
	break;
	case 1:printf("Mon");
	break;
	case 2:printf("Tue");
	break;
	case 3:printf("Wed");
	break;
	case 4:printf("Thur");
	break;
	case 5:printf("Fri");
	break;
	case 6:printf("Sat");
	
}

}

}
