#include<stdio.h>
main()
{int n,decimaltooctal(int ),decimaltohexadecimal(int);
printf("TIRUVEEDHULA HARIKA\nS170007\nCSE-1D\n");
printf("Enter decimal number:");
scanf("%d",&n);
printf("%d in octal is %d",n,decimaltooctal(n));
printf("\n%d in hexadecimal is %d",n,decimaltohexadecimal(n));
}
int decimaltooctal(int n)
{
	int octalnum=0,i=1;
	while(n!=0)
	{
		octalnum+=(n%8)*i;
		n/=8;
		i*=10;
	}
    return octalnum;	
}
int decimaltohexadecimal(int n)
{
	int hexadecimal=0,i=1;
	while(n!=0)
	{
		hexadecimal+=(n%16)*i;
		n/=16;
		i*=10;
	}
	return hexadecimal;
}
