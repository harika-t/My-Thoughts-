#include<stdio.h>
void main()
{
	int r,i,j;
	printf("TIRUVEEDHULA HARIKA\nS170007\nCSE  1D\n");
	printf("Enter the number of rows:");
	scanf("%d",&r);
	for(i=1;i<=r;i++)
	{ for(j=1;j<=r;j++)
	  { 
	     if(i==1||j==1||i==r||j==r)
		   printf("1 ");
	     else
		   printf("0 ");
	  }
		printf("\n");
	}
}
