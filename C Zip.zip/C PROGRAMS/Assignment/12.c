#include <stdio.h>
void main()
{
	float x,sum,term;
	int i,n;
	printf("TIRUVEEDHULA HARIKA\nS170007\nCSE  1D\n");
	printf("Value of x is:");
	scanf("%f",&x);
	printf("Number of terms upto which series is to be computed:");
	scanf("%d",&n);
	sum=1;term=1;
	for (i=1;i<n;i++)
	{
	  term=term*x/i;
	  sum=sum+term;
	}
	printf("The sum  is : %f",sum);
}
