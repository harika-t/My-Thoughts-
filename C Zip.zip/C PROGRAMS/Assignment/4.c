#include<stdio.h>
void main()
{int n;
printf("TIRUVEEDHULA HARIKA\nS170007\nCSE-1D\n");
printf("Enter any year:");
scanf("%d",&n);
(n%4)==0?printf("%d is a leap year",n):printf("%d is not a leap year",n);
}
