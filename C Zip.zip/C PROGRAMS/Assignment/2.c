#include<stdio.h>
void main()
{
	int year=1900,n,leap,normaldays,diff,totaldays,day;
	printf("TIRUVEEDHULA HARIKA\nS170007\nCSE 1D\n");
	printf("Enter present year:");
	scanf("%d",&n);
	n=(n-1)-year;
	leap=n/4;
	normaldays=n-leap;
	totaldays=(normaldays*365)+(leap*366)+1;
	day=totaldays%7;
	if(day==0)
	{
		printf("Monday");
	}
	else if(day==1)
	{
		printf("Tuesday");
	}
	else if(day==2)
	{
		printf("Wednesday");
	}
	else if(day==3)
	{
		printf("Thursday");
	}
	else if(day==4)
	{
		printf("Friday");
	}
	else if(day==5)
	{
		printf("Saturday");
	}
	else
	{
		printf("Sunday");
	}
}
