#include<stdio.h>
void main()
{int a,b,c,choice,min,max;
printf("TIRUVEEDHULA HARIKA\nS170007\nCSE-1D\n");
printf("Enter three values:");
scanf("%d%d%d",&a,&b,&c);
printf("1-Product\n2-Smallest number\n3-Middle number\n4-Biggest number");
printf("\nEnter choice:");
scanf("%d",&choice);
switch(choice)
  {
	case 1:printf("The product of %d,%d and %d is %d",a,b,c,(a*b*c));
	       break;
	case 2:if((a<b)&&(a<c))
	        min=a;
	        else if(b<c)
	        min=b;
	        else
	        min=c;
	        printf("The smallest number among %d,%d and %d is %d",a,b,c,min);
	        break;
	case 3:if((a>b)&&(a>c))
	        max=a;
	        else if(b>c)
	        max=b;
	        else
	        max=c;
	        if((a<b)&&(a<c))
	        min=a;
	        else if(b<c)
	        min=b;
	        else
	        min=c;
	        printf("The middle number among %d,%d and %d is %d",a,b,c,((a+b+c)-(max+min)));
	        break;
	case 4:if((a>b)&&(a>c))
	        max=a;
	        else if(b>c)
	        max=b;
	        else
	        max=c;
	        printf("The biggest number among %d,%d and %d is %d",a,b,c,max);
	        break;
  }
}
