#include<stdio.h>
main() 
{ 
 int a[100],n,i,sum=0; 
 printf("TIRUVEEDHULA HARIKA\nS170007\nCSE 1D\n");
 printf("Enter the number of elements:"); 
 scanf("%d",&n); 
 printf("Enter elements into array:\n"); 
 for(i=0;i<n;i++) 
 { 
  scanf("%d",&a[i]); 
 } 
 printf("The array of cumulative sum is:\n");
for(i=0;i<n;i++)
{
	sum=a[i];
	a[i+1]+=sum;
	printf("%d\n",a[i]);
}
} 
