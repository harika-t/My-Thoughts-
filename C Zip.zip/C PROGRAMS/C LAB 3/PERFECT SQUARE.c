
#include<stdio.h>
main()
{int n,i,c=0;
printf("Enter number:");
scanf("%d",&n);
for(i=1;i<=n;i++)
{
	if(n==i*i)
	{
		c++;
	}

}
	if(c==1)
	{
		printf("perfect");
	}
    else
    printf("Not perfect");
}
