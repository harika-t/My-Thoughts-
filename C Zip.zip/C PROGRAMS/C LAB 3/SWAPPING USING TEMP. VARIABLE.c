#include<stdio.h>
main()
{ int a,b,c;
printf("Enter original values of a and b:");
scanf("%d%d",&a,&b);
c=a;
a=b;
b=c;
printf("Reversed values of a and b are %d and %d",a,b);
}
