#include<stdio.h>
main()
{ int a,b,choice,result;
printf("0-Addition\n1-Subtraction\n2-Multiplication\n3-Division\n4-Remainder\n");
printf("Enter a and b:");
scanf("%d%d",&a,&b);
printf("Enter your choice:");
scanf("%d",&choice);
switch(choice)
{
	case 0:result=a+b;
	printf("Addition=%d",result);
	break;
	case 1:result=a-b;
	printf("Subtarction=%d",result);
	break;
	case 2:result=a*b;
	printf("Multiplication=%d",result);
	break;
	case 3:result=a/b;
	printf("Quotient=%d",result);
	break;
	case 4:result=a%b;
	printf("Remainder=%d",result);
	break;
	default:printf("Your choice is invalid");
}
}
