#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *link;
};
struct node *root=NULL;
void append()
{
	struct node *temp;
	temp=(struct node*)malloc(sizeof(struct node));
	printf("Enter an integer:");
	scanf("%d",&temp->data);
	temp->link=NULL;
	if(root==NULL)
	{
		root=temp;
	}
	else
	{
		struct node *p=root;
		while(p->link!=NULL)
		{
			p=p->link;
		}
		p->link=temp;
	}
}
void insert(int count)
{
	int i=1,loc;
	struct node *temp;
	printf("Enter location:");
	scanf("%d",&loc);
	if(loc>count)
	{
		printf("Wrong location(Exceeded)");
	}
	else
	{
	temp=(struct node*)malloc(sizeof(struct node));
	printf("Enter data:");
	scanf("%d",&temp->data);
	temp->link=NULL;
	struct node *p=root,*q;
	while(i<loc-1)
	{
		p=p->link;
		i++;
	}
	q=p->link;
	temp->link=q;
	p->link=temp;
	printf("Values upto position %d are :\n",loc);
	p=root;i=1;
	while(i<=loc)
	{
		printf("%d\t",p->data);
		p=p->link;
		i++;
	}
}
}
main()
{
	int ch,count=0;
	printf("Enter -1 to stop entering/storing integers\n");
	do
	{
		printf("Enter choice:");
		scanf("%d",&ch);
		if(ch!=-1)
		{
			append();
			count++;
		}
	}while(ch!=-1);
	insert(count);
}
