
 main(){
   char ch = 'A';
   putchar(ch);   

}
