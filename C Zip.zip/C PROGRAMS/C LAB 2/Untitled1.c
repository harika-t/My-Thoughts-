#include<stdio.h>
#include<conio.h>

void main(){
   char ch;
   printf("\nEnter any character : ");
   ch = getchar();
   printf("\nYou have entered : %c\n",ch);   

}
