#include<stdio.h>
main()
{ int a=2,b,c,d,e,f;
b=++a+1;
f=7;
c=f+++1;
printf("%d\n%d\n",b,c);
d=7;
b=--d+1;
e=7;
c=e--+1;
printf("%d\n%d",b,c);
}
