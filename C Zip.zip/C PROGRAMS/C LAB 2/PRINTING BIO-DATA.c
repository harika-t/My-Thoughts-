#include<stdio.h>
main()
{
printf("Name:Harika\nDate of birth:10-10-2001\nBranch:Computer Science and Engineering");
}
