#include<stdio.h>
main()
{ int a,b;
printf("Enter the values of a and b:");
scanf("%d%d",&a,&b);
printf("a&b is %d\n",a&b);
printf("a|b is %d\n",a|b);
printf("a^b is %d\n",a^b);
printf("~a is %d\n",~a);
printf("Left shift of a is %d\n",a<<2);
printf("Right shift of a is %d\n",a>>2);
}
