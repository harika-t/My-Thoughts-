#include<stdio.h>
main()
{ int a,b;
printf("Enter values:");
scanf("%d%d",&a,&b);
a>b?printf("true"):printf("false");
}
