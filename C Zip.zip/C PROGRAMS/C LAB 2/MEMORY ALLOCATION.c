#include<stdio.h>
main()
{ 
  int a=12;
  float b=1.2;
 char c='v';
printf("The memory allocated for an integer is %d\n",sizeof(a));
printf("The memory allocated for a floating point value is %d\n",sizeof(b));
printf("The memory allocated for a character is %d\n",sizeof(c));
}
