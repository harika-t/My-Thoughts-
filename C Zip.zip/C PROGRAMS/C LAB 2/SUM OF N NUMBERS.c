#include<stdio.h>
main()
{
 int i,sum,n;

 printf("Enter the number:");
 scanf("%d",&n);
 sum=(n*(n+1)/2);
 printf("Sum of %d numbers is %d",n,sum);
}

