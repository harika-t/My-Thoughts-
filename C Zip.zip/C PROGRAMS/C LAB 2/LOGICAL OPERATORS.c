#include<stdio.h>
main()
{int a,b;
printf("enter a and b:");
scanf("%d%d",&a,&b);
printf("a & b is %d\n",a&&b);
printf("a or b is %d\n",a||b);
printf("a not b is %d\n",!b);
}
