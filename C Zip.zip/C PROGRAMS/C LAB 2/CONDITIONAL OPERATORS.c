#include<stdio.h>
main()
{ int a;
printf("enter a:");
scanf("%d",&a);
a>=0?printf("a is positive"):printf("a is negative");
}
