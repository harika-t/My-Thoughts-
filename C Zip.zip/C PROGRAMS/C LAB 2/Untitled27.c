#include<stdio.h>
main()
{int a=2;
printf("%d",a+=10);
}
