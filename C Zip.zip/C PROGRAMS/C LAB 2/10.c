#include<stdio.h>
main()
{int a,b,c,d,e;
a=10,b=10,c=10,d=10,e=10;
printf("%d\n%d\n%d\n%d\n%d\n",a+=2,b-=2,c*=2,d/=2,e%=2);
}
