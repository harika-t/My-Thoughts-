#include<stdio.h>
main()
{int a,b;
printf("enter a and b:");
scanf("%d%d",&a,&b);
a=a+b;
b=a-b;
a=a-b;
printf("%d\n%d",a,b);
}
