#include<stdio.h>
mergeSort(int a[],int b[],int lb,int ub)
{
	int mid;
	if(lb<ub)
	{
		mid=(lb+ub)/2;
		mergeSort(a,b,lb,mid);
		mergeSort(a,b,mid+1,ub);
		merge(a,b,lb,mid,ub);
	}
}
merge(int a[],int b[],int lb,int mid,int ub)
{
	int h=lb,i=lb,j=mid+1,k;
	while((h<=mid)&&(j<=ub))
	{
		if(a[h]<a[j])
		{
			b[i]=a[h];
			h++;
		}
		else
		{
			b[i]=a[j];
			j++;
		}
		i++;
	}
	if(h>mid)
	{
		for(k=j;k<=ub;k++)
		{
			b[i]=a[k];
			i++;
		}
	}
	else
	{
		for(k=h;k<=mid;k++)
		{
			b[i]=a[h];
			i++;
		}
	}
	for(k=lb;k<=ub;k++)
	{
		a[k]=b[k];
	}
}
main()
{
	int a[100],b[100],n,i;
	printf("Enter number of elements:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	mergeSort(a,b,0,n-1);
	printf("Elements after sorting are:\n");
	for(i=0;i<n;i++)
	{
		printf("%d\t",a[i]);
	}
}
