#include<stdio.h>
main()
{int a[100],n,small,smallest(),i;
printf("Enter number of elements in array:");
scanf("%d",&n);
printf("Enter elements into array:\n");
for(i=0;i<n;i++)
{
	scanf("%d",&a[i]);
}
printf("The entered array is:");
for(i=0;i<n;i++)
{
	printf("\n%d",a[i]);
}
for(i=0;i<n-1;i++)                              
{
	small=smallest(a[i],smallest(a[i],a[i+1]));
}
printf("\nThe smallest number in the array is %d",small);
}
int smallest(int x,int y) 
{
	return ((x<y)?0:(x-y));
}
