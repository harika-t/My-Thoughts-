#include<stdio.h>
main()
{int a[100],b[100],c[100],i,j,k,n1,n2,n3;
printf("Enter number of elements of array 1:");
scanf("%d",&n1);
printf("Enter elements:\n");
for(i=0;i<n1;i++)
{
	scanf("%d",&a[i]);
}
printf("Enter number of elements of array 2:");
scanf("%d",&n2);
printf("Enter elements:\n");
for(i=0;i<n2;i++)
{
	scanf("%d",&b[i]);
}
printf("Enter number of elements of array 3:");
scanf("%d",&n3);
printf("Enter elements:\n");
for(i=0;i<n3;i++)
{
	scanf("%d",&c[i]);
}
printf("Dupliacate elements are:");
for(i=0;i<n1;i++)
{
	for(j=0;j<n2;j++)
	{
		for(k=0;k<n3;k++)
		{
			if(a[i]==b[j]&&b[j]==c[k]&&c[k]==a[i])
			{
				printf("\n%d",a[i]);
			}
		}
	}
}
}
