#include<stdio.h>
main()
{char a[100],i;
printf("Enter any string:");
gets(a);
for(i=0;a[i]!='\0';i++)
{
	if(a[i]>='A'&&a[i]<='Z')
	{
		a[i]='#';
	}
	else if(a[i]>='a'&&a[i]<='z')
	{
		a[i]='*';
	}
}
printf("Modified string is %s",a);
}
