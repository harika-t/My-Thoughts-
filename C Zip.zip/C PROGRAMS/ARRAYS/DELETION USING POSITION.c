#include<stdio.h>
main()
{ int a[10],n,i,j,p,e;
printf("Enter number of elements:");
scanf("%d",&n);
for(i=0;i<n;i++)
{
	printf("Enter a[%d]:",i);
	scanf("%d",&a[i]);
}
printf("Enter position:");
scanf("%d",&p);
if(p<=n)
{
	for(j=p-1;j<n;j++)
	a[j]=a[j+1];
}
else
printf("Deletion is not possible");
for(i=0;i<n;i++)
printf("\na[%d] is %d",i,a[i]);
}
