#include<stdio.h>
main()
{ int a[10],n,i,j,index,e;
printf("Enter number of elements:");
scanf("%d",&n);
for(i=0;i<n;i++)
{
	printf("Enter a[%d]:",i);
	scanf("%d",&a[i]);
}
printf("Enter index:");
scanf("%d",&index);
if(index<n)
{
	for(j=index;j<n;j++)
	a[j]=a[j+1];
}
else
printf("Deletion is not possible");
for(i=0;i<=n;i++)
printf("\na[%d] is %d",i,a[i]);
}
