#include<stdio.h>
main()
{ int a[10],large,small,h,i,n,r;
printf("Enter number of elements in array:");
scanf("%d",&n);
printf("Enter elements into array:");
for(i=0;i<n;i++)
{
  scanf("%d",&a[i]);
}
large=a[0];
for(i=0;i<n;i++)
{
	if(a[i]>large)
	{
		large=a[i];
	}
}
h=a[1];
for(i=0;i<n;i++)
{
	if(a[i]!=large)
	{
		if(h>a[i])
		{
			h=a[i];
		}
	}
}
printf("%d is the second largest number\n",h);
small=a[0];
for(i=0;i<n;i++)
{
	if(a[i]<small)
	{
		small=a[i];
	}
}
r=a[1];
for(i=0;i<n;i++)
{
	if(a[i]!=small)
	{
		if(a[i]<r)
		{
			r=a[i];
		}
	}
}
printf("%d is the second smallest number",r);
} 
