#include<stdio.h>
main()
{int a[50],n,i,index;
printf("Enter number of elements in array:");
scanf("%d",&n);
printf("Enter elements:\n");
for(i=0;i<n;i++)
{
	scanf("%d",&a[i]);
}
printf("The elements are:");
for(i=0;i<n;i++)
{
	printf("%d\t",a[i]);
}
printf("\nEnter the index value of the element to be deleted:");
scanf("%d",&index);
if(index<n)
{
	for(i=index;i<n;i++)
	{
		a[i]=a[i+1];
	}
}
else
printf("Deletion is not possible");
for(i=0;i<n-1;i++)
{
	printf("%d\t",a[i]);
}
}
