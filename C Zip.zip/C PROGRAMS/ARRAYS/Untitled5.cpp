#include<stdio.h>
int remainder()
int reverse()
int number()
main()
{int n,temp;
printf("Enter number:");
scanf("%d",&n);
temp=n;
while(n!=0)
{ if(temp==rev)
printf("IS a palindrome");
else
{printf("Is not ")
}
}
}
int remainder()
{int rem;
rem=n%10;
return rem;
}
int reverse()
{int rev
rev=0;
rev=rev*10+rem;
return rev;
}
int number()
{int n;
n=n/10;
return n;
}
