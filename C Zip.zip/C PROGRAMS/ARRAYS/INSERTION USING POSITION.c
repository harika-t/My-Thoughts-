#include<stdio.h>
main()
{ int a[10],n,i,j,p,e;
printf("Enter number of elements:");
scanf("%d",&n);
for(i=0;i<n;i++)
{
	printf("Enter a[%d]:",i);
	scanf("%d",&a[i]);
}
printf("Enter element and position:");
scanf("%d%d",&e,&p);
if(p<=n)
{
	for(j=n;j>=p;j--)
	{
	a[j]=a[j-1];
    }
    a[p-1]=e;
}
else
printf("Insertion is not possible");
for(i=0;i<=n;i++)
printf("\na[%d] is %d",i,a[i]);
}
