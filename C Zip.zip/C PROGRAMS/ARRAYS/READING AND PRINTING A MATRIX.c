#include<stdio.h>
main()
{int a[10][10],row,col,i,j;
printf("Enter number of rows and columns:");
scanf("%d%d",&row,&col);
printf("Enter elements:\n");
for(i=0;i<row;i++)
{
	for(j=0;j<col;j++)
	scanf("%d",&a[i][j]);
}
printf("The matrix is:\n");
for(i=0;i<row;i++)
{
    for(j=0;j<col;j++)
    {
    	printf("%d\t",a[i][j]);
	}
	printf("\n");
}
}
