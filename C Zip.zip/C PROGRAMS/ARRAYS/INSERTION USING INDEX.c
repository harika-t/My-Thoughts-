#include<stdio.h>
main()
{ int a[10],i,j,n,index,e;
printf("Enter number of elements:");
scanf("%d",&n);
for(i=0;i<n;i++)
{
	printf("Enter a[%d]:",i);
	scanf("%d",&a[i]);
}
printf("Enter element and index:");
scanf("%d%d",&e,&index);
if(index<n)
{
	for(j=n-1;j>=index;j--)
	{
		a[j+1]=a[j];
	}
	a[index]=e;
}
else
printf("Insertion is not possible");
for(i=0;i<=n;i++)
printf("\na[%d] is %d",i,a[i]);
}
