#include<stdio.h>
main()
{ int a[10],sum=0,n,i,product=1;
float avg;
printf("Enter number of elements:");
scanf("%d",&n);
printf("Enter elements in array:\n");
for(i=0;i<n;i++)
{printf("Enter a[%d]=",i);
scanf("%d",&a[i]);
}
for(i=0;i<n;i++)
{
    sum=sum+a[i];
}
printf("The sum is %d\n",sum);
avg=(float)sum/n;
printf("Average is %f\n",avg);
for(i=0;i<n;i++)
{
	product=product*a[i];
}
printf("The product is %d",product);
}
