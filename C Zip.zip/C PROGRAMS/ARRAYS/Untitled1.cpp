#include<stdio.h>
main()
{ int a[5],sum=0,n,i,avg;
printf("Enter number of students:");
scanf("%d",&n);
for(i=0;i<n;i++)
{printf("Enter a[%d]=",i);
scanf("%d",&a[i]);
sum=sum+a[i];
}
avg=sum/n;
printf("%d",avg);

}
