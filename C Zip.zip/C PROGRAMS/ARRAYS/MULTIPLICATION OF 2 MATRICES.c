#include<stdio.h>
main()
{ int a[10][10],b[10][10],c[10][10],arow,acol,brow,bcol,i,j,k;
printf("Enter rows and columns of a:\n");
scanf("%d%d",&arow,&acol);
printf("Enter elements of a:\n");
for(i=0;i<arow;i++)
{
	for(j=0;j<acol;j++)
	scanf("%d",&a[i][j]);
}
printf("Enter rows and columns of b:\n");
scanf("%d%d",&brow,&bcol);
printf("Enter elements of b:\n");
for(i=0;i<brow;i++)
{
	for(j=0;j<bcol;j++)
	{
	scanf("%d",&b[i][j]);
    }
}
printf("Elements of a are:\n");
for(i=0;i<arow;i++)
{
	for(j=0;j<acol;j++)
	{
		printf("%d\t",a[i][j]);
	     
	}printf("\n");
}
printf("Elements of b are:\n");
for(i=0;i<brow;i++)
{
    for(j=0;j<bcol;j++)
	{
	    printf("%d\t",b[i][j]);	
	}printf("\n");	
}
if(acol==brow)
{ for(i=0;i<arow;i++)
  {
	 for(j=0;j<bcol;j++)
	 {
	  c[i][j]=0;
	  for(k=0;k<acol;k++)
	  {
	  	c[i][j]+=a[i][k]*b[k][j];
	  }	
	 } 
  }
  printf("Multiplication of a and b is:\n");
for(i=0;i<arow;i++)
{
	for(j=0;j<bcol;j++)
	{
		printf("%d\t",c[i][j]);
	}printf("\n");
}
}
else
printf("Multiplication is not possible");

}
