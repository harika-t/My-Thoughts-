#include<stdio.h>
main()
{ int a[50],large,small,h,i,n,r=0;
printf("Enter number of elements in array:");
scanf("%d",&n);
for(i=0;i<n;i++)
{
printf("Enter element a[%d]:",i);
scanf("%d",&a[i]);
}
large=a[0];
for(i=1;i<n;i++)
{
	if(a[i]>large)
	{
		h=large;
		large=a[i];
	}
}
printf("%d is the largest number\n",large);
printf("%d is the second largest number\n",h);
small=a[0];
for(i=1;i<n;i++)
{
	if(a[i]<small)
	{
		r=small;
		small=a[i];
	}
}
printf("%d is the smallest number\n",small);
printf("%d is the second smallest number",r);
}
