#include<stdio.h>
main()
{ int a[10][10][10],n,i,j,k,m,o;
printf("Enter n:");
scanf("%d%d%d",&n,&m,&o);
printf("Enter elements:\n");
for(i=0;i<n;i++)
{
	for(j=0;j<m;j++)
	{ 
	     for(k=0;k<o;k++)
	     scanf("%d",&a[i][j][k]);
	}
}
printf("The matrix is:\n");
for(i=0;i<n;i++)
{
	for(j=0;j<m;j++)
	{ 
	     for(k=0;k<o;k++)
	    {
		 printf("%d\t",a[i][j][k]);
	}printf("\n");
	}printf("\n");
}

}
