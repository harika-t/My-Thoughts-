#include<stdio.h>
main()
{int a[10],i,n,e,large,small;
printf("Enter number of elements in array:");
scanf("%d",&n);
for(i=0;i<n;i++)
{
	printf("Enter element a[%d]:",i);
	scanf("%d",&a[i]);
}
for(i=0;i<n;i++)
{
    printf("\na[%d] is %d",i,a[i]);
}
printf("\nElement to search is:");
scanf("%d",&e);
for(i=0;i<n;i++)
{
	if(a[i]==e)
	{
		printf("%d is present in the array",e);
		printf("\nAnd its position is %d",i+1);
		break;
	}
}
large=a[0];
for(i=1;i<n;i++)
{
	if(a[i]>large)
	large=a[i];

    }
printf("\n%d is the largest number",large);
small=a[0];
for(i=1;i<n;i++)
{
	if(a[i]<small)
	small=a[i];
}
printf("\n%d is the smallest number",small);
}
