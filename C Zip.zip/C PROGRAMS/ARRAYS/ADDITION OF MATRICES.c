#include<stdio.h>
main()
{ int a[10][10],b[10][10],c[10][10],row,col,i,j;
printf("Enter number of rows and columns:");
scanf("%d%d",&row,&col);
printf("Enter elements of a:\n");
for(i=0;i<row;i++)
{
	for(j=0;j<col;j++)
	scanf("%d",&a[i][j]);
}
printf("Enter elements of b:\n");
for(i=0;i<row;i++)
{
	for(j=0;j<col;j++)
	scanf("%d",&b[i][j]);
}
for(i=0;i<row;i++)
{ 
    for(j=0;j<col;j++)
    c[i][j]=a[i][j]+b[i][j];
}
printf("Addition of a and b is:\n");
for(i=0;i<row;i++)
{
	for(j=0;j<col;j++)
	{
	printf("%d\t",c[i][j]);
}printf("\n");
}
}

