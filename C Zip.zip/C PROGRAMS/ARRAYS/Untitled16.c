#include<stdio.h>
main()
{ int a[2][3],i,j,row,col;
printf("Enter number of rows and columns:");
scanf("%d%d",&row,&col);
printf("Enter elements:\n");
for(i=0;i<5;i++)
{
	for(j=0;j<2;j++)
	{
		scanf("%d",&a[i][j]);
	}
}
printf("The array is:\n");
for(i=0;i<5;i++)
{
	for(j=0;j<2;j++)
	{
		printf("%d\t",a[i][j]);
	}printf("\n");
}

}
