#include<stdio.h>
main()
{int a[50],i,j,n,temp,b[50];
printf("Enter number of elements in array:");
scanf("%d",&n);
printf("Enter elements in array:\n");
for(i=0;i<n;i++)
{
    scanf("%d",&a[i]);
}
for(i=0;i<n;i++)
{
	for(j=i+1;j<n;j++)
	{
		if(a[i]>a[j])
		{
			temp=a[i];
			a[i]=a[j];
			a[j]=temp;
		}
	}
}
printf("Elements in ascending order are:");
for(i=0;i<n;i++)
{
	printf("%d\t",a[i]);
}
for(i=0;i<n;i++)
{
	b[i]=a[i];
}
printf("\nSecond smallest number is %d",b[1]);
printf("\nSecond largest number is %d",b[n-2]);
}
