#include<stdio.h>
main()
{ int a[10][10][10],i,j,k,rowin,rowout,col;
printf("Enter number of rowout,rowin,col:");
scanf("%d%d%d",&rowout,&rowin,&col);
printf("Enter elements in array:\n");
for(i=0;i<rowout;i++)
{
	for(j=0;j<rowin;j++)
	{
		for(k=0;k<col;k++)
		{
		scanf("%d",&a[i][j][k]);
	}
	}
}
printf("The array is:\n");
for(i=0;i<rowout;i++)
{
	for(j=0;j<rowin;j++)
	{
		for(k=0;k<col;k++)
		{
		printf("%d\t",a[i][j][k]);
	}printf("\n");
}printf("\n");

}
}
