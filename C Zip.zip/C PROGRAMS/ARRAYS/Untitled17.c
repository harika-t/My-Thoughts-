#include<stdio.h>
main()
{ int a[10],fsmall,ssmall,i,n,temp;
printf("Enter number of elements in array:");
scanf("%d",&n);
printf("Enter array:\n");
for(i=0;i<n;i++)
{
	scanf("%d",&a[i]);
}
fsmall=a[0];
ssmall=a[1];
if(fsmall>ssmall)
{
	temp=fsmall;
	fsmall=ssmall;
	ssmall=temp;
}
for(i=2;i<n;i++)
{
	if(a[i]<fsmall)
	{
		fsmall=a[i];
		ssmall=fsmall;
	}
	else if(a[i]<ssmall)
	{ssmall=a[i];
	}
}
printf("%d is the smallest number and %d is the second smallest number",fsmall,ssmall);
}
