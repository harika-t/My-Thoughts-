#include<stdio.h>
main()
{int a[50],i,index,e,n;
printf("Enter number of elements in array:");
scanf("%d",&n);
printf("Enter elements:\n");
for(i=0;i<n;i++)
{
	scanf("%d",&a[i]);
}
printf("The elements are:");
for(i=0;i<n;i++)
{
	printf("%d\t",a[i]);
}
printf("\nEnter element to be inserted and index position:");
scanf("%d%d",&e,&index);
if(index<n)
{
	for(i=n-1;i>=index;i--)
	{
		a[i+1]=a[i];
	}
	a[index]=e;
}
else
printf("Invalid index");
printf("New array is:\n");
for(i=0;i<=n;i++)
{
	printf("%d\t",a[i]);
}
}
