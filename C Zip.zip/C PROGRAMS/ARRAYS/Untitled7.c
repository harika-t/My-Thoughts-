#include<stdio.h>
main()
{ int x=032;
printf("%d",x);
}
