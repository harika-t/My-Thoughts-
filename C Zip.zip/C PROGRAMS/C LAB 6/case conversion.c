#include<stdio.h>
#include<conio.h>
#include<string.h>
main()
{ char a[50];
int i;
printf("Enter string a:");
gets(a);
for(i=0;a[i]!='\0';i++)
{
   a[i]=a[i]+32;
   printf("%c",a[i]);
}
}
