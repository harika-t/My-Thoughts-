#include<stdio.h>
main()
{int a,b,c,d;
a=5;
b=++a;
printf("%d,%d,",a,b);
c=7;
d=c++;
printf("%d,%d",c,d);
}
