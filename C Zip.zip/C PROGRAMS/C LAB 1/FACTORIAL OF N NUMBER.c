#include<stdio.h>
main()
{ int n,i,fact;
printf("Enter number:");
scanf("%d",&n);
fact=1;
i=1;
while(i<=n)
{
	fact=fact*i;
	i=i+1;
}
printf("The factorial of %d numbers is %d",n,fact);
}
