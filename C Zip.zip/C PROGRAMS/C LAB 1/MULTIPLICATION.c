#include<stdio.h>
main()
{ int a,b,c;
printf("a,b are:");
scanf("%d%d",&a,&b);
c=a*b;
printf("C is %d",c);
}
