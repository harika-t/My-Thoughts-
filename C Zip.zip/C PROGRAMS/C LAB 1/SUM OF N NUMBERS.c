#include<stdio.h>
main()
{ int n,i,sum;
printf("Enter number:");
scanf("%d",&n);
sum=0;
i=1;
while(i<=n)
{
	sum=sum+i;
	i++;
}
printf("The sum of %d numbers is %d",n,sum);
}
