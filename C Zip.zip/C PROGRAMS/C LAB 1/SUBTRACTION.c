#include<stdio.h>
main()
{ int a,b,c;
printf("The values of a,b are  : ");
scanf("%d%d",&a,&b);
c=a-b;
printf("The value of c is %d",c);
}
