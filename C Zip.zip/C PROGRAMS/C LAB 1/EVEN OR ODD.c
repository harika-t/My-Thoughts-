#include<stdio.h>
main()
{ int n;
printf("Enter the value of n:");
scanf("%d",&n);
if(n%2==0)
{
	printf("The number %d is even",n);
}
else
{
	printf("The number %d is odd",n);
}
}
