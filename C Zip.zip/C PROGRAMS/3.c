#include<stdio.h>
void fun_1(char *s1,char *s2)
{
	char *temp;
	temp=s1;
	s1=s2;
	s2=temp;
}
void fun_2(char **s2,char **s1)
{
	char *temp;
	temp=*s1;
	*s1=*s2;
	*s2=temp;
}
main()
{
	char *str1="Hi",*str2="Bye";
	fun_1(str1,str2);
	printf("%s%s",str1,str2);
	fun_2(&str1,&str2);
	printf("%s%s",str1,str2);
	
}
