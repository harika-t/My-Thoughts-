#include<graphics.h>

int main( ){
        initwindow( 700 , 700 , "MY First Program");
        circle(200, 200, 150);
        getch();
        return 0;
}
