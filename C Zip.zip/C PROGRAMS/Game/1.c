#include<graphics.h>
int main()
{
   int gd = DETECT, gm;

   initgraph(&gd, &gm, "C:\Program Files (x86)\Dev-Cpp\MinGW64\bin");
   closegraph();
   return 0;
}
