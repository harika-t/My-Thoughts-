#include<graphics.h>

int main( )
{
        initwindow( 700 , 700 , "MY First Program");
        circle(200, 200, 150);
        return 0;
}
