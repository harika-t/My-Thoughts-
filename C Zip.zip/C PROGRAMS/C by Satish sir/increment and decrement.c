#include<stdio.h>
main()
{int a=10;
printf(" --a is %d\n",--a);
printf("a-- is %d\n",a--);
printf("a++ is %d\n",a++);
printf("++a is %d",++a);
}
