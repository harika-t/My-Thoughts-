#include<stdio.h>
main()
{int a=10;
printf("Negative of a is %d",-a);
}
