#include<stdio.h>
main()
{
    printf("Hiii");
    printf("\nWelcome");
}
