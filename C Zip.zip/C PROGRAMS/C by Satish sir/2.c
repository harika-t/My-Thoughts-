#include<stdio.h>
main()
{int a,b,c;
printf("Enter a,b and c:");
scanf("%d%d%d",&a,&b,&c);
printf("a=%d,b=%d,c=%d",a,b,c); 
}
