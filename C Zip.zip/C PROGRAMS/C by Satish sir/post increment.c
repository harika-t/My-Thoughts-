#include<stdio.h>
main()
{int a=10;
printf("%d",a++);
}
