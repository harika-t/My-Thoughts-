#include<stdio.h>
main()
{const int x=20;
printf("%d",x++);
}
