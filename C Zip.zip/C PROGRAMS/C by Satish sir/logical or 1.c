#include<stdio.h>
main()
{int a=10,b=20;
printf("%d",(a>b)||(a==b));
}
