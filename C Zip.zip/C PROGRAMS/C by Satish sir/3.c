#include<stdio.h>
main()
{int a=6;
char b='h';
float c=9.5;
printf("Memory allocated for an integer is %d",sizeof(a));
printf("\nMemory allocated for a character is %d",sizeof(b));
printf("\nMemory allocated for a floating point value is %d",sizeof(c));
}
