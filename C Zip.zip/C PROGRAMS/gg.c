#include<stdio.h>
main()
{int b;
float a;
b=2.3;
a=b+2.9;
printf("%f",a);
}
