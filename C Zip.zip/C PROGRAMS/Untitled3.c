#include<stdio.h>
main()
{int sum,n,i;
printf("enter n value");
scanf("%d\n",&n);
sum=0;
i=1;
while(i<=n)
{
	sum=sum+i;
	i=i+1;
}
printf("sum of %d numbers %d",n,sum);
}
