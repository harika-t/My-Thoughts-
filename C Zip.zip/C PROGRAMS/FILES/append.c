#include<stdio.h>
int main()
{
FILE *fp;
char ch;

	fp=fopen("f2.txt","a");
fputs("\nappended data end of the file",fp);
	close(fp);

	printf("appended data sucessfully");
return 0;
}
