#include<stdio.h>
int main()
{
FILE *fp;
char ch;
int nl=1,nw=1,nc=0;
	fp=fopen("f2.txt","r");
while((ch=fgetc(fp))!=EOF)
{   nc++;   	 
if(ch=='\n')
nl++;
if(ch=='\t'||ch=='\n'||ch==' ')
nw++;
}
printf("Number of lines=%d",nl);
printf("\nNumber of words=%d",nw);
printf("\nNumber of characters=%d",nc);
	close(fp);

	printf("\nProgram excuted sucessfully");
return 0;
}
