#include<stdio.h>
#include<string.h>
int main()
{
FILE *fp;
char ch,line[50],word[10];
int flag=0;
	fp=fopen("f2.txt","r");
	printf("enter word to search=");
scanf("%s",word);

while (fgets(line , sizeof(line) , fp )!= NULL)
   {
      if (strstr(line , word )!= NULL)
      {
      	printf("word found in the file\n");
         printf("%s",line);
         flag=1;
      }
   }

if(flag==0)
printf("word not found");
	close(fp);
	

return 0;
}
