#include<stdio.h>
int main()
{
FILE *fp,*fp1;
char ch;
	fp=fopen("f2.txt","r");
	fp1=fopen("f3.txt","w");
while((ch=fgetc(fp))!=EOF)
{      
  	fputc(ch,fp1);
  	 
}
	close(fp);
	close(fp1);
	printf("File copied sucessfully");
return 0;
}
