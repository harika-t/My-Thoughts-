#include<stdio.h>
main()
{
   void addition() ; // function declaration
   addition() ; // function call 
}
void addition()  // function definition
{
   int num1, num2 ;
   printf("Enter any two integer numbers : ") ;
   scanf("%d%d", &num1, &num2);
   printf("Sum = %d", num1+num2 ) ;
}
