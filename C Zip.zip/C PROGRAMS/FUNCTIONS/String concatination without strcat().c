#include<stdio.h>
main()
{char str1[50],str2[50],stringcat();
printf("Enter string 1:");
gets(str1);
printf("Enter string 2:");
gets(str2);
stringcat(str1,str2);
printf("Concatinated string is %s",str1);
}
char stringcat(char str1[50],char str2[50])
{int i,l,j,count;
for(j=0;str1[j]!='\0';j++)
{
	l++;
}
for(i=0;str2[i]!='\0';i++)
{
	str1[l+i]=str2[i];
}
str1[l+i]='\0';
return str1[50];
}
