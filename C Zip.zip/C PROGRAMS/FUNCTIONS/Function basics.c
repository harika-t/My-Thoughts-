#include<stdio.h>
main()
{int a,b,sum(),result;
printf("Enter a and b:");
scanf("%d%d",&a,&b);
printf("\nHii");
result=sum(a,b);
printf("\nSum is %d",result);
printf("\nHellooo");
}
int sum(int a,int b)
{
    return a+b;
}
