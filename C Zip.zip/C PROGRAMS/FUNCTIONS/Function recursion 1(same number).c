#include<stdio.h>
main()
{ int n,fun();
printf("Enter number:");
scanf("%d",&n);
printf("%d",fun(n));
}
int fun(int n)
{if(n==1)
return 1;
else
return 1+fun(n-1);
}
