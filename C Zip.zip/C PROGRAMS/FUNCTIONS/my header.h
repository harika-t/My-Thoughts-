int add(int a,int b)
{
	return a+b;
}
int sub(int a,int b)
{
	return a-b;
}
int mul(int a,int b)
{
	return a*b;
}
int div(int a,int b)
{
	return a/b;
}
int fact(int n)
{
	if(n==0)
	return 1;
	else
	return n*fact(n-1);
}
void printf(int a[100],n)
{
	int i;
	for(i=0;i<n;i++)
	{
		scanf("")
	}
}
