#include<stdio.h>
main()
{char string1[50],stringupper(),stringlower(),string2[50];
printf("Enter string to be converted into upper case:");
gets(string1);
stringupper(string1);
printf("Converted string is %s\n",string1);
printf("\nEnter string to be converted into lower case:");
gets(string2);
stringlower(string2);
printf("\nConverted string is %s",string2);
}
char stringupper(char string[50])
{int i; 
for(i=0;string[i]!='\0';i++)
{if(string[i]>='a'&&string[i]<='z')
   string[i]=string[i]-32;
}
return string[50];
}
char stringlower(char string[50])
{int i;
for(i=0;string[i]!='\0';i++)
{
	if(string[i]>='A'&&string[i]<='Z')
	string[i]=string[i]+32;
}
return string[50];
}
