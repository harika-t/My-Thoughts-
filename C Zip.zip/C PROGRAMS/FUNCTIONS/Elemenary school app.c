#include<stdio.h>
#include<stdlib.h>
main()
{int a,b,c,d,i=1,e,k=0;
while(i<=10)
{    srand(time(NULL));
	a=rand()%10;
	b=rand()%10;
	d=rand()%10;
	if(d==0)
	{
		i++;
		printf("%d+%d is ",a,b);
		c=a+b;
		scanf("%d",&e);
		if(c==e)
		{
			printf("Correct!!!\n");
			k++;
		}
		else
		{
			printf("Wrong\n");
			for(;c!=e;)
			{
				printf("Please try again\n");
				scanf("%d",&e);
				if(c==e)
				printf("Correct\n");
			}
		}
	}
	else if(d==1)
	{
		i++;
		printf("%d-%d is ",a,b);
		c=a-b;
		scanf("%d",&e);
		if(c==e)
		{
			printf("Greattt!!!\n");
			k++;
		}
		else
		{
			printf("Wrong\n");
			for(;c!=e;)
			{
				printf("Please try again!!!");
				scanf("%d",&e);
				if(c==e)
				{
					printf("Correct\n");
				}
			}
		}
	}
	else if(d==2)
	{
		i++;
		printf("%d/%d is ",a,b);
		c=a/b;
		scanf("%d",&e);
		if(c==e)
		{
			printf("wohoooo correct!!!\n");
			k++;
		}
		else
		{
			printf("Wrong\n");
			for(;c!=e;)
			{
				printf("Please try again\n");
				scanf("%d",&e);
				if(c==e)
				{
					printf("Correct!!!\n");
				}
			}
		}
	}
}
printf("The number of correct answers are %d",k);
}
