#include<Stdio.h>
main()
{char str1[50],str2[50],stringcopy();
printf("Enter string to be copied:");
gets(str1);
stringcopy(str2,str1);
printf("Copied string is %s",str2);
}
char stringcopy(char str2[50],char str1[50])
{int i=0;
while(str1[i]!='\0')
{
	str2[i]=str1[i];
	i++;
}
str2[i]='\0';
return str2[50];
}
