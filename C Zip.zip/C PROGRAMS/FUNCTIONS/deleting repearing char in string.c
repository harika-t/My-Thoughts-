#include<stdio.h>
#include<string.h>
main()
{int i,j,l;
char s[20],c;
printf("Enter string:");
gets(s);
printf("Enter character to be deleted:\n");
scanf("%c",c);
l=strlen(s)-1;
for(i=0;i<=l;i++)
{
		if(s[i]==c)
		{  for(j=i;j<l;j++)
		  {
			s[i]=s[i+1];
		  }  
	}
}
puts(s);
}
