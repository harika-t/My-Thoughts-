#include<stdio.h>
main()
{ int n,m,fun();
printf("Enter number:");
scanf("%d",&n);
m=fun(n);
printf("%d",m);
}
int fun(int n)
{if(n==1)
return 1;
else
return 1+fun(n-1);
}
