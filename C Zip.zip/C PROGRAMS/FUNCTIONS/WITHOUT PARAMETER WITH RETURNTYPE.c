#include<stdio.h>
int harika();
main()
{int h;
   h=harika();
   printf("%d",h);
}
int harika()
{int r=10;
return r;
}
