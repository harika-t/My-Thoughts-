#include<stdio.h>
main()
{int gcd(),a,b,result;
printf("Enter two numbers to find GCD:");
scanf("%d%d",&a,&b);
result=gcd(a,b);
printf("The GCD of %d and %d is %d",a,b,result);
}
int gcd(int a,int b)
{
	while(a!=b)
	{
		if(a>b)
		return gcd(a-b,b);
		else
		return gcd(a,b-a);
	}return a;
}
