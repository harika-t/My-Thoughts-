#include<stdio.h>
main()
{char str1[50],str2[50];
int stringcmp();
printf("Enter string 1:");
gets(str1);
printf("Enter string 2:");
gets(str2);
if(stringcmp(str1,str2)==0)
{
	printf("Both strings are same");
}
else
printf("Both strings are not same");
}
int stringcmp(char str1[50],char str2[50])
{
	int i;
	for(i=0;str1[i]!='\0';i++)
	{
		if(str2[i]!=str1[i])
		return 1;
	}
	return 0;
}
