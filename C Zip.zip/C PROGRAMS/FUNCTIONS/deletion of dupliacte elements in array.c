#include<stdio.h>
main()
{int a[50],i,j,n,k;
printf("Enter number of elements:");
scanf("%d",&n);
printf("Enter elements into array:\n");
for(i=0;i<n;i++)
{
	scanf("%d",&a[i]);
}
for(i=0;i<n;i++)
{
	for(j=i+1;j<n;j++)
	{
		if(a[i]==a[j])
		{  
		    for(k=j;k<n;k++)
			  {
			    a[k]=a[k+1];
			}
			n--;
		}
	}
}
printf("New array is:\n");
for(i=0;i<n;i++)
{
	printf("%d\n",a[i]);
}
}
