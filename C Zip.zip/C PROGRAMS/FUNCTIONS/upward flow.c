#include<stdio.h>
main()
{int result,add();
result=add();
printf("Sum is %d",result);
}
int add()
{int a,b;
printf("Enter a and b:");
scanf("%d%d",&a,&b);
return a+b;
}
