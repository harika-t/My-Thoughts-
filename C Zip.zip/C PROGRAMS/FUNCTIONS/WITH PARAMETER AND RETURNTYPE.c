#include<stdio.h>
int add(int ,int );
main()
{int h=20,i=30,j;
j=add(h,i);
printf("Sum is %d",j);
}
int add(int a,int b)
{int r;
r=a+b;
return r;
}
