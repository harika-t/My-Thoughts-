#include<stdio.h>
void harika();
main()
{
	harika();
}
void harika()
{
	printf("Hiii");
}
