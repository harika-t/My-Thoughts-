#include<stdio.h>
main()
{int date,month,year;
printf("Enter date,month and year:");
scanf("%d%d%d",&date,&month,&year);
if(date==31&&(month==1||month==3||month==5||month==7||month==8||month==10))
{
  date=1,month++;
}
else if(date==30&&(month==4||month==6||month==9||month==11))
{
  date=1,month++;
}
else if(date==28&&(year%4==0&&year%100!=0||year%400==0))
{
  date++;
}
else if(date==28&&!(year%4==0&&year%100!=0||year%400==0))
{
  date=1,month++;
}
else if(date==29&&(year%4==0&&year%100!=0||year%400==0))
{
   date=1,month++;
}
else if(month==12&&date==31)
{
  date=1,month=1;year++;
}
else if(date<=30)
{
  date++;
}
else
{
  printf("Invalid");
}
printf("%d\t%d\t%d",date,month,year);
}
