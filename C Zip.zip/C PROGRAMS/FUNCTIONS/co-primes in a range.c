#include<stdio.h>
main()
{int gcd(int,int),a,b,result,i,j;
printf("Enter two numbers:");
scanf("%d%d",&a,&b);


for(i=a;i<=b;i++)
{
	for(j=i+1;j<=b;j++)
	{   result=gcd(i,j);
    	if(result==1)
         {
		   printf("\n(%d,%d) are co-primes",i,j);
          printf("\n(%d,%d) are co-primes",j,i);
         }
	}
}
}
int gcd(int a,int b)
{
	while(a!=b)
	{
		if(a>b)
		return gcd(a-b,b);
		else
		return gcd(a,b-a);
	}
	return a;
}
