#include<stdio.h>
#include<math.h>
#include<stdlib.h>
main()
{int a,b,result,divide(int ,int);
printf("Enter two numbers:");
scanf("%d%d",&a,&b);
result=divide(a,b);
printf("Division is %d",result);
}
int divide(int a,int b)
{int sign=1,quotient=0; 
if(b==0)
{
	printf("Error....Division is not possible");
	exit(1);
}
if(a*b<0)
{
	sign=-1;
}
a=abs(a),b=abs(b);
while(a>=b)
{
	a=a-b;
	quotient++;
}
printf("Remainder is %d\n",a);
return sign*quotient;
}
