#include<stdio.h>
main()
{int m,n,result,add(int,int);
printf("Enter a and b:");
scanf("%d%d",&m,&n);
result=add(m,n);
printf("Sum is %d",result);
}
int add(int m,int n)
{
	return m+n;
}
