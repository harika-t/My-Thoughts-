#include<stdio.h>
main()
{int n,f;
int fact(int);
printf("Enter number:");
scanf("%d",&n);
f=fact(n);
printf("Factorial is %d",f);
}
int fact(int n)
{if(n==0)
return 1;
else
return n*fact(n-1);
}
