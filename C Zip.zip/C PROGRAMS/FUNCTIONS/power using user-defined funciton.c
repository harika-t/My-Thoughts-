#include<stdio.h>
main()
{int b,e,result,power();
printf("Enter base and exponent:");
scanf("%d%d",&b,&e);
result=power(b,e);
printf("Value is %d",result);
}
int power(int base,int exp)
{
	if(exp==0)
	return 1;
	else
	return base*power(base,exp-1);
}
