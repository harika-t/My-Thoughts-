#include<stdio.h>
void add(int ,int );
main()
{int h=20,i=30;
add(h,i);
}
void add(int a,int b)
{int r;
r=a+b;
printf("Sum is %d",r);
}
