#include<stdio.h>
#include"my header.h"
main()
{int a,b,add(),n,fact();
printf("Enter two numbers:");
scanf("%d%d",&a,&b);
printf("Sum is %d",add(a,b));
printf("\nEnter number:");
scanf("%d",&n);
printf("Factorial is %d",fact(n));
}
