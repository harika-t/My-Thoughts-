#include<stdio.h>
main()
{char string[50],stringupper();
printf("Enter string to be converted into upper case:");
gets(string);
stringupper(string);
printf("Converted string is %s",string);
}
char stringupper(char string[50])
{int i; 
for(i=0;string[i]!='\0';i++)
{
   string[i]=string[i]-32;
}
return string[50];
}
