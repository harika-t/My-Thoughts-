#include<stdio.h>
main()
{int a,b,result,mul();
printf("Enter two numbers:");
scanf("%d%d",&a,&b);
result=mul(a,b);
printf("Multiplication is %d",result);
}
int mul(int a,int b)
{int i,result=0;
for(i=0;i<b;i++)
{
	result+=a;
}
return result;
}
