#include<stdio.h>
main()
{ int m,n;
void add(int,int);
printf("Enter values of m and n:");
scanf("%d%d",&m,&n);
printf("m is %d and n is %d",m,n);
add(m,n);
}
void add(int m,int n)
{
	printf("\nSum is %d",m+n);?
}
