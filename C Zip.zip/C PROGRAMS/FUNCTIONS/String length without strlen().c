#include<stdio.h>
main()
{char string[20];
int l,stringlength();
printf("Enter string:");
gets(string);
l=stringlength(string);
printf("Length of %s is %d",string,l);
}
int stringlength(char string[20])
{int i=0,count=0;
while(string[i]!='\0')
{
	count++;
	i++;
}
return count;
}
