#include<stdio.h>
main()
{ int a,b,c;
printf("The value of a and b are ");
scanf("%d,%d",&a,&b);
c=a+b;
printf("%d",c);
}
