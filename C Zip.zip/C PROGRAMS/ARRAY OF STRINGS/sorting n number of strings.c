#include<stdio.h>
#include<string.h>
main()
{
char a[50][20],temp[50];
int n,i,j;
printf("Enter number of strings:");
scanf("%d",&n);
printf("Enter strings:");
for(i=0;i<n;i++)
{
	scanf("%s",a[i]);
}
printf("Entered strings are:");
for(i=0;i<n;i++)
{
	printf("\n%s",a[i]);
}
for(i=0;i<n-1;i++)
{
	for(j=0;j<n-1-i;j++)
	{
		if(strcmp(a[j],a[j+1])>0)
		{
			strcpy(temp,a[j]);
			strcpy(a[j],a[j+1]);
			strcpy(a[j+1],temp);
		}
	}
}
printf("\nSorted strings are:");
for(i=0;i<n;i++)
{
	printf("\n%s",a[i]);
}
}
