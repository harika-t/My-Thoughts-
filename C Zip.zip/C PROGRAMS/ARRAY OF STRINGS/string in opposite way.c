#include<stdio.h>
#include<string.h>
main()
{char a[50],b[50];
int i,index,ws,we;
printf("Enter a string:");
gets(a);
index=0;
ws=strlen(a)-1;
we=strlen(a)-1;
while(ws>0)
{
	if(a[ws]==' ')
	{
		i=ws+1;
		while(i<=we)
		{
			b[index]=a[i];
			i++;
			index++;
		}
		b[index++]=' ';
		we=ws-1;
	}
	ws--;
}
for(i=0;i<=we;i++)
{
    b[index]=a[i];
	index++;	
}
b[index]='\0';
printf("%s",b);
}
