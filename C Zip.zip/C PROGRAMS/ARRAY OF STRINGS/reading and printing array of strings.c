#include<stdio.h>
main()
{char a[10][10];
int i,row;
printf("Enter number of rows:");
scanf("%d",&row);
printf("Enter elements:");
for(i=0;i<row;i++)
{
	scanf("%s",a[i]);
}
for(i=0;i<row;i++)
{
	printf("\n%s",a[i]);
}
}
