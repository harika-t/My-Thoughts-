#include<stdio.h>
main()
{char a[20][20];
int i,n,count=0;
printf("Enter number of strings:");
scanf("%d",&n);
printf("Enter strings:");
for(i=0;i<n;i++)
{
	scanf("%s",a[i]);
}
printf("The strings are:");
for(i=0;i<n;i++)
{
	printf("\n%s",a[i]);
}
printf("\nStrings starting with a and c are:");
for(i=0;i<n;i++)
{
if(a[i][0]=='c'||a[i][0]=='a')
{
   printf("\n%s",a[i]);
   count++;
}
}
if(count==0)
printf("\nNo strings starting with a and c are found");
}
