#include<stdio.h>
main()
{long int s=1;
while(s++<=1)
while(s++<=2);
printf("%ld",s);
}
