#include<stdio.h>
int count=0;
int calc(int a,int b)
{
	int c;
	count++;
	if(b==3)
	return a*a*a;
	else
	{
		c=calc(a,b/3);
		return c*c*c;
	}
	
}
main()
{
	calc(4,81);
	printf("%d",count);
	
}
