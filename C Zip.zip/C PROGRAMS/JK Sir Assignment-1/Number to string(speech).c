#include<stdio.h>
main()
{
	char a[10][10]={" ","One","Two","Three","Four","Five","Six","Seven","Eight","Nine"};
	char b[10][10]={"Ten","Eleven","Twleve","Thirteen","Fourteen","Fifteen","Sixteen","Seventeen","Eighteen","Nineteen"};
	char c[10][10]={"","Ten","Twenty","Thirty","Fourty","Fifty","Sixty","Seventy","Eighty","Ninety"};
	int n,h;
	printf("TIRUVEEDHULA HARIKA\nS170007\nCSE-2C\n");
	printf("Enter a number:");
	scanf("%d",&n);
	while(n!=0)
	{
		if(n>=1000)
		{
			h=n/1000;
			printf("%s Thousand ",a[h]);
			n=n%1000;
		}
		if(n>=100)
		{
			h=n/100;
			printf("%s Hundred ",a[h]);
			n=n%100;
			if(n>0)
			{
				printf("and ");
			}
		}
		if(n>19 && n<=100)
		{
			h=n/10;
			printf("%s",c[h]);
			n=n%10;
		}
		if(n<10)
		{
			printf("%s",a[n]);
			n=0;
		}
		if(n>=10 && n<20)
		{
			h=n%10;
			printf("%s",b[h]);
			n=0;
		}
	}
}
