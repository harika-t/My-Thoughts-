#include<stdio.h>
main()
{
	int n,k=0,count_1=0,count_2=0,x,y;
	printf("TIRUVEEDHULA HARIKA\nS170007\nCSE-2C\n");
	printf("Enter a number:");
	scanf("%d",&n);
	while(n!=0)
	{
		k=k*10+(n%10);
		n=n/10;
		count_1+=1;
	}
	y=k;
	while(k!=0)
	{
		count_2+=1;
		k=k/10;
	}
	
	x=count_1-count_2;
	
	while(y!=0)
	{
		switch(y%10)
		{
			case 0: printf("Zero ");
			        break;
			case 1: printf("One ");
			        break;
			case 2: printf("Two ");
			        break;
			case 3: printf("Three ");
			        break;
			case 4: printf("Four ");
			        break;
			case 5: printf("Five ");
			        break;
			case 6: printf("Six ");
			        break;
			case 7: printf("Seven ");
			        break;
			case 8: printf("Eight ");
			        break;
			case 9: printf("Nine ");
		}
		y=y/10;
	}
	while(x>0)
	{
		printf("Zero ");
		x-=1;
	}
}
