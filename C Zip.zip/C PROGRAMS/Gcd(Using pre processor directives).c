#include<stdio.h>
#include"gcd.h"
main()
{int gcd(),a,b,result;
printf("Enter two numbers:");
scanf("%d%d",&a,&b);
result=gcd(a,b);
printf("GCD of %d and %d is %d",a,b,result);
}
