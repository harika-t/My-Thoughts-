import java.lang.*;
import java.util.*;
import java.util.Random;

       //int n1 = rand.nextInt(1000); 
        //int n2 = rand.nextInt(1000); 

class Calculator
{
	int r,ch,c;
	float f;
	int total[]={0,0,0,0};
	int correct[]={0,0,0,0};
	Random rand = new Random(); 
	void read()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("1 For Addition\n2 For Subtraction\n3 For Multiplication\n4 For Division\n5 For Summary\n6 For Exit.");
	    do
	    {
		int n1 = rand.nextInt(100); 
        		int n2 = rand.nextInt(100); 
		System.out.println("Enter Your Choice: ");
		ch=sc.nextInt();
		switch(ch)
		{
			case 1:
				c=0;
			          do{
				System.out.println("How much is the addition of n1: "+n1+" and n2: "+n2);
				System.out.println("Enter the answer: ");
				r=sc.nextInt();
				if(r==n1+n2)
				{
					System.out.println(" Excellent! ");
					if(c==0)
						correct[0]++;
				}
				else
				{
					if(r>=n2)
						System.out.println("No, please try again");
					else if(r<=n1)
						System.out.println("Sorry, wrong answer, try again");
					else
						System.out.println("Don’t lose hope, keep trying");	
				}
				c++;	
				
			             }
			             while(r!=n1+n2);
				total[0]++;
				break;
			case 2:
				c=0;
			          do{
				System.out.println("what is the value when n1 is subtracted from n2: "+n1+" and n2: "+n2);
				System.out.println("Enter the answer: ");
				r=sc.nextInt();
				if(r==n1-n2)
				{
					System.out.println(" Excellent! ");
					if(c==0)
						correct[1]++;
				}
				else
				{
					if(r>=n2)
						System.out.println("No, please try again");
					else if(r<=n1)
						System.out.println("Sorry, wrong answer, try again");
					else
						System.out.println("Don’t lose hope, keep trying");	
				}
				c++;	
				
			             }
			             while(r!=n1-n2);
				total[1]++;
				break;
			case 3:
				c=0;
			          do{
				System.out.println("multiplication of n1 and n2: "+n1+" and n2: "+n2);
				System.out.println("Enter the answer: ");
				r=sc.nextInt();
				if(r==n1*n2)
				{
					System.out.println(" Excellent! ");
					if(c==0)
						correct[2]++;
				}
				else
				{
					if(r>=n2)
						System.out.println("No, please try again");
					else if(r<=n1)
						System.out.println("Sorry, wrong answer, try again");
					else
						System.out.println("Don’t lose hope, keep trying");	
				}
				c++;	
				
			             }
			             while(r!=n1*n2);
				total[2]++;
				break;
			case 4:
				c=0;
			          do{
				System.out.println("the result of n1/n2: "+n1+" and n2: "+n2);
				System.out.println("Enter the answer: ");
				f=sc.nextFloat();
				if(f==n1/n2)
				{
					System.out.println(" Excellent! ");
					if(c==0)
						correct[3]++;
				}
				else
				{
					if(f>=n2)
						System.out.println("No, please try again");
					else if(f<=n1)
						System.out.println("Sorry, wrong answer, try again");
					else
						System.out.println("Don’t lose hope, keep trying");	
				}
				c++;	
				
			             }
			             while(f!=n1/n2);
				total[3]++;
				break;
			case 5:
				int  count=0;
				float p;
				float add=0,sub=0,mul=0,div=0,tot;
				if(total[0]>0)
					add=(correct[0]*100/total[0]);
				if(total[1]>0)
					sub=(correct[1]*100/total[1]);
				if(total[2]>0)
					mul=(correct[2]*100/total[2]);
				if(total[3]>0)
					div=(correct[3]*100/total[3]);
				for(int i=0;i<4;i++)
				{
					if(total[i]>0)
						count++;
				}
				if(count==0)
					System.out.println("No data found");
				else{
				tot=add+sub+mul+div;
				p=tot/count;
				System.out.println("Percentage of each operation");
				if(add>0)
					System.out.println("Percentage of each Addition: "+add);
				if(sub>0)
					System.out.println("Percentage of each Subtraction: "+sub);
				if(mul>0)
					System.out.println("Percentage of each Multiplication: "+mul);
				if(div>0)
					System.out.println("Percentage of each Division: "+div);	
				if(p>=75)
					System.out.println("Your Total Percentage is: "+p+" Good Keep It up!!!");
				else
					System.out.println("Your Total Percentage is: "+p+" Please approach Tutor to learn Arithmetic operations accurately");
				}
			           break;
			case 6:
				System.out.println("Successfully Exited");
				break;
			default:
				System.out.println("Please Enter valid Choice ");	
				break;
		}
	       }while(ch!=6);
	}
}


class StudentPerformance
{
	public static void main(String[] args)
	{
		Calculator ob = new Calculator();
		ob.read();
	}
}