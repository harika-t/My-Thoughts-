//To implement Bell triangle
import java.lang.*;
import java.util.*;
class Bell
{
   public static void main(String Vk[])
   {
       int a[][]=new int[50][50];
       a[0][0]=1;
       Scanner sc=new Scanner(System.in);
       System.out.print("Enter number of rows : ");
       int n=sc.nextInt();
       for(int i=1;i<n;i++)
       {
           for(int j=0;j<=i;j++)
           {
                if(j==0)
                  a[i][j]=a[i-1][i-1];
                else
                  a[i][j]=a[i][j-1]+a[i-1][j-1];
           }
       }
       for(int i=0;i<n;i++)
       {
           for(int j=0;j<=i;j++)
           {
               System.out.print(a[i][j]+"\t");
           }
          System.out.print("\n");
       }
    System.out.print("Number of equivalence relations are : "+a[n-1][n-1]);   
   }
}