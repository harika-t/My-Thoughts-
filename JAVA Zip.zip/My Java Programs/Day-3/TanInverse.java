//To implement tangent^-1 function
import java.lang.*;
import java.util.*;
class TanInverse
{
    public static void main(String Vk[])
    {
       Scanner sc=new Scanner(System.in);
       System.out.print("Enter x value in radians : ");
       double x=sc.nextDouble();
       System.out.print("Enter n value : ");
       int n=sc.nextInt();
       double sum=0;
       int sign=-1;
       if(x<=-1)
       {
           for(int i=1;i<=n;i=i+2)
           {
              sum=sum+sign*(1/(i*Math.pow(x,i)));
              sign=sign*(-1);
            }
        sum=(-3.14/2)+sum;
        sum=sum*((double)180.0/3.14);
       System.out.print("tan^-1("+x+") = "+sum);
       }
       else if(x<1)
       {
         for(int i=3;i<=n;i=i+2)
         {
           sum=sum+sign*(Math.pow(x,i)/i);
           sign=sign*(-1);
         }
        sum=sum*180/3.14;
       System.out.print("tan^-1("+x+") = "+sum);
       }  
       else 
       {
           for(int i=1;i<=n;i=i+2)
           {
             sum=sum+sign*(1/(i*Math.pow(x,i)));
             sign=sign*(-1);
           }
        sum=(3.14/2)+sum;
        sum=sum*((double)180.0/3.14);
       System.out.print("tan^-1("+x+") = "+sum);
       }
    }
}
