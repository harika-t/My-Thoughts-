//To implement square root
import java.util.Scanner;
class SquareRoot
{
   public static void main(String Vk[])
   {
      Scanner sc=new Scanner(System.in);
      System.out.print("Enter number : ");
      float f=sc.nextFloat();
      float sqrt=f/2;
      float temp=0;
      while(sqrt!=temp)
     {
       temp=sqrt;
       sqrt=((f/temp+temp)/2;
     } 	
      System.out.println("The square root of "+f+" is: "+sqrt);
   }
}