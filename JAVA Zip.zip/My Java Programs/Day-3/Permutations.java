//No. of k digit numbers from  m digits
import java.lang.*;
import java.util.*;
class B
{
  int factorial(int n)
  {
   int fact=1;
   while(n>0)
   {
    fact=fact*n;
    n--;
   }
   return fact;
  }
  void permutationsFunc()
  {
   int n,i,k,r,f=1;
   System.out.print("Enter the number of digits : ");
   Scanner sc=new Scanner(System.in);
   n=sc.nextInt();
   int a[]=new int[n];
   int b[]=new int[10];
   System.out.println("Enter the distinct elements : ");
   for(i=0;i<n;i++)
   {
      a[i]=sc.nextInt();
   }
   for(i=0;i<n;i++)
   {
    b[a[i]]++;
   }
   System.out.print("Enter the number of k digits you want want : ");
   k=sc.nextInt();
   for(i=1;i<10;i++)
   {
      if(b[i]>1)
      f=0;
   }
   if(f==1)
   {
   r=(factorial(n)/(factorial(n-k)*factorial(k)));
   System.out.println("the number of k digits formed is:"+r);
   }
   if(f==0)
   {
    int fact=1;
    for(i=0;i<10;i++)
    {
     fact=fact*factorial(b[i]);
    }
    r=(factorial(n)/fact);
    System.out.println("the number of k digits formed is:"+r);
   }
  }
}
class Permutations
{
  public static void main(String k[])
  {
    B b=new B();
    b.permutationsFunc();
  }
}