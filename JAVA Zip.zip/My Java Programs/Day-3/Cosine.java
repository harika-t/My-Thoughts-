//To implement cosine function
import java.lang.*;
import java.util.*;
class Cos
{
    void cosx()
    {
       Scanner sc=new Scanner(System.in);
       System.out.print("Enter x value in degrees : ");
       double x=sc.nextDouble();
       System.out.print("Enter n value : ");
       int n=sc.nextInt();
       double r= x*(3.14/180.0);
       double sum=1;
       int fact=1,i,sign=-1;
       for(i=2;i<=n;i=i+2)
       {
          fact=fact*i*(i-1);
          sum=sum+sign*(Math.pow(r,i)/fact);
          sign=sign*(-1);
       }
       System.out.print("cos("+x+") = "+sum);
   
    }
}
class Cosine
{
    public static void main(String Vk[])
    {
       Cos p=new Cos();
       p.cosx();
    }
}