//this is a program to implement a simple calculator application (+,-,*, /, %, calculate). (follow Feasible approach)
import java.lang.*;
import java.util.*;
class Calculator7{
	public static void main(String args[]){
		int operandl,operandr;
		char choice;
		Scanner scan=new Scanner(System.in);
	/*	System.out.println("\t Hey user here you can find the operations you can perform here: \n \t\t '+'->addition,'-'->substracton,'*'->multiplication,'/'->division,'%'->modulus");*/
		System.out.println("\n\t\t.....HEY GUYS ..... WELCOME TO MY Calculator..... \n");
		operandl=scan.nextInt();
//		System.out.println("Enter the operator to perform the operation you want  :=");
		choice=scan.next().charAt(0);
		operandr=scan.nextInt();
		switch(choice){
			case '+':
				System.out.print(operandl+operandr);
				break;
			case '-':
				2wsSystem.out.print(operandl-operandr);
				break;
			case '*':
				System.out.print(operandl*operandr);
				break;
			case '/':
				if(operandr!=0)
					System.out.print(operandl/operandr);
				else
					System.out.println("Cant possible division");
				break;
			case '%':
				if(operandr!=0)
					System.out.print(operandl%operandr);
				else
					System.out.println("Cant possible division");
				break;	
			default:
				System.out.println("\nEnter valid Operator");
				
		}
		
		
		
	}

}
