import java.lang.*;
import java.util.*;
class Arithmatic
{
  void negativewords(int z)
  {
    if(z==1)
     System.out.println("No.please try again");
    else if(z==2)
    System.out.println("Sorry wrong result, try again");
    else if(z==3)
    System.out.println("Better luck next time");
    else
    System.out.println("dont loose hope");
   return;
  }
  void positivewords(int z)
  {
    if(z==1)
     System.out.println("Very Good!");
    else if(z==2)
    System.out.println("Excellent!!");
    else if(z==3)
    System.out.println("Nice Work!");
    else
    System.out.println("Keep it ip!");
   return;
  }
  void calculation()
  {
    int n,res,a,b,c,d,p,q;
    a=b=c=d=0;
    double t1,t2,t3,t4,per=0;
    t1=t2=t3=t4=0;
    Random r=new Random();
    System.out.println("welcome-test your skills");
    System.out.print("1)addition\n2)substraction\n3)multiplication\n4)division\n5)exit\n");
    Scanner sc=new Scanner(System.in);
    int c1,c2,c3,c4;
    c1=c2=c3=c4=0;
    while(true)
    {
      System.out.println("enter your choice:");
      n=sc.nextInt();
      switch(n)
      {
        case 1: p=r.nextInt(99);
               q=r.nextInt(99);
               t1++;
               System.out.println("how much is addition of"+p+"and"+q);
               res=sc.nextInt();
               if(res==(p+q))
               {
               a=1;
               positivewords(r.nextInt(4));
               if(a==1)
               c1++;
               }
               else
               { 
                a=0;
               while(res!=(p+q))
               {
                negativewords(r.nextInt(4));
                res=sc.nextInt();
               }
               System.out.println("correct answer");
               }
               break;
       case 2:p=r.nextInt(99);
               q=r.nextInt(99);
               t2++;
               System.out.println("what is the value when"+p+"substracted from"+q);
               res=sc.nextInt();
               if(res==(q-p))
               {
                b=1;
               positivewords(r.nextInt(4));
               if(b==1)
               c2++;
               }
               else
               { 
               b=0;
               while(res!=(q-p))
               {
                negativewords(r.nextInt(4));
                res=sc.nextInt();
               }
               System.out.println("correct answer");
               }
               break;
       case 3:p=r.nextInt(99);
               q=r.nextInt(99);
               t3++;
               System.out.println("what is the valye when"+p+"and"+q+"are multiplied");
               res=sc.nextInt();
               if(res==(p*q))
               {
               c=1;
               positivewords(r.nextInt(4));
               if(c==1)
               c3++;
               }
               else
               { 
                c=0;
               while(res!=(p*q))
               {
                negativewords(r.nextInt(4));
                res=sc.nextInt();
               }
               System.out.println("correct answer");
               }
               break;
       case 4:p=r.nextInt(99);
               q=r.nextInt(99);
               t4++;
               System.out.println("what is the value when"+p+"divides"+q);
               res=sc.nextInt();
               if(res==(q/p))
               {
                d=1;
                positivewords(r.nextInt(4));
               if(d==1)
               c4++;
               }
               else
               {
                d=0;
               while(res!=(q/p))
               {
                negativewords(r.nextInt(4));
                res=sc.nextInt();
               }
               System.out.println("correct answer");
               }
               break;
       case 5:System.out.println("Total percentage:"+((c1/t1)*100));
              if(t1!=0)
              {
              t1=(c1/t1)*100;c1=0;
              }
              if(t2!=0)
              {
              t2=(c2/t2)*100;c1++;
              }
              if(t3!=0)
              {
              t3=(c3/t3)*100;c1++;
              }
              if(t4!=0)
              {
              t4=(c4/t4)*100;c1++;
              }
              per=t1+t2+t3+t4;
              per=per/(c1+1);
              System.out.println("Total percentage:"+per+"%");
              if(per>=75)
              System.out.println("Good keep it up");
              else
              System.out.println("Approach tutor to improve your skills");
              System.exit(0);
              break;
       default:System.out.println("wrong choice");
      }
    }
  }
}
class StudentCode
{
  public static void main(String k[])
 {
   Arithmatic o=new Arithmatic();
   o.calculation();
 }
}