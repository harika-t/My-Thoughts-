//To implement sine function
import java.lang.*;
import java.util.*;
class Sin
{
    void sinx()
    {
       Scanner sc=new Scanner(System.in);
       System.out.print("Enter x value in degrees : ");
       double x=sc.nextDouble();
       System.out.print("Enter n value : ");
       int n=sc.nextInt();
       double r= x*(3.14/180.0);
       double sum=r;
       int fact=1,i,sign=-1;
       for(i=3;i<=n;i=i+2)
       {
          fact=fact*i*(i-1);
          sum=sum+sign*(Math.pow(r,i)/fact);
          sign=sign*(-1);
       }
       System.out.print("sin("+x+") = "+sum);
   
    }
}
class Sine
{
    public static void main(String Vk[])
    {
       Sin p=new Sin();
       p.sinx();
    }
}