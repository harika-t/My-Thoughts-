//To implement sin^-1 x
import java.lang.*;
import java.util.*;
class SineInverse
{
    public static void main(String Vk[])
    {
       Scanner sc=new Scanner(System.in);
       System.out.print("Enter x value in radians : ");
       double x=sc.nextDouble();
       System.out.print("Enter n value : ");
       int n=sc.nextInt();
       double sum=x;
       double d=1;
       for(int i=3;i<=n;i=i+2)
       {
          d=d*((double)(i-2)/(i-1));
          sum=sum+(Math.pow(x,i)/i)*d;
       }
        sum=sum*((double)180.0/3.14);
       System.out.print("sin^-1("+x+") = "+sum);
   
    }
}
