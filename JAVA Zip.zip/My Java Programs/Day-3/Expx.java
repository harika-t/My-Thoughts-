//To implement e^x;
import java.lang.*;
import java.util.*;
class exp
{
   void input()
   {
       Scanner sc=new Scanner(System.in);
       System.out.print("Enter x  : ");
       int x=sc.nextInt();
       System.out.print("Enter n value : ");
       int n=sc.nextInt();
       double sum=1+x;
       int fact=1,i;
       for(i=2;i<=n;i++)
       {
          fact=fact*i;
          sum=sum+(Math.pow(x,i)/fact);
       }
       System.out.print("e^"+x+" = "+sum);
   
   }
}
class Expx
{
    public static void main(String Vk[])
    {
       exp e=new exp();
       e.input();
    }
}