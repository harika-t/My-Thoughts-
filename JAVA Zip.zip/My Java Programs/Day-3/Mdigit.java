import java.lang.*;
import java.util.*;

class ReadMdigit
{
	int x,m,n,k,c,r,i,f=1,wr=1,wtr=1,wrz=1,wtrz=1;
	static int s=1;
	void read()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the M digit number: ");
		m=sc.nextInt();
		System.out.println("Enter the k digit number: ");
		k=sc.nextInt();
		int countArray[]={0,0,0,0,0,0,0,0,0,0};
		n=m;
 		c=0;
		while(n!=0)
		{
			r=n%10;
			countArray[r]++;
			c++;
			n=n/10;
		}
		if(c<k)
			System.out.println("Not Possible");
		else
		{
		// with repetition
		withrep(k,c,countArray);
		// without repetition
     		withoutrep(k,c,countArray);
		// without repetition ZERO
		withoutrepzero(k,c,countArray);
		//with repitition with zero
		withrepzero(k,c,countArray);
		// repeated 
		repeated(c, k,countArray);
		}
	}

// without repitition

	void withoutrep(int k, int c, int countArray[])
	{
		if(countArray[0]==0)
		{
			while(k!=0)
			{
				wr=wr*c;
				c--;
				k--;
			}
			System.out.println("Without repetition we can arrange the number in : "+wr + " ways");
		}	
	}

// with repetition 

	void withrep(int k, int c, int countArray[])
	{
		if(countArray[0]==0)
		{
			while(k!=0)
			{
				wtr=wtr*c;
				k--;
			}
			System.out.println("With Repetition we can arrange the number in: "+wtr+ " ways");
		}
	}

// without repetition with zero

	void withoutrepzero(int k, int c, int countArray[])
	{
		c--;
		int z=1;
		if(countArray[0]==1)
		{
			while(k!=0)
			{
				wrz=wrz*c;
				if(z==1)
					c=c;
				else
					c--;
				z--;
				k--;
			}
			System.out.println("Without Repetition with Zero we can arrange this in: "+wrz+ " ways");
		}
	}

// with repetition with Zero


	void withrepzero(int k, int c, int countArray[])
	{
		int z=1;
		c--;
		if(countArray[0]==1)
		{
			while(k!=0)
			{
				wtrz=wtrz*c;
				k--;
				if(z==1){
				c++;
				}
				z++;
			}
			System.out.println("With Repetition with Zero we can arrange this in: "+wtrz+" ways");
		}
	}

// number is repeated 

	void repeated(int c, int k, int countArray[])
	{
		int x,y,s=1,one;
		float res;
		for(i=1;i<10;i++)
		{
			if(countArray[i]>1)
			{
				one=countArray[i];
				x=fact(one);
				s=s*x;
			}
		}
		y=fact(c)/fact(c-k);
		res=(float)y/s;
		System.out.println("Repeated number of ways: "+res);
	}

// factorial

	int fact(int n)
	{
		if(n==0 || n==1)
			return 1;
		else
  			return n*fact(n-1);
	}



}


class Mdigit
{
	public static void main(String args[])
	{
		ReadMdigit ob = new ReadMdigit();
		ob.read();	
	}
}