//This is a program to find the Square root of a number with out using... square root function
import java.lang.*;
import java.util.*;
class Sqrts{
	public static void main(String args[]){
	int num;
	double root;
	Scanner read=new Scanner(System.in);
	System.out.println("Enter the number you want to find Square root:");
	num=read.nextInt();
	root=Math.pow(num,(float)1/2);
	System.out.println(root);
	}

}
