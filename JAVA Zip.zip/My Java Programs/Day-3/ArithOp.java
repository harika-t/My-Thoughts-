//To perform arithmetic evaluation system
import java.lang.*;
import java.util.*;
class ArithOp
{
   public static void main(String Vk[])
   {
      Random r=new Random();
      Scanner sc=new Scanner(System.in);
       int add=0,sub=0,counta=0,counts=0,mul=0,countm=0,div=0,countd=0,sum=0,c=0;
        System.out.print("Arithmetic Operations are :\n0.Addition\n1.Subtraction\n2.Multiplication\n3.Division\n4.Summary\n5.Exit\n");
       while(true)
       {
          switch(r.nextInt(6))
          {
              case 0:int a=r.nextInt(100);
                     int b=r.nextInt(100);
                     int ans;
                     System.out.println("How much is addition of "+a+" and "+b+" ??");
                      do
                      {
                        ans=sc.nextInt();
                         if(ans!=(a+b))
                           { 
                              add++;
                              System.out.println("Don't lose hope,have faith and try again");
                           }
                         else
                            { c++;
                               System.out.println("Very good..Keep it up!!!");
                            }
                         counta++;
                      } while(ans!=(a+b));           
                       break;
             case 1:int a1=r.nextInt(100);
                     int b1=r.nextInt(100);
                     int ans1;
                     System.out.println("What is the value when "+b1+" is subtracted from "+a1+" ??");
                      do
                      {
                        ans1=sc.nextInt();
                         if(ans1!=(a1-b1))
                           { 
                              sub++;
                              System.out.println("No....please try again");
                           }
                         else
                           { c++;
                              System.out.println("Nice work!!!");
                           }
                         counts++;
                      } while(ans1!=(a1-b1));           
                       break;
              case 2: int a2=r.nextInt(100);
                     int b2=r.nextInt(100);
                     int ans2;
                     System.out.println("Multiplication of "+a2+" and "+b2+" is ??");
                      do
                      {
                        ans2=sc.nextInt();
                         if(ans2!=(a2*b2))
                           { 
                              mul++;
                              System.out.println("Wrong........try again once more");
                           }
                         else
                           { c++;
                              System.out.println("Excellent!!!");
                           }
                        countm++;
                      } while(ans2!=(a2*b2));           
                       break;
               case 3: int a3=r.nextInt(100);
                     int b3=r.nextInt(100);
                     int ans3;
                      if(b3==0)
                          break;
                      else
                     { 
                         System.out.println("The result of "+a3+"/"+b3+" is ??");
                      do
                      {
                        ans3=sc.nextInt();
                         if(ans3!=(a3/b3))
                           { 
                              div++;
                              System.out.println("Sorry..wrong answer!!Try again");
                           }
                         else
                           { c++;
                              System.out.println("Awesome!!!");
                           }
                        countd++;
                      } while(ans3!=(a3/b3));   
                     }        
                       break;
              case 4: System.out.println("Your summary is : ");
                      System.out.println("Number of operations performed :");
                      System.out.print("Additon : "+counta+"\n");
                      System.out.print("Subtraction : "+counts+"\n");
                      System.out.print("Multiplication : "+countm+"\n");
                      System.out.print("Division : "+countd+"\n");
                      /*System.out.println("Percentage of result of first correct answer of each operation");
                      if(add==0||sub==0||mul==0||div==0)
                        sum++;*/
                      System.out.println("Overall percentage");
                        System.out.println((double)(c)/(add+sub+mul+div+4)*100+" %");
              case 5:System.exit(0);
              //default:System.out.print("Invalid choice\n");          
          }
       }
   }
}