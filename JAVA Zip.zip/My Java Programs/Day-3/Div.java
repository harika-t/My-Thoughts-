//To perform proper division
import java.lang.*;
import java.util.*;
class Div
{
   public static void main(String Vk[])
   { 
     int f=0,r=0,q=0;
      Scanner sc=new Scanner(System.in);
      System.out.print("Enter numbers to perform division : ");
      int a=sc.nextInt();
      int b=sc.nextInt();
      if(b==0)
      {
         System.out.print("Dividing by zero leads to undefined value ");
      }
      else
      {
                  r=a%b;
                  q=a/b;
          for(int i=0;i<6;i++)
          {
             if(r==0)
                 break;
              r=r*10;
              f=f*10+(r/b);
              r=r%b;
               
          }
        System.out.print(a+"/"+b+"= "+q+"."+f);
      }
   }
}