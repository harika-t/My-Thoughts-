import java.io.*;
public class InputFile
{
   public static void main(String Jk[]) throws Exception
   {
       //FileInputStream fis=new FileInputStream("Add.java");
       /*int i=fis.read();
       System.out.println("Data is "+i);
       System.out.println("Data is "+(char)i);*/
       /*int i=0;
       while((i=fis.read())!=-1)
       {
           System.out.print((char)i);
       }*/
       /*File f=new File("abc.txt");
       f.createNewFile();
       FileInputStream fis=new FileInputStream(f);
       int i=0;
       while((i=fis.read())!=-1)
       {
           System.out.print((char)i);
       }*/
       FileInputStream fis=new FileInputStream("Add.java");
       byte[] b=new byte[fis.available()];
       fis.read(b);
       /*for(int k=0;k<b.length;k++)
       {
           System.out.print((char)b[k]);
       }*/
       String data=new String(b);
       System.out.print(data);
      fis.close();
   }
}