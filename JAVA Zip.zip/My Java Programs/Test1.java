public class Test1
{
   public static void main(String[] args)
   {
      Test1 t=new Test1();
      System.out.println("Address : "+t.hashCode());
      t=null;
      System.gc();
      Test1 t1=new Test1();
      t1=null;
      System.gc();
   }
   protected void finalize()
   {
      System.out.println("Finalize called");
   }
}