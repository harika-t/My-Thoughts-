package arithmetic;
public class Add
{
   public double add(double a,double b)
   {
      return a+b;
   }
}