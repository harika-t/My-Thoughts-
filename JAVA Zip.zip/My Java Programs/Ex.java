import java.lang.*;
import java.util.Scanner;
class Ex
{
   public static void main(String Jk[])
   {
       Scanner sc=new Scanner(System.in);
       int n=sc.nextInt();
       int arr[]={4,6,9,10,12,14,15,16,18,20,22,24,25,26,27,28,30,32,33,35,36,38,39,40};
       System.out.print(arr[n-1]);
   }
}