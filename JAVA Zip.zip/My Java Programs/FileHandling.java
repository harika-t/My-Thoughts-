import java.io.File;
class FileHandling
{
   public static void main(String Jk[]) throws Exception
   {
       /*File f=new File("abc.txt");
       System.out.println(f.exists());
       System.out.println(f.createNewFile());
       System.out.println(f.exists());
       System.out.println(f.createNewFile());
       File f1=new File("E://My Java Programs//in","abc1.txt");//'\' needs to be replaced with '//' in file paths
       System.out.println(f1.exists());
       System.out.println(f1.createNewFile());
       System.out.println(f1.exists());
       System.out.println(f1.createNewFile());
       File f=new File("Virat");
       f.mkdir();
       File f1=new File(f,"cse.txt");//Not physically created
       System.out.println("Directory created");
       f1.createNewFile();//Created

       
       File f=new File("cse.txt");
       f.createNewFile();
       System.out.println("Size : "+f.length());
       System.out.println("File : "+f.isFile());*/

       File f=new File("E://My Java Programs//Virat");
       String[] s=f.list();
       System.out.println("The list of files and folders are : ");
       for(int i=0;i<s.length;i++)
       {
          System.out.println(s[i]);
       }
       System.out.println("The list of files are : ");
       int files=0,directory=0;
       for(int i=0;i<s.length;i++)
       {
          File f1=new File(f,s[i]);
          if(f1.isFile())
          {
             System.out.println(s[i]);
               files++;
          }
          else
            directory++;
       }
      System.out.println("Total number of files are : "+s.length);
      System.out.println("Total number of files are : "+files);
      System.out.println("Total number of directories are : "+directory);
   }
}