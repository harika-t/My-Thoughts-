package beta;
public class Virat
{
   public static int d=10;
}