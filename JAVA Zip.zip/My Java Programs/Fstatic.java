import java.lang.*;
class Fstatic
{
   void display()
   {
      display1(); //Rule 2
      System.out.println("Instance display method");
   }
   static void show()
   {
      System.out.println("Static show method");
   }
   void display1()
   {
      Fstatic.show();//Rule 4
      System.out.println("Instance display1 method");
   }
   public static void main(String Jk[])//Program driver
   { 
      System.out.println("Start of main method");
      show();//Rule 1
      Fstatic f=new Fstatic();
      f.display();
      System.out.println("End of main method");
   }
}