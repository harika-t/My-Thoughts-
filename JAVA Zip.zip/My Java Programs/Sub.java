package arithmetic.ar2;
import java.util.Scanner;
public class Sub
{
   public void sub()
   {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter two values : ");
      int a=sc.nextInt();
      int b=sc.nextInt();
     System.out.println("Result : "+(a-b));
   }
}