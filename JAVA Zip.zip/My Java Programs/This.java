import java.lang.*;
class Jk
{
   int x,y;
   Jk(int x,int y)
   {
      this.x=x;this.y=y;
 
   }
   
   Jk(int x)
   { 
      x=this.x+y;
      System.out.println("X value is : "+x);
      y=this.x+y;
      System.out.println("y value is : "+y);
      y=x+y;
      System.out.println("y value is : "+y);
   }
   
}
class This
{
   public static void main(String Jk[])
   {
      Jk j=new Jk(5,6);
        Jk j1=new Jk(10);//x=0,y=0
   }
}