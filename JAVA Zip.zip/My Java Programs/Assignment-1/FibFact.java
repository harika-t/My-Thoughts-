//To find fibonacci series,factorial of the given number,armstrong number or not,palindrome or not
import java.lang.*;
import java.util.Scanner;
class Number
{  int i;
   void fib(int x)
   {
      int a=0,b=1,c;
      System.out.println(a);
      for(int i=1;i<=x;i++)
      {
         c=a+b;
         a=b;
         b=c;
         if(a<=x)
         {
            i=a;
            display(a);
         }
      }
   }
   void display(int a)
   {
      System.out.println(a);
   }
   void fact(int f)
   {
       int n=1;
       for(int i=2;i<=f;i++)
       {
          n=n*i;
       }
       display(n);
   }
   void armstrong(int n)
   {
       int i,temp=n,j=0;
       while(temp>0)
       {
           int rem=temp%10;
           j+=rem*rem*rem;
           temp=temp/10;
       }
       display1(n,j);
   }
   void display1(int n,int j)
   {
       if(j==n)
          System.out.print(n+" is an armstrong number\n");
       else
         System.out.print(n+" is not an armstrong number\n");
   }
   void palindrome(int n)
   {
       int temp,i,rev=0,rem;
       temp=n;
       while(n>0)
       {
          rem=n%10;
          rev=rev*10+rem;
          n=n/10;
       }
       display2(temp,rev);
   }
   void display2(int temp,int rev)
   {
       if(temp==rev)
          System.out.print(temp+" is a palindrome");
       else
         System.out.print(temp+" is not a palindrome");
   }
   
}
class FibFact
{
   public static void main(String Jk[])
   {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter number upto which Fibonacci Series is required : ");
      int h=sc.nextInt();
      Number n=new Number();
      System.out.println("Fibonacci Series upto "+h+" is : ");
      n.fib(h);
      System.out.println("Enter number to find factorial : ");
      int i=sc.nextInt();
      System.out.println("Factorial of  "+i+" is : ");
      n.fact(i);
      System.out.println("Enter number to find whether it is an Armstrong Number or not : ");
      int j=sc.nextInt();
      n.armstrong(j);
      System.out.println("Enter number to find whether it is a Palindrome or not : ");
      int k=sc.nextInt();
      n.palindrome(k);
   }
}