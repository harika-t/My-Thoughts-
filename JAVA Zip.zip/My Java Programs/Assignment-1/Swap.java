//Swap two integer values in three ways
import java.lang.*;
class Number
{
   int temp,a,b;
   void displayBeforeSwap(int a,int b)
   {
      System.out.println("Values before swapping are : a = "+a);
      System.out.println("Values before swapping are : b = "+b);  
   }
   void swapUsingTemp(int x,int y)
   {
      displayBeforeSwap(x,y);
      a=x;b=y;
      temp=a;
      a=b;
      b=temp;
      System.out.println("Here...Values are swapped using a third (temporary) variable");
      displayAfterSwap();
   }
   void displayAfterSwap()
   {
      System.out.println("Values after swapping are : a = "+a);
      System.out.println("Values after swapping are : b = "+b);
   }
   void swap(int x,int y)
   {
      a=x;b=y;
      a=a+b;
      b=a-b;
      a=a-b;
      System.out.println("Here...Values are swapped without using a third (temporary) variable");
      displayAfterSwap();
   }
   void swapUsingXor(int x,int y)
   {
      a=x;b=y;
      a=a^b;
      b=a^b;
      a=a^b;
      System.out.println("Here...Values are swapped using Bitwise X-OR operator");
      displayAfterSwap();
   }
}
class Swap
{
   public static void main(String Jk[])
   { 
      if(Jk.length!=2)
      {
         System.out.println("Please enter two integer values!!!");
      }
      else
      {
         int a=Integer.parseInt(Jk[0]);
         int b=Integer.parseInt(Jk[1]);
         Number n=new Number();
         n.swapUsingTemp(a,b);
         n.swap(a,b);
         n.swapUsingXor(a,b);
      }
   }
}