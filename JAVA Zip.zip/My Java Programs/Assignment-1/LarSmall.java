//To print largest,second largest,smallest and second smallest element in the given array
import java.lang.*;
import java.util.Scanner;
class Array
{
   void input()
   {
      Scanner sc=new Scanner(System.in);
      System.out.print("Enter the number of elements : ");
      int n=sc.nextInt();
      int a[]=new int[n];
      System.out.print("Enter "+n+" elements : ");
      for(int i=0;i<n;i++)
      {
         a[i]=sc.nextInt();
      }
    large(a,n);
    small(a,n);
   }
   void large(int a[],int n)
   {
       int l=a[0];
      for(int i=1;i<n;i++)
      {
	  if(a[i]>l)
	    l=a[i];
      }
    System.out.println("The largest element in the array is : "+l);
    sLarge(a,n,l);
   }
   void sLarge(int a[],int n,int l)
   {
      int j=a[1];
      for(int i=0;i<n;i++)
      {
	if(a[i]!=l)
	{
           if(a[i]>j)
           {
              j=a[i];
	   }
	}
      }
    System.out.println("The second largest element in the array is : "+j);
   }
   void small(int a[],int n)
   {
      int s=a[0];
      for(int i=1;i<n;i++)
      {
	 if(a[i]<s)
	 s=a[i];
      }
    System.out.println("The smallest element in the array is : "+s);
    sSmall(a,n,s);
   }
   void sSmall(int a[],int n,int s)
   {
      int r=a[1];
      for(int i=0;i<n;i++)
      {
	 if(a[i]!=s)
	 {
	    if(a[i]<r)
	    {
		r=a[i];
	    }
	 }
      }
    System.out.println("The second smallest element in the array is : "+r);
   }
}
class LarSmall
{
   public static void main(String Jk[])
   {
      Array a=new Array();
      a.input();
   }
}