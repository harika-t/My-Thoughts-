//Accept float value from cmd and display square of it
import java.lang.*;
class Number
{  
   float result,r;
   void square(float h)
   {
      r=h;
      calculate();
   }
   void calculate()
   {
      result=r*r;
      display();
   }
   void display()
   {
     System.out.println("The square of the given value is : "+result);
   }
}
class Square
{
   public static void main(String Jk[])
   {
     if(Jk.length!=1)
     {
        System.out.println("Please enter one float value!!!");
     }
     else
     {
       float f=Float.parseFloat(Jk[0]);
       Number n=new Number();
       n.square(f);
     }
   }
}