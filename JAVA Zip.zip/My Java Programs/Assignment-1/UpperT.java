//To check whether the given matrix is an upper triangular matrix
import java.lang.*;
import java.util.Scanner;
class Matrix
{
    void input()
    {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the number of rows of array : ");
        int row=sc.nextInt();
        System.out.print("Enter the number of columns of array : ");
        int col=sc.nextInt();
        int a[][]=new int[row][col];
        System.out.println("Enter the elements of array:");
        for(int i=0;i<row;i++)
        {
            for(int j=0;j<col;j++)
            {
                a[i][j]=sc.nextInt();
            }
        }
         display1(a,row,col);
     }
     void display1(int a[][],int r1,int c1) 
      {
           System.out.println("Elements of array are:");
          for(int i=0;i<r1;i++)
          {
                for(int j=0;j<c1;j++)
                {
                      System.out.print(a[i][j]+"\t");
                }
             System.out.print("\n");
          }
       upper(a,r1,c1);
      }
     void upper(int a[][],int row,int col)
     {
        int c=0;
        for(int i=0;i<row;i++)
        {
            for(int j=0;j<col;j++)
            {
                if(i>j)
                {
                     if(a[i][j]==0)
                         c=1;
                     else
                         c=0; 
                }
             }
         }
        display(c);
     }
   void display(int c)
   {
       if(c==1)
          System.out.print("The given matrix is an upper triangular matrix");
       else
          System.out.print("The given matrix is not an upper triangular matrix");
   }
}
class UpperT
{
   public static void main(String Jk[])
   {
      Matrix m=new Matrix();
      m.input();
   }
}