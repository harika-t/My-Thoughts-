import java.lang.*;
import java.util.Scanner;
class Matrix
{
      void input()
      {
          Scanner sc=new Scanner(System.in);
          System.out.print("Enter the number of rows of array : ");
          int row=sc.nextInt();
          System.out.print("Enter the number of columns of array : ");
          int col=sc.nextInt();
          int a[][]=new int[row][col];
          System.out.println("Enter the elements of array : ");
          for(int i=0;i<row;i++)
          {
             for(int j=0;j<col;j++)
             {
                 a[i][j]=sc.nextInt();
             }
          }
         display(a,row,col);
      }
      void display(int a[][],int row,int col) 
      {
           System.out.println("Elements of the  array are : ");
           for(int i=0;i<row;i++)
           {
               for(int j=0;j<col;j++)
               {
                  System.out.print(a[i][j]+"\t");
               }
             System.out.print("\n");
            }
         identity(a,row,col);
      }
      void identity(int a[][],int row,int col) 
      {
          int flag1=0,flag2=0;
          for(int i=0;i<row;i++)
          {
              for(int j=0;j<col;j++)
              {
                  if(i==j)
                  {
                      if(a[i][j]==1)
                         flag1=1;
                      else 
                         flag1=0;      
                   }
                   if(i!=j)
                   {
                      if(a[i][j]==0)
                         flag2=1;
                      else 
                         flag2=0;      
                   }
               }
            }
           display1(flag1,flag2);
       }
       void display1(int flag1,int flag2)
       { 
           if(flag1==1&&flag2==1)
               System.out.print("The given array is an identity matrix");
           else
               System.out.print("The given array is not an identity matrix");
       }
}
class IdentityMatrix
{
    public static void main(String s[])
    {
       Matrix m=new Matrix();
       m.input();
    }  
}   