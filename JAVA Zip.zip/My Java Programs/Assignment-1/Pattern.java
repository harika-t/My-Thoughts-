//To print first letter of your surname as a pattern
import java.lang.*;
import java.util.Scanner;
class Surname
{
   void surname()
   {
      System.out.println("T as pattern : ");
      System.out.print("Enter number for length of 'T'(Odd number for proper pattern) : ");
      Scanner sc=new Scanner(System.in);
      int n=sc.nextInt();
      for(int i=0;i<n;i++)
      {
         System.out.print("T");
      }
      System.out.print("\n");
      for(int j=1;j<n;j++)
     {
      for(int i=1;i<n;i++)
      {
         if(i==n/2)  
         {
            for(int space=0;space<n/2;space++)
            {
            System.out.print(" ");
            }
            System.out.println("T");
         }
         
      }
     }
   }
}
class Pattern
{
   public static void main(String Jk[])
   {
      Surname s=new Surname();
      s.surname();
   }
}