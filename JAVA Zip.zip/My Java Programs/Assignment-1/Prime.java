//To display prime numbers in a given range
import java.lang.*;
import java.util.Scanner;//import java.util.*;
class Number
{ 
   void prime(int a,int b)
   {
       System.out.print("Prime numbers between "+a+" and "+b+" are : ");
      for(int i=a;i<=b;i++)
      { int c=0;
         for(int j=1;j<=i;j++)
            {
               if(i%j==0)
                 c++;
            }
           if(c==2)
             System.out.print(i+" ");
      }
   }
}
class Prime
{
   public static void main(String Jk[])
   {
      System.out.println("Enter lower bound : ");
      Scanner sc=new Scanner(System.in);
      int a=sc.nextInt();
      System.out.println("Enter upper bound : ");
      int b=sc.nextInt();
      Number n=new Number();
      n.prime(a,b);
   }
}