import java.lang.*;
import java.util.Scanner;
class Matrix
{
     void input()
     {
          Scanner sc=new Scanner(System.in);
          System.out.print("Enter the number of rows of array : ");
          int row=sc.nextInt();
          System.out.print("Enter the number of columns of array : ");
          int col=sc.nextInt();
          int a[][]=new int[row][col];
          System.out.println("Enter the elements of array :");
          for(int i=0;i<row;i++)
          {
              for(int j=0;j<col;j++)
              {
                  a[i][j]=sc.nextInt();
              }
          }
         display(a,row,col);
     }
     void display(int a[][],int row,int col) 
     {
         System.out.println("Elements of the array are:");
         for(int i=0;i<row;i++)
         {
             for(int j=0;j<col;j++)
             {
                 System.out.print(a[i][j]+"\t");
             }
             System.out.print("\n");
          }
       transpose(a,row,col);
      }
     void transpose(int a[][],int row,int col)
     {
         System.out.println("The transpose of the given matrix is :");
         for(int i=0;i<col;i++)
         {
             for(int j=0;j<row;j++)
                {
                   System.out.print(a[j][i]+"\t");
                }
            System.out.print("\n");
         }
     }
}
class Transpose
{
      public static void main(String s[])
      {
             Matrix m=new Matrix();
             m.input();
      }  
}  