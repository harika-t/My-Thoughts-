//To print the frequency of elements in an array
import java.lang.*;
import java.util.Scanner;
class Frequency
{ int z,c,i;
   void input()
   {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter the number of elements : ");
      int n=sc.nextInt();
      int a[]=new int[n];
      System.out.println("Enter "+n+" elements : ");
      for(i=0;i<n;i++)
      {
         a[i]=sc.nextInt();
      }
     frequency(a);
   }
   void frequency(int a[])
   {
      for(int i=0;i<a.length;i++)
      {
         c=1;
         for(int j=i+1;j<a.length;j++)
         {
            if(a[i]==-1)
             break;
            else
            {
               if(a[i]==a[j])
               {
                  c++;
                  a[j]=-1;
               }
            }
         }
          z=a[i];
         display(z);
      }
   }
   void display(int a)
   {
      if(z!=-1)
      {
         System.out.println("Frequency of "+z+" is "+c);
      }
   }
}
class FrequencyInArray
{
   public static void main(String Jk[])
   {
      Frequency f=new Frequency();
      f.input();
   }
}