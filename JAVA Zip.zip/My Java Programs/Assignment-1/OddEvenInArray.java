//To print odd and even numbers seperately from the given array
import java.lang.*;
import java.util.Scanner;
class OddEven
{
   void input()
   {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter the number of elements : ");
      int n=sc.nextInt();
      int a[]=new int[n];
      System.out.println("Enter "+n+" elements : ");
      for(int i=0;i<n;i++)
      {
         a[i]=sc.nextInt();
      }
     oddEven(a);
   }
   void oddEven(int a[])
   {
       int j=0,k=0,l=a.length;
       int e[]=new int[l];
       int o[]=new int[l];
       for(int i=0;i<a.length;i++)
       { 
           if(a[i]%2==0)
           {
              e[j]=a[i];
              j++;
           }
           else
           {
              o[k]=a[i];
              k++;
           }
       }
      display(e,o,j,k);
   }
   void display(int e[],int o[],int j,int k)
   {
     System.out.println("Even numbers in the given array are : ");
     for(int i=0;i<j;i++)
     { 
         System.out.println(e[i]);
     }
     System.out.println("Odd numbers in the given array are :");
     for(int i=0;i<k;i++)
     { 
         System.out.println(o[i]);
     }
   }
}
class OddEvenInArray
{
   public static void main(String Jk[])
   {
      OddEven h=new OddEven();
      h.input();
   }
}