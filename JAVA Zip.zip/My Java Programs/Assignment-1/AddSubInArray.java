//To perform addition,subtraction,multiplication on two dynamic arrays
import java.lang.*;
import java.util.Scanner;
class Array
{
   void input()
   {
      Scanner sc=new Scanner(System.in);
      System.out.print("Enter the number of rows : ");
      int row=sc.nextInt();
      System.out.print("Enter the number of columns : ");
      int col=sc.nextInt();
      int a[][]=new int[row][col];
      int b[][]=new int[row][col];
      int c[][]=new int[row][col];
      System.out.print("Enter "+row*col+" elements for matrix A : ");
      for(int i=0;i<row;i++)
      {
         for(int j=0;j<col;j++)
         {
           a[i][j]=sc.nextInt();
         }
      }
      System.out.print("Enter "+row*col+" elements for matrix B : ");
      for(int i=0;i<row;i++)
      {
         for(int j=0;j<col;j++)
         {
           b[i][j]=sc.nextInt();
         }
      }
    add(a,b,c,row,col);
   }
   void add(int a[][],int b[][],int c[][],int row,int col)
   {
      for(int i=0;i<row;i++)
      { 
         for(int j=0;j<col;j++)
             c[i][j]=a[i][j]+b[i][j];
      }
        System.out.println("Addition of A and B is:");
     display(c,row,col);
     sub(a,b,c,row,col);
   }
   void sub(int a[][],int b[][],int c[][],int row,int col)
   {
      for(int i=0;i<row;i++)
      { 
         for(int j=0;j<col;j++)
             c[i][j]=a[i][j]-b[i][j];
      }
        System.out.println("Subtraction of A and B is:");
     display(c,row,col);
   }
   void mul(int a[][],int b[][],int c[][],int row,int col)
   {  
      
   }
   void display(int c[][],int row,int col)
   {   
      for(int i=0;i<row;i++)
      {
	for(int j=0;j<col;j++)
	{
	  System.out.print(c[i][j]+"\t");
        }
          System.out.print("\n");
      }

   }
}
class AddSubInArray
{
   public static void main(String Jk[])
   {
      Array a=new Array();
      a.input();
   }
}