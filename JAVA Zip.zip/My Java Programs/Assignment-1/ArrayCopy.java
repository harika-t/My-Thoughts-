//To copy elements of one array to another array
import java.lang.*;
import java.util.Scanner;
class Copy
{
   void input()
   {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter the number of elements : ");
      int n=sc.nextInt();
      int a[]=new int[n];
      System.out.println("Enter "+n+" elements : ");
      for(int i=0;i<n;i++)
      {
         a[i]=sc.nextInt();
      }
      System.out.println("Elements in the original array are : ");
      display(a,n);
      cpy(a,n);
   }
   void cpy(int a[],int n)
   {
      int b[]=new int[n];
      for(int i=0;i<n;i++)
      {
         b[i]=a[i];
      }
   System.out.println("Elements in the array after copying are : ");
   display(b,n);
   }
   void display(int b[],int n)
   {
      for(int i=0;i<n;i++)
      {
         System.out.println(b[i]);
      }
   }
}
class ArrayCopy
{
   public static void main(String Jk[])
   {
      Copy c=new Copy();
      c.input();
   }
}