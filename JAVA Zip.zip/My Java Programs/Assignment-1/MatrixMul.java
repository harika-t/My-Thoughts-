//To perform multiplication of two matrices
import java.lang.*;
import java.util.Scanner;
class Mul
{
   void input()
   {
      Scanner sc=new Scanner(System.in);
      System.out.print("Enter the number of rows of matrix A: ");
      int arow=sc.nextInt();
      System.out.print("Enter the number of columns of matrix A: ");
      int acol=sc.nextInt();
      System.out.print("Enter the number of rows of matrix B: ");
      int brow=sc.nextInt();
      System.out.print("Enter the number of columns of matrix B: ");
      int bcol=sc.nextInt();
      int a[][]=new int[arow][acol];
      int b[][]=new int[brow][bcol];
      int c[][]=new int[arow][bcol];
      System.out.print("Enter "+arow*acol+" elements for matrix A : ");
      for(int i=0;i<arow;i++)
      {
         for(int j=0;j<acol;j++)
         {
           a[i][j]=sc.nextInt();
         }
      }
      System.out.print("Enter "+brow*bcol+" elements for matrix B : ");
      for(int i=0;i<brow;i++)
      {
         for(int j=0;j<bcol;j++)
         {
           b[i][j]=sc.nextInt();
         }
      }
    mul(a,b,c,arow,acol,brow,bcol);
   }
   void mul(int a[][],int b[][],int c[][], int arow,int acol,int brow,int bcol)
   {
      if(acol==brow)
      {
         for(int i=0;i<arow;i++)
         {
	    for(int j=0;j<bcol;j++)
	    {
	       c[i][j]=0;
	       for(int k=0;k<acol;k++)
	       {
	  	  c[i][j]+=a[i][k]*b[k][j];
	       }	
	    } 
         }
          System.out.println("Multiplication of A and B is : ");
          for(int i=0;i<arow;i++)
          {
	     for(int j=0;j<bcol;j++)
	     {
	        System.out.print(c[i][j]+"\t");
	     }System.out.print("\n");
          }
      }
      else
    System.out.print("Multiplication is not possible for the matrices with these rows and columns");
  }
}
class MatrixMul
{
   public static void main(String Jk[])
   {
      Mul m=new Mul();
      m.input();
   }
}