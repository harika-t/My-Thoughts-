//To print student details
import java.lang.*;
import java.util.Scanner;
class Student
{ 
   static String College="Rgukt Sklm";
   String name;
   Student()
   {
      Scanner sc=new Scanner(System.in);
      System.out.print("Enter name : ");
      name=sc.nextLine();
      System.out.print("Enter ID number : ");
      String ID=sc.nextLine();
      System.out.print("Enter branch : ");
      String branch=sc.nextLine();
      System.out.print("Enter name of the college : ");
      String college=sc.nextLine();
      System.out.print("Enter cgpa : ");
      float cgpa=sc.nextFloat();
    }
     void display()
     {
      System.out.println("Name : "+name);
      System.out.println("College : "+College);
     }
}
class StudentDetails
{
    public static void main(String Jk[])
    {
      System.out.print("Enter number of students : ");
      Scanner sc=new Scanner(System.in);
      int n=sc.nextInt();
      Student a[]=new Student[n];
      for(int i=0;i<n;i++)
      {
          a[i]=new Student();
      }
      System.out.println("Student details are : ");
      for(int i=0;i<n;i++)
      {
          a[i].display();
      }
    }
}