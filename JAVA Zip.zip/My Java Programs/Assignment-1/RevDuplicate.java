//To reverse the array and print the duplicate numbers
import java.lang.*;
import java.util.Scanner;
class Array
{
   void input()
   {
      Scanner sc=new Scanner(System.in);
      System.out.print("Enter the number of elements : ");
      int n=sc.nextInt();
      int a[]=new int[n];
      System.out.print("Enter "+n+" elements : ");
      for(int i=0;i<n;i++)
      {
         a[i]=sc.nextInt();
      }
      System.out.print("Original elements are : ");
      display(a,n);
      reverse(a,n);
      duplicate(a,n);
   }
   void display(int a[],int n)
   {
      for(int i=0;i<n;i++)
      {
         System.out.print(a[i]+"\t");
      }
   }
   void reverse(int a[],int n)
   {
      int i=0;
      int j=a.length-1;
      while(i<j)
      { 
         int temp=a[i];
         a[i]=a[j];
         a[j]=temp;
         i++;
         j--;
      } 
     System.out.print("\nReversed elements are : ");
     display(a,n);
   }
   void duplicate(int a[],int n)
   {
      for(int i=0;i<a.length;i++)
      {
         int c=1;
         for(int j=i+1;j<a.length;j++)
         {
            if(a[i]==-1)
             break;
            else
            {
               if(a[i]==a[j])
               {
                  c++;
                  a[j]=-1;
               }
            }
         } 
        display1(a[i],c); 
      }
      
   }
   void display1(int z,int c)
   {
      
      if(z!=-1&&c!=1)
        System.out.println("\n"+z+" is a duplicate element");
   }
}
class RevDuplicate
{
   public static void main(String Jk[])
   {
      Array a=new Array();
      a.input();
   }
}