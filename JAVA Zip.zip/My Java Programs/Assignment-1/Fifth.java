//To find fibonacci series,factorial of the given number,armstrong number or not,palindrome or not
import java.lang.*;
import java.util.Scanner;
class Number
{
   void fib(int x)
   {
      int a=0,b=1,c;
      System.out.println(a);
      for(int i=1;i<=x;i++)
      {
         c=a+b;
         a=b;
         b=c;
         if(a<=x)
         System.out.println(a);
      }
   }
}
class Fifth
{
   public static void main(String Jk[])
   {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter number : ");
      int h=sc.nextInt();
      Number n=new Number();
      System.out.println("Fibonacci Series upto "+h+" is : ");
      n.fib(h);
   }
}