import java.lang.*;
class Outer
{
   static class Nested
   {
      
      public static void main(String Jk[])
      {
         System.out.println("static nested class called");
      }
   };
   public static void main(String Jk[])
   {
      System.out.println("Main method of outer class");
   }
}