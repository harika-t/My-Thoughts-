import p.Ka;
class Throwable
{
           public static void main(String a[])
           {
                try{
                String s1=a[0];
                String s2=a[1];
                Ka k=new Ka();
                k.div(s1,s2);
                }
                catch(ArithmeticException e)
                {
                    System.out.println("please don't enter denominator as zero");
                }
               catch (NumberFormatException p)
               {
                   System.out.println("please enter integer values only");
               }
              catch(ArrayIndexOutOfBoundsException j)
               {
                  System.out.println("please pass values from command prompt");
               }

           }
}