import java.util.Scanner;
import arithmetic.Add;
import arithmetic.ar2.Sub;
import arithmetic.ar2.OuterArt;
public class Test
{
    public static void main(String Vk[])
    {
       Scanner sc=new Scanner(System.in);
       System.out.println("Enter two values for addition : ");
       double a=sc.nextDouble();
       double b=sc.nextDouble();
       Add obj=new Add();
       double d=obj.add(a,b);
       System.out.println("Addition : "+d);
       Sub s=new Sub();
       s.sub();
       OuterArt o=new OuterArt();
       o.show();
       OuterArt.Inn i=o.new Inn();
       i.display();
    }
}