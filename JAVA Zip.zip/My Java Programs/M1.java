package pack1;
public class M1
{
    private int a=1;
    int b=2;
    protected int c=3;
    public int d=4;
}