import java.lang.*;
class Jk
{
   int a,b;
   Jk(int a,int b)
   {
      System.out.println("Double parameter constructor");
      this.a=a;
      this.b=b;
      System.out.println("Double : this.a="+this.a+" this.b="+this.b);
   }
   Jk()
   {
      System.out.println("Default constructor");
   }
   Jk(Jk l)
   {
      System.out.println("Single parameter object constructor");
      System.out.println("With object parameter this : this.a="+this.a+" this.b="+this.b);
      System.out.println("With object parameter object :"+l.a+"object b"+l.b);
      l.a=this.a+l.b;
      this.b=l.a+this.b;
      System.out.println("Single parameter object constructorafter processing");
      System.out.println("With object parameter this : this.a="+this.a+" this.b="+this.b);
      System.out.println("With object parameter object :"+l.a+"object b"+l.b);
   }
   void m1(Jk y)
   {
      System.out.println("Method with Single parameter object");
      System.out.println("With object parameter this : this.a="+this.a+" this.b="+this.b);
      System.out.println("With object parameter object :"+y.a+"object b"+y.b);
   }
   void m(int p)
   {
      System.out.println("Method with Single parameter value");
      this.a=p;
      System.out.println("With object parameter this : this.a="+this.a+" this.b="+this.b);
      System.out.println("With object parameter object :"+a+"object b"+b);
   }
}
class E22
{
   public static void main(String k[])
   {
      Jk j1=new Jk(5,6);
      j1.m(10);
      Jk j2=new Jk();
      Jk j3=new Jk(j1);
      j3.m1(j1);
      Jk j4=j1;
      System.out.println("With j4 object :"+j4.a+"object b"+j4.b);
      System.out.println("With j1 object :"+j1.a+"object b"+j1.b);
   }
}