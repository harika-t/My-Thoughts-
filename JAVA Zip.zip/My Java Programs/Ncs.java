package in.ac.rguktnuzvid;
public class Ncs
{
   public void ncsa()
   {
      System.out.println("cse a");
   }
   public void ncsb()
   {
      System.out.println("cse b");
   }
   public void ncsc()
   {
      System.out.println("cse c");
   }
}