import java.lang.*;
class Bc1
{
   int a,b;
   Bc1(int a,int b)
   {
      System.out.println("Parametrized Constructor");
   }
   Bc1()
   {
      System.out.println("Default Constructor");
   }
   Bc1(float c)
   {
      System.out.println("Single float parameter Constructor");
   }
   Bc1(int h)
   {
      System.out.println("Single int parameter Constructor");
   }
}
class E231
{
   public static void main(String Jk[])
   {
      Bc1 b1=new Bc1(10,20);
      Bc1 b2=new Bc1();
      Bc1 b3=new Bc1(5.5f);
      Bc1 b4=new Bc1(10);
   }
}