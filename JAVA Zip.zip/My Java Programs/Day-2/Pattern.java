//H in pattern of length NXN
import java.lang.*;
import java.util.*;
class H
{
  int i,j;
   void input()
   {
      System.out.print("Enter n(Odd value for proper pattern) : ");
      Scanner sc=new Scanner(System.in);
      int n=sc.nextInt();
      for(i=0;i<n;i++)
      {
         for(j=0;j<n;j++)
         {
            if(j==0||j==n-1||(i==n/2&&(j>=1&&j<=n-2)))
            {
                System.out.print("* ");
            }
            else
          System.out.print("  ");
         }
       System.out.println();
      }
   }
}
class Pattern
{
   public static void main(String Vk[])
   {
      H h=new H();
      h.input();
   }
}