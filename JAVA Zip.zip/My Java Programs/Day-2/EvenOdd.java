import java.lang.*;
import java.util.*;
class EvenOdd
{
  public static void main(String k[])
  {
    int n,i,j,t;
    System.out.print("Enter the number of elements in array:");
    Scanner sc=new Scanner(System.in);
    n=sc.nextInt();
    if(n<=0)
    System.out.println("Wrong input");
    else
    {
      int a[]=new int[n];
    for(i=0;i<n;i++)
    {
      a[i]=sc.nextInt();
    }
    for(i=0;i<n;i++)
    {
     for(j=i+1;j<n;j++)
     {
       if(a[i]%2==0)
       {
         t=a[i];
         a[i]=a[j];
         a[j]=t;
        }
       }
    }
  for(i=0;i<n;i++)
    {
      System.out.print(a[i]+" ");
    }
}
}
}