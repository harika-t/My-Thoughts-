//Sum of quadratic equations
import java.lang.*;
import java.util.*;
class Sum
{
   int i,j;
   void input()
   {
      Scanner sc=new Scanner(System.in);
      System.out.print("Enter the number of quadratic equations : ");
      int n=sc.nextInt();
      int a[][]=new int[n][3];
      for(i=0;i<n;i++)
      {
         System.out.print("Enter the coefficients of quadratic equations : ");
         for(j=0;j<=2;j++)
         {
            a[i][j]=sc.nextInt();
         }
      }
      total(a,n);
   }
   void total(int a[][],int n)
   {
      int b[]=new int[3];
       int sum,k=0;
      for(j=0;j<=2;j++)
      {
         sum=0;
         for(i=0;i<n;i++)
         {
             sum=sum+a[i][j];
         }
        b[k]=sum;k++;
      } 
     output(b); 
   }
   void output(int b[])
   {
      System.out.print("The sum of all the quadratic equations is : "+b[0]+" x^2 + "+b[1]+" x + "+b[2]+" =0");
   }
}
class Qsum
{
   public static void main(String Vk[])
   {
      Sum s=new Sum();
      s.input();
   }
}