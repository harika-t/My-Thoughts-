//To print fibanocci (initial values from user)
import java.lang.*;
import java.util.Scanner;
class Number
{  int i;
   void fib(int x,int y,int z)
   {
      System.out.println("The fibanocci series is :");
      int a=y,b=z,c;
      System.out.println(a);
      for(int i=1;i<=x;i++)
      {
         c=a+b;
         a=b;
         b=c;
         if(a<=x)
         {
            i=a;
            display(a);
         }
      }
   }
   void display(int a)
   {
      System.out.println(a);
   }
}
class Fibanocci
{
   public static void main(String Vk[])
   {
      Number n=new Number();
      Scanner sc=new Scanner(System.in);
      System.out.print("Enter number upto which fibonacci series is required : ");
      int x=sc.nextInt();
      System.out.print("Enter first initial value : ");
      int y=sc.nextInt();
      System.out.print("Enter second initial value : ");
      int z=sc.nextInt();
      n.fib(x,y,z);
   }
}