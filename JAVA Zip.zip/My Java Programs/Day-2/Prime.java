import java.lang.*;
import java.util.*;
class Number
{
   int c=0,i;
   void input()
   {
     System.out.print("Enter the number : ");
     Scanner sc=new Scanner(System.in);
     int n=sc.nextInt();
     for(i=2;i<n;i++)
     {
       if(n%i==0)
         c++;
     }
      if(c==0)
        System.out.println(n+" is a prime number");
      else
        System.out.println(n+" is not a prime number");
   }
}
class Prime
{
   public static void main(String Vk[ ])
   {
       Number n=new Number();
       n.input();
   }
}
