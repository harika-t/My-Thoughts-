//To implement a 4-bit comparator
import java.lang.*;
import java.util.*;
class Bit
{
    void input()
    {
     int i,l=0,f=0,temp1,temp2;
     int a[]=new int[4];
     int b[]=new int[4];
     System.out.print("Enter the first number : ");
     Scanner sc=new Scanner(System.in);
     int n=sc.nextInt();
     System.out.print("Enter the second number : ");
     int m=sc.nextInt();
     temp1=n;
     temp2=m;
     if(n<16&&m<16&&n>=0&&m>=0)
     {
        for(i=0;i<4;i++)
        {
           a[i]=n%2;
           n=n/2;
           b[i]=m%2;
           m=m/2;
        }
        System.out.println("Binary number of "+temp1+" is : ");
        for(i=3;i>=0;i--)
        {
           System.out.print(a[i]);
        }
        System.out.print("\n");
        System.out.println("Binary number of "+temp2+" is : ");
        for(i=3;i>=0;i--)
        {
           System.out.print(b[i]);
        }
        System.out.print("\n");
       i=3;
       while(i>=0)
       {
          if(a[i]==b[i])
             i--;
          else if(a[i]>b[i])
          {
            l=1;
            break;
          }
         else
         {
            f=1;
            break;
         }
       }
      if(l==0&&f==0)
         System.out.println("Both are equal i.e, "+temp1+" == "+temp2);
      else if(l==1)
         System.out.println(temp1+" is greater than "+temp2+" i.e, "+temp1+" > "+temp2);
      else
         System.out.println(temp2+" is greater than "+temp1+" i.e, "+temp2+" > "+temp1);
   }
   else
      System.out.println("Out of range!!!We can represent only numbers upto 15 in 4-bits");
  }
}
class Comparator
{
  public static void main(String Vk[])
  {
      Bit b=new Bit();
      b.input();
  }
}

         