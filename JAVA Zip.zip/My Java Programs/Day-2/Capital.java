import java.lang.*;
import java.util.*;
class CapitilizeFirst
{
   void capitilize()
   {
     Scanner s=new Scanner(System.in);
     System.out.print("Enter a sentence : ");
     String p=s.nextLine();
     char a[]=p.toCharArray();
     for(int i=0;i<a.length;i++)
     {
        if(i==0)
        {
           a[i]=Character.toUpperCase(a[i]);
        }
        if(a[i]==' ')
        {
           a[i+1]=Character.toUpperCase(a[i+1]);
        }
   
     }
     for(int i=0;i<a.length;i++) 
     {
        System.out.print(a[i]);
     } 
   }
}
class Capital
{
    public static void main(String args[])
    {
     CapitilizeFirst c=new CapitilizeFirst();
     c.capitilize();   
    }
}