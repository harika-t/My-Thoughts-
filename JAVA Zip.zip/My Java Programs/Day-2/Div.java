//To print the number of integers within the given range of two values that are divisible by another given number
import java.lang.*;
import java.util.Scanner;
class Number
{
   int i,count=0;
    void input()
    {
       System.out.print("Enter lower range : ");
       Scanner sc=new Scanner(System.in);
       int l=sc.nextInt();
       System.out.print("Enter upper range : ");
       int u=sc.nextInt();
       System.out.print("Enter value to divide : ");
       int d=sc.nextInt();
       for(i=l;i<=u;i++)
       {
          if(i%d==0)
            count++;
       }
      output(count,l,u,d);
    }
    void output(int count,int l,int u,int d)
    {
       System.out.print("Number of numbers divisible by "+d+" from "+l+" to "+u+" are "+count);
    }
}
class Div
{
   public static void main(String Vk[])
   {
      Number n=new Number();
      n.input();
   }
}