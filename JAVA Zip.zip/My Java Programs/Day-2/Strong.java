//To check whether a given number is a strong number or not
import java.lang.*;
import java.util.*;
class Fact
{
  int factorial(int x)
  {
    int fact=1,i;
    for(i=1;i<=x;i++)
    { 
     fact=fact*i;
    }
    return fact;
  }
}
class Strong
{
     public static void main(String Vk[ ])
     {
         System.out.print("Enter the number :");
         Scanner sc=new Scanner(System.in);   
         int n=sc.nextInt();
         int rem=0,temp,sum=0;
         temp=n;
         Fact z=new Fact();
         while(n!=0)
         {
           rem=n%10;
           sum=sum+z.factorial(rem);
           n=n/10;
         }
         if(sum==temp)
            System.out.println(temp+" is a strong number");
         else
            System.out.println(temp+" is not  a strong number");
     }
}
