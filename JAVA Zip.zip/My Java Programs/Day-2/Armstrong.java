//To check whether a given number is an armstrong number or not
import java.lang.*;
import java.util.Scanner;
class Number
{
   void input()
  {
    System.out.print("Enter the number : ");
    Scanner sc=new Scanner(System.in);
    int n=sc.nextInt();
    int rem,temp,sum=0;
    temp=n;
    while(n!=0)
    {
       rem=n%10;
       sum=sum+(rem*rem*rem);
       n=n/10;
    }
    if(sum==temp)
       System.out.println(temp+" is an armstrong number");
    else
       System.out.println(temp+" is not an rmstrong number");
   }
}
class Armstrong
{
    public static void main(String Vk[])
    {
        Number n=new Number();
        n.input();
    }
}
