//To check whether a given number is palindrome or not
import java.lang.*;
import java.util.*;
class Number
{
   void input()
  {
   System.out.print("Enter number : ");
   Scanner sc=new Scanner(System.in);
   int n=sc.nextInt();
   int temp,sum=0,rem;
   temp=n;
   while(n!=0)
   {
      rem=n%10;
      sum=sum*10+rem;
      n=n/10;
   }
   if(sum==temp)
     System.out.println(temp+" is a palindrome");
   else
     System.out.println(temp+" is not a plindrome");
   }
}
class Palindrome
{
    public static void main(String Vk[ ])
    {
        Number n=new Number();
        n.input();
    } 
}