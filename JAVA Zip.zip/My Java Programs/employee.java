package in.ac.rguktsklm.student;
class employee
{
   public static void main(String Vk[])
   {
       System.out.println("Hiiiii");
   }
}