import java.lang.*;
import java.util.*;
class Rcse
{
   public static void main(String Jk[])
   {
      System.out.println("Main method");
      /*Random r=new Random();
      System.out.println("Boolean : "+r.nextBoolean());
      System.out.println("Double : "+r.nextDouble());
      System.out.println("Float : "+r.nextFloat());
      System.out.println("Int : "+r.nextInt());
      System.out.println("Int with seed value : "+r.nextInt(10));
      System.out.println("Int with seed value : "+r.nextInt(10));*/
     String s1="RGUKT is a university present in AP.";
     StringTokenizer st=new StringTokenizer(s1);
     System.out.println("Count : "+st.countTokens());
     int count=0;
     while(st.hasMoreTokens())
     {
        st.nextToken();
        count++;
     }
     System.out.println("Count though loop : "+count);
   }
}