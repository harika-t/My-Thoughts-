import java.lang.*;
class Multiplication
{
   int mul(int a,int b)
   {
      return a*b;
   }
   static int add(int a,int b)
   {
      return a+b;
   }
}
class Fmul
{
   public static void main(String Jk[])//Program driver
   {
      System.out.println("Main method");
      Multiplication m=new Multiplication();
      System.out.println("Multiplication:"+m.mul(2,3));
      System.out.println("Addition:"+Multiplication.add(2,3));
   }
}