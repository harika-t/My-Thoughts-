package p;
public class Ka
{
      public void div(String s1, String s2) 
      {
           int n1=Integer.parseInt(s1);
           int n2=Integer.parseInt(s2);
           int n3=n1/n2;
           System.out.println("Division of two numbers:"+n3);
      }
}