package gamma;
public class JungKook
{
   public static void cse()
   {
      System.out.println("CSE method called");
   }
}