package arithmetic.ar2;
public class OuterArt
{
   public void show()
   {
      System.out.println("Outer class");
   }
   public class Inn
   {
      public void display()
      {
          System.out.println("Inner class");
      }
   };
}