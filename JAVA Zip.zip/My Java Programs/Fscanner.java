import java.lang.*;
import java.util.Scanner;//import java.util.*;
class Fscanner
{
   public static void main(String Jk[])//Program driver
   {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter your name : ");
      String name=sc.nextLine();//Collection of words
      //String name1=sc.next();//Only one word
      System.out.println("Enter your gender : ");
      char gender=sc.next().charAt(0);
      System.out.println("Enter your branch : ");
      String branch=sc.next();
      System.out.println("Enter your age : ");
      while(!sc.hasNextInt())//While the next input is an integer or not
      {
         String j=sc.next();
      }
      int age=sc.nextInt();
      System.out.println("Enter your mobile number : ");
      long mobile=sc.nextLong();
      System.out.println("Enter your CGPA : ");
      double cgpa=sc.nextDouble();
      System.out.println("Name : "+name);
      System.out.println("Gender : "+gender);
      System.out.println("Branch : "+branch);
      System.out.println("Age : "+age);
      System.out.println("Mobile Number : "+mobile);
      System.out.println("CGPA : "+cgpa);
   }
}