import java.lang.*;
class Bc
{
  int i=5;
  void m()
  {
     System.out.println("m method in Base class");
  }
  Bc()
  {
     System.out.println("Constructor of Base class");
  }
  Bc(int a,int b)
  {
     System.out.println("Parametrized Constructor of Base class");
  }
}
class Dobc extends Bc
{
   Dobc()
   {
      System.out.println("Constructor of derived class");
   }
   Dobc(int a,int b)
   {
     
      System.out.println("Parametrized Constructor of derived class");
       this();
   }
   void m()
   {  
      System.out.println("m method in Derived class");
      super.m();
   }
   public static void main(String Jk[])
   {
      System.out.println("Main method starts executing");
      Dobc d=new Dobc(5,6);
      d.m();
   }
}