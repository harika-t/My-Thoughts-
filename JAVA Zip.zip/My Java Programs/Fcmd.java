import java.lang.*;
class Fcmd
{
   public static void main(String Jk[])
   {
      if(Jk.length!=2)
      {
         System.out.println("Please enter two parameters");
      }
      else 
      {
      System.out.println("Start of main method");
      System.out.println(Jk[0]);
      System.out.println(Jk[1]);
      int a=Integer.parseInt(Jk[0]);
      int b=Integer.parseInt(Jk[1]);
      System.out.println("Addition operation on strings : "+(Jk[0]+Jk[1]));
      System.out.println("Addition operation on integers : "+(a+b));
      System.out.println("End of main method");
      }
   }
}