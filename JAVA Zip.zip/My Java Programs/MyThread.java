/*
class cse extends Thread
{
    public void run()
    {
        for(int i=0;i<10;i++)
        {
            System.out.println("Child thread");
        }
    }
}
class MyThread
{
    public static void main(String Jk[])  
    {
        cse c=new cse();
        c.start(); //Thread is created
        for(int i=0;i<5;i++)
        {
            System.out.println("Main thread");
        }
    }
}  */


class cse extends Thread
{
    public void run()
    {
        for(int i=0;i<10;i++)
        {
            System.out.println("Child thread");
        }
    }
}
/*
class MyThread
{
    public static void main(String Jk[])  
    {
        cse c=new cse();
        Thread t=new Thread(c);
        t.start(); //Thread is created
        for(int i=0;i<5;i++)
        {
            System.out.println("Main thread");
        }
    }
}   */


class MyThread
{
     public static void main(String Jk[])
     {
          System.out.println("Current executing thread is : "+Thread.currentThread().getName());
          cse c=new cse();
          System.out.println("Current executing thread is : "+c.getName());
          Thread.currentThread().setName("Virat Kohli");
          System.out.println("Current executing thread is : "+Thread.currentThread().getName());
     }
}