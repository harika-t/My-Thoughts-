import java.io.*;
public class FileEx1
{
    public static void main(String Jk[]) throws Exception
    {
        /*String f=Jk[0];
        FileInputStream fis=new FileInputStream(f);
        byte[] b=new byte[fis.available()];
        fis.read(b);
        String s=new String(b);
        System.out.println("Copying....");
        FileOutputStream fos=new FileOutputStream("E://My Java Programs//in//Add.txt");
        byte[] j=s.getBytes();
        fos.write(j);
        System.out.println("Successfully copied");
        fis.close();
        fos.close();*/
        
       //To copy an image
        //String f=Jk[0];
    /*    FileInputStream fis=new FileInputStream("Virat.jpg"); //For video:"name.mp4"
        byte[] b=new byte[fis.available()];
        fis.read(b);
        //String s=new String(b);
        System.out.println("Copying....");
        FileOutputStream fos=new FileOutputStream("E://My Java Programs//in//Vk.jpg");  //For video:"name.mp4"  
        //byte[] j=s.getBytes();
        fos.write(b);
        System.out.println("Successfully copied");
        fis.close();
        fos.close();   */


        FileInputStream fis=new FileInputStream("abc.txt");
        byte[] b=new byte[fis.available()];
        fis.read(b);
        String s=new String(b); //Byte to string
        System.out.println("Copying....");
        String[] str=s.split(" ");
        int word_count=str.length;
        System.out.println("Total number of words are : "+word_count);
        System.out.println("The words are :");
        for(int i=0;i<str.length;i++)
            System.out.println(i+1+"."+str[i]);
        int c=0;
        for (int i=0;i<s.length();i++)
        {
            char ch=s.charAt(i);
            if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u'||ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U')
                c++;
        }
       System.out.println("The total number of vowels are :"+c);
       int h=0;
       for(int i=0;i<word_count;i++)
       {
           String val=str[i];
           if(val.equals("Virat"))
              h++;
       }
       System.out.println("The total number of times Virat occurred is :"+h);
    }
}