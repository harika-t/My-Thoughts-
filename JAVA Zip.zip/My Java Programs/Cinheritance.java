import java.util.*;
final class C1
{
   int a=5;
   private int b=6;
   final void show()
   {
      System.out.println("Values of a and b from Base class are : "+a+"  "+b);
   }
};
class C2 extends C1
{
   /*void show()
   {
      System.out.println("Overridden show() of derived class");
   }*/
};
class Cinheritance
{
   public static void main(String Jk[])
   {  
      System.out.println("Main method starts execution");
      C2 b=new C2();
      //b.display();
      b.show();
   }
}