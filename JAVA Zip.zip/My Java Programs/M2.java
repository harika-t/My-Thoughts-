package pack1;
public class M2
{
   public static void main(String Vk[])
   {
       M1 m=new M1();
       //System.out.println("a="+m.a);
       System.out.println("b="+m.b);
       System.out.println("c="+m.c);
       System.out.println("d="+m.d);
   }
}