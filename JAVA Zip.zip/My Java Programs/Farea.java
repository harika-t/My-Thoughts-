//To take radius as input from cmd and display corresponding area of circle
import java.lang.*;
class Circle
{
   double r,res;
   void area(double x)
   {
      r=x;
      calculate();
   }
   void calculate()
   {
      res=3.14*r*r;
      display();
   }
   void display()
   { 
      System.out.println("Area of circle is : "+res);
   }
}
class Farea
{
   public static void main(String Jk[])//Program driver
   {
      if(Jk.length!=1)
      {
         System.out.println("Please enter only one parameter!!!");
      }
      else
      {
         Circle c=new Circle();
         double d=Double.parseDouble(Jk[0]);
         c.area(d);
      }
   }
}