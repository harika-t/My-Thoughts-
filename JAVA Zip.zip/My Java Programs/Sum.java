import java.util.*;
class Sum
{
   public static void main(String args[])
   {
       int n=Integer.parseInt(args[0]);
int sum=0;String s="";
for(int i=1;i<=n;i++ )
{
    sum=sum+i;
    s=s+i+"+";
}
System.out.println(s+"=sum");
System.out.println(sum);
   }
}