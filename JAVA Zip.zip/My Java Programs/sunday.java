interface sunday
{
   void m1();
   int a=10;
}