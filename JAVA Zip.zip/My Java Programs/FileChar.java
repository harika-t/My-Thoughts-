import java.io.*;
public class FileChar
{
    public static void main(String Jk[]) throws Exception
    {
       /* FileReader f=new FileReader("Add.java");
        int i=f.read();
        while(i!=-1)
        {
            System.out.print((char)i);
            i=f.read();
        } */
       

 //       File f1=new File("Add.java");
 //        FileReader f=new FileReader(f1);
     /*   int i=f.read();
        while(i!=-1)
        {
            System.out.print((char)i);
            i=f.read();
        } */


    /*   char[] ch=new char[(int)f1.length()];  //FIS-available(),File-length()
        f.read(ch);
        for (int i=0;i<ch.length;i++)
        {
            System.out.print((char)ch[i]);
        }  
      f.close();  */



     /* FileWriter fw=new FileWriter("abc.txt",true);  // If true-data is appended else overidden
       fw.write("Virat");  //Overrides data
        fw.flush();
        System.out.println("Copied successfully");  */

        
      /*  File f=new File("abc.txt");
        FileWriter fw=new FileWriter(f,true);  
       fw.write("Virat");  
        fw.flush();
        System.out.println("Copied successfully");  */


      /*  FileWriter fw=new FileWriter("abc.txt",true);  
        char[] ch={'k','o','h','l','i'};
        String s="Jeon JungKook";
        //fw.write(ch,0,3);  
        fw.write(s);//Appends the data
        fw.flush();
        System.out.println("Copied successfully");  */


        File f=new File("abc.txt");
         f.createNewFile();
         FileWriter fw=new FileWriter(f);
         fw.write("An example of file writer and reader");
         fw.flush();
         fw.close();
         System.out.println("Written Successfully");
        FileReader fr=new FileReader(f);
         char[] ch=new char[(int)f.length()];
         fr.read(ch);
          for (int i=0;i<ch.length;i++)
          {
              System.out.print((char)ch[i]);
          }
    }
}
