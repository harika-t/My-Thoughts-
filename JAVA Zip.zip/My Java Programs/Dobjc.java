import java.lang.*;
class Bc
{
   void m()
   {
      System.out.println("final m method in Base class");
   }
   
   void j()
   {
      System.out.println("j method in Base class");
   }
}
class Dobjc extends Bc
{
   void m()
   {
      System.out.println("m method in Derived class");
   }
   public static void main(String Jk[])
   {
      System.out.println("Main method starts execution");
      Bc b=new Bc();
      Dobjc d=new Dobjc();
      b=d;//Implicit object type casting(sub to super)
      b.m();
      b.j();
   }
}