import java.io.*;
public class FileAsg1
{
   public static void main(String Jk[]) throws Exception
   {
     FileReader fr = new FileReader(Jk[0]);
     FileReader fr1 = new FileReader(Jk[1]);
     FileWriter fw = new FileWriter(Jk[2]);
     BufferedReader br = new BufferedReader(fr);
     BufferedReader br1 = new BufferedReader(fr1);
     BufferedWriter bw=new  BufferedWriter(fw);
     String line=br.readLine();
     String line1=br1.readLine();
     boolean i=true;
     while(i)
    {
       if(line!=null)
       {   
       bw.write(line);
       bw.newLine();
       bw.flush();
       line=br.readLine();
       }
       if(line1!=null)
       {
       bw.write(line1);
       bw.newLine();
       bw.flush();
       line1=br1.readLine();
       }
       else
       {
        i=false;
       }
       
    }
  br.close();
  br1.close();
  fr.close();
  fr1.close();
  }
}