import java.lang.*;
class EStrings
{
   public static void main(String Jk[])
   {
      System.out.println("Main method starts");
      /*String s="cse";
      String s1="hello";
      String s2="cse";
      System.out.println("SCP checking : "+(s==s2));//True
      System.out.println("SCP checking : "+(s==s1));//False
      String s3=new String();//Empty string
      String s4=new String("cse");
      String s5=new String("cse");
      String s6=new String("ece");
      System.out.println("Heap checking : "+(s4==s5));//False
      char c[]={'c','s','e','w','e','l','l',};
      String s7=new String(c);
      System.out.println("s7 data is : "+s7);//csewell
      String s8=new String(c,3,2);
      System.out.println("s8 data is : "+s8);//we*/
      String s="csewelcomes you. cse is a good branch for software people, cse";
      /*System.out.println("Second character : "+s.charAt(1));//s
      char c[]=new char[15];
      s.getChars(3,10,c,4);
      for(int i=0;i<c.length;i++)
      System.out.println("c data(array) is : "+c[i]);
      String s1=new String("csewelcomes");
      System.out.println(s.equalsIgnoreCase(s1));//True
      System.out.println(s.indexOf("cse",5));//0
      System.out.println(s.lastIndexOf("cse"));//59
      System.out.println(s.substring(4));
      System.out.println(s.substring(4,15));
      String s2=new String("cse");
      System.out.println(s2.concat("welcomes"));//csewelcomes
      System.out.println(s2);//cse(String is immutable)
      System.out.println(s2.toUpperCase());//CSE
      System.out.println(s2);//cse
      System.out.println(s2.length());//3
      System.out.println(s2.replace('e','E'));//csE
      System.out.println(s2);//cse*/
      StringBuffer sb1=new StringBuffer("cse");
      /*StringBuffer sb2=new StringBuffer("cse");
      System.out.println("Comparison(==) : "+(sb1==sb2));//False
      System.out.println("Comparison(equals()) : "+sb1.equals(sb2));//False
      System.out.println("Content Comparison(Using toString().equals()) : "+sb1.toString().equals(sb2.toString()));//True*/
      System.out.println("Length : "+sb1.length());
      System.out.println("Capacity(Buffer) : "+sb1.capacity());
      sb1.insert(1,"omputer");
      System.out.println("Insertion : "+sb1);
      /*sb1.reverse();
      System.out.println("Reverse : "+sb1);
      sb1.deleteCharAt(8);
      System.out.println("Single character deletion : "+sb1);
      sb1.delete(1,8);
      System.out.println("Multiple characters deletion : "+sb1);*/
      sb1.replace(1,8,"system");
      System.out.println("Replace : "+sb1);
      String s5="cse";
      s5.concat("likes");
      System.out.println("String concat: "+s5);
      sb1.append("likes");
      System.out.println("String append : "+sb1);
   }
}