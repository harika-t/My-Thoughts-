import java.lang.*;
class Outer
{
   int x=5;
   static int y=10;
   void m2()
   {
      System.out.println("Outer class m2 is called");
   }
   void m3()
   {
      System.out.println("Outer class m3 is called");
   }
   static class Nested
   {
      void m(Outer o)
      {  //Outer o=new Outer();
         System.out.println("x= "+o.x+" y="+y);
      }
      static void m1(Outer o)
      {  //Outer o=new Outer();
         System.out.println("x= "+o.x+" y="+y);
      }
   };
   Nested n=new Nested();
 }
class StaticNested
{
    public static void main(String Jk[])
   {
      System.out.println("Main method");
      Outer o=new Outer();
      System.out.println("x= "+o.x+" y="+Outer.y);
      o.m2();
      o.m3();
      o.n.m(o);
      o.n.m1(o);
   }
}