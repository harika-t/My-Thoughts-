package alpha;
import beta.*;
import gamma.*;
public class Harika
{
   public static void main(String Vk[])
   {
      System.out.println("Harika Class");
      System.out.println("Virat Class : "+Virat.d);
      JungKook.cse();
   }
}