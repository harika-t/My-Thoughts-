import java.io.*;
public class FileAsg2
{
   public static void main(String Jk[]) throws Exception
   {
     FileReader fr = new FileReader(Jk[0]);
     FileWriter fw = new FileWriter(Jk[1]);
     //FileWriter fw1 = new FileWriter(Jk[2]);
     BufferedReader br = new BufferedReader(fr);
     BufferedWriter bw = new BufferedWriter(fw);
     //BufferedWriter bw1=new  BufferedWriter(fw1);
     String line=br.readLine();
     String line1=br.readLine();
     while(line!=null&&line1!=null)
     {
         int c=1;  
         if(line=="-1")
           break;
         else
         {
            if(line.equals(line1))
            {
                c++;
                line1="-1";
            }
            if(line!="-1"&&c!=1)
            {
                line=br.readLine();
                line1=br.readLine();
            }
            else
            {
                bw.write(line);
                bw.newLine();
                bw.flush();
                line=br.readLine();
                //line1=br.readLine();
            }
         }              
     }
  br.close();
  fr.close();
   }
}