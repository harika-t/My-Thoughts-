package in.ac.rguktsklm;
import in.ac.rguktnuzvid.*;
class Scs
{
   public static void main(String Vk[])
   {
      Ncs n=new Ncs();
      n.ncsa();
      n.ncsb();
      n.ncsc();
   }
}