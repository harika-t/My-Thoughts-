import java.lang.*;
class Test
{
   int a,b;
   Test(int i,int j)
   {
      a=i;b=j;
   }
   Test(Test c)
   {
      a=c.a+c.b;
      c.b=c.a+a;
   }
   Test(int i)
   {
      b=i;
   }
   void m(int i)
   {
     a=i;
   }
   void m1(Test j)
   {
     a=j.a+j.b;
     System.out.println("From m1 method : a : "+a+" b : "+b);
   }
}
class ObjInConstr
{
   public static void main(String jk[])
   {
      Test o=new Test(15,20);
      Test o1=new Test(1);
      Test o2=new Test(o);
      System.out.println("Object o2-a Value : "+o2.a+" b value is : "+o2.b);
      System.out.println("Object o1-a Value : "+o1.a+" b value is : "+o1.b);
      System.out.println("Object o-a Value : "+o.a+" b value is : "+o.b);
      o.m(40);
      o2.m1(o);
   }
}
  