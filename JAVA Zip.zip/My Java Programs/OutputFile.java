import java.io.*;
public class OutputFile
{
    public static void main(String Jk[]) throws Exception
    {
        /*FileOutputStream fos=new FileOutputStream("cse.txt",false);
            fos.write('J');
            fos.write('K');//Appends K to J
            fos.write('V');//Appends V to JK
            System.out.print("Successfully data written");*/
            File f=new File("cse.txt");
         //   FileOutputStream fos=new FileOutputStream(f,true);
         //   /*fos.write('J');
         //   */fos.write(65);
         //   //String s="Virat Kohli Jeon JungKook";
         //    //String s="Shubman Gill";//Appends the text
         //    String s="Ishaan Kishan";//Appends at the end of Vk Jk Sg
         //   byte[] b=s.getBytes();//String to Byte
         //   fos.write(b);  
         // For Overriding
            FileOutputStream fos=new FileOutputStream(f);
            String s="Virat Kohli Jeon JungKook";//ENtire text is overridden by this
            byte[] b=s.getBytes();//String to Byte
            fos.write(b);
            System.out.print("Successfully data written");
            fos.close();
    }
}