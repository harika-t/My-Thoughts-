interface Vehicle
{
   void seatcapacity();
   void ac();
}
class lorry implements Vehicle
{
   void seatcapacity()
   {
      System.out.println("Seat capacity is 3");
   }
   void ac()
   {
      System.out.println("AC is not required for lorry");
   }
}
class car implements Vehicle
{
   void seatcapacity()
   {
      System.out.println("Seat capacity is 6");
   }
   void ac()
   {
      System.out.println("AC is required for car");
   }
}
abstract class bus implements Vehicle
{
   void seatcapacity()
   {
      System.out.println("Seat capacity is 46");
   }
   abstract void ac();
}
class acbus extends bus
{
   void ac()
   {
       System.out.println("AC is not required for Non-AC buses");
   }
}