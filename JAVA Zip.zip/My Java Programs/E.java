import java.util.Scanner;
class E
{
      static int i[]=new int[5];
      public static void main (String t[])
      {
           Scanner s=new Scanner(System.in);
           for(int j=0;j<5;j++)
           {
               System.out.println("enter value:");
               i[j]=s.nextInt();
           }
           System.out.println("enter the subject number to get the marks:");
           int r=s.nextInt();
           readSubjectMarks(r);
      }
      public static void readSubjectMarks(int r)
      {
         try
           {
               System.out.println("entered subject marks are:"+i[r]);
           }
           catch(ArithmeticException d)
           {
              System.out.println("Denominator should not be zero");
              System.out.println(d);
           }
           catch(ArrayIndexOutOfBoundsException e)
           {
              System.out.println("Please enter valid subject");
              e.printStackTrace();//prints nature,name and line (where) exception occurs
              System.out.println("the exception is:"+e);//prints nature and name of the exception  
              System.out.println(e.getMessage());//prints only nature of the exception
           }
           catch(Exception s)
           {
              System.out.println("Error occured while running the program");
           }
           finally
           {
               System.out.println("last line of the program");
            }
     }
}