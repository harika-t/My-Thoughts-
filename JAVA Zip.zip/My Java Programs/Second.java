import java.lang.*;
class Second
{
   public static void main(int x)
   {
      System.out.println("Int method");
   }
   public static void main(String Jk[])//Program driver
   {
      System.out.println("Main method");
      main();
   }
   public static void main(float j)
   {
      System.out.println("Float method");
      main(5);
   }
   public static void main()
   {
      System.out.println("Method without arguments");
      main(5.5f);
   }
}