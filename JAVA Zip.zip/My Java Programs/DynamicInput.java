import java.io.*;
class DynamicInput
{
    public static void main(String Jk[]) throws Exception
    {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
     /*   System.out.print("Enter text : ");
        String name=br.readLine();
        System.out.println("Entered name is : "+name);
        System.out.print("Enter number : ");
        String f=br.readLine();
        System.out.println("Entered number is : "+f);
        System.out.print("Enter number : ");
        String s=br.readLine();
        System.out.println("Entered number is : "+s);
        int fval=Integer.parseInt(f);
        int sval=Integer.parseInt(s);
        int j=fval+sval;
        System.out.println("Sum is : "+j);  */


/*        System.out.print("Enter username : ");
        String name=br.readLine();
        System.out.print("Enter password : ");
        String pwd=br.readLine();
        if(name.equals("cse")&&pwd.equals("cse"))
            System.out.println("Login Successful");
        else
            System.out.println("Login Unsuccessful");     */



        Console c=System.console();
        String name=c.readLine("Enter username : ");
        char[] pwd=c.readPassword("Enter password : ");
        String password=new String(pwd);
        if(name.equals("cse")&&password.equals("cse"))
            System.out.println("Login Successful");
        else
            System.out.println("Login Unsuccessful");
    }
}