import java.lang.*;//Default package
class Ftypecasting
{
   public static void main(String Jk[])
   {
      int x='a';
      System.out.println(x);
      float f=10;
      System.out.println(f);
      int j=663;
      byte b=(byte)j;
      System.out.println(b);
   }
}