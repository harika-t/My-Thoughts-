import java.io.*;
import java.nio.charset.Charset;
class isr
{
   public static void main(String Jk[]) throws Exception
   {
    /*   char[] array=new char[200];
       FileInputStream fis=new FileInputStream("Add.java");
       //InputStreamReader isr=new InputStreamReader(fis);
       InputStreamReader isr1=new InputStreamReader(fis);
       InputStreamReader isr2=new InputStreamReader(fis,Charset.forName("UTF-8"));
       /*isr.read(array);
       System.out.println("Data in the stream is:");
       System.out.print(array);*/

    /*   System.out.println("Data in the stream is:");
       System.out.println("Without encoding : "+isr1.getEncoding());
       System.out.println("With encoding : "+isr2.getEncoding());   */



       String str="Virat Kohli Jeon JungKook";
       FileOutputStream fos=new FileOutputStream("abc.txt");
       OutputStreamWriter osw=new OutputStreamWriter(fos);
       osw.write(str);
       osw.flush();
       System.out.println("Success");
   }
}