import java.io.*;
class disdos
{
    public static void main(String Jk[]) throws Exception
    {
        FileOutputStream fos=new FileOutputStream("abc.txt");
        DataOutputStream dos=new DataOutputStream(fos);
       /* fos.write(100);//d
        fos.write('H'); */

        dos.writeUTF("Virat Kohli");
        dos.writeInt(68);
        dos.writeInt(69);
        dos.writeBoolean(true);


        FileInputStream fis=new FileInputStream("abc.txt");
        DataInputStream dis=new DataInputStream(fis);
        String s=dis.readUTF();
        int n=dis.readInt();
        int m=dis.readInt();
        Boolean str=dis.readBoolean();
        System.out.println(s);
        System.out.println(n);
        System.out.println(m);
        System.out.println(str);
        System.out.println("Success");
    }
}