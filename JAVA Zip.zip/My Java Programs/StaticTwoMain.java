import java.lang.*;
class StaticTwoMain
{
   static class Nested
   {
      static void m()
      {
         System.out.println("m method called");
      }
      public static void main(String Jk[])
      {
         System.out.println("static nested class called");
      }
   };
   public static void main(String Jk[])
   {
      System.out.println("Main method of outer class");
   }
}