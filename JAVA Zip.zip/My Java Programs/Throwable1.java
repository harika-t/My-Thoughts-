import p1.Kat;
class Throwable1
{
           public static void main(String a[])
           {
                
                String s1=a[0];
                String s2=a[1];
                Kat k1=new Kat();
                k1.div(s1,s2);
            }
}