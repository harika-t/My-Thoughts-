//To print Welcome to CSE Department
import java.lang.*;
class Welcome
{
   public static void main(String Jk[])
   {
      System.out.print("Welcome to CSE Department");
   }
}