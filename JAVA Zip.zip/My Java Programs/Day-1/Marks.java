//To print total and percentage of marks obtained
import java.lang.*;
import java.util.Scanner;
class Total
{
   int i;
   void input()
   { 
      Scanner sc=new Scanner(System.in);
      System.out.print("Enter number of subjects : ");
      int n=sc.nextInt();
      int a[]=new int[n];
      for(i=0;i<n;i++)
      {
         a[i]=sc.nextInt();
         if(!(a[i]>=0&&a[i]<=100))
         {
             System.out.println("Enter marks between 0-100 only!!!");
             i--;continue;
         }
      }
     sum(a,n);
   }
   void sum(int a[],int n)
   {
       float s=0;
       for(i=0;i<n;i++)
       {
          s=s+a[i];
       }
    System.out.println("Total marks of the student are "+s);
    System.out.print("Percentage of marks obtained is "+(s/(n*100))*100+" %");
   }
}
class Marks
{
   public static void main(String Vk[])
   {
      Total t=new Total();
      t.input();
   }
}