import java.lang.*;
import java.util.*;
class Calci
{
  public static void main(String arg[])
{ 
  double t=0,a=0;
  double b=0;
  int f=1,n;
  System.out.println("enter the first value");
  Scanner sc=new Scanner(System.in);
  a=sc.nextDouble();
  if(!(a>=0&&a<=9))
  System.exit(0);
 else
 {
 while(true)
 {
  System.out.println("1)+   2)-  3)*  4)/  5)% 6)calculate 7)exit");
  System.out.println("choose opration");
  n=sc.nextInt();
  if(n>7)
  {System.out.println("wrong choice");}
  else
  {
   if(n<6)
   {
   System.out.println("enter the next value");
   b=sc.nextDouble();
   if(!(b>=0&&b<=9))
   break;
   }
  switch(n)
  { 
     case 1:a=a+b;
            break;
     case 2:a=a-b;
            break;
     case 3:a=a*b;
            break;
     case 4:if(b==0)
            {
            f=0;
            System.out.println("not possible to calculate");
            System.exit(0);
            }
            else
            a=a/b;
            break;
     case 5:a=a%b;
            break;
     case 6:if(f==1)
            System.out.println("res="+a);
            break;
     case 7:System.exit(0);
            break;
     default:System.out.println("wrong choice");
  }
}
}
}
}
}
