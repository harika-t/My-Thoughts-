//To display total and percenatge of each student
import java.lang.*;
import java.util.Scanner;
class Student
{
       int i,j;
        void input()
        {
              Scanner sc=new Scanner(System.in);
              System.out.print("Enter the number of students:");
              int n=sc.nextInt();
              System.out.print("Enter the number of subjects:");
              int m=sc.nextInt();
               int a[][]=new int[n][m];
              for(i=0;i<n;i++)
              {
                      System.out.println("Enter the marks for each subject of the student:");
                      for(j=0;j<m;j++)
                      {
                          a[i][j]=sc.nextInt();
                          if(!(a[i][j]>=0&&a[i][j]<=100))
                           {
                              System.out.println("Enter marks between 0-100 only!!!");
                              j--;continue;
                           }
                            
                      }  
              }
            float total=m*100;
            calculate(a,n,m,total);
        }
       void calculate(int a[][],int n,int m,float total)
       {
               for(i=0;i<n;i++)
            {
                   float sum=0;
                   for(j=0;j<m;j++)
                   {
                           sum=sum+a[i][j];
                   }
                  System.out.println("Total marks of student is  "+sum);
                 System.out.println("Percentage of student is  "+(sum/total)*100+" %");
            }
       }
}
class Percentage
{
    public static void main(String Vk[])
    {
          Student h=new Student();
          h.input();
    }
}