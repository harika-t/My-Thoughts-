 //Roots of the given quadratic equation
import java.lang.*;
import java.util.*;
class Quadratic
{        
        void input()
        {
             Scanner sc=new Scanner(System.in);
             System.out.print("Enter the coefficient of x^2 : ");
             int a=sc.nextInt();
             System.out.print("Enter the coefficient of x^1 : ");
             int b=sc.nextInt();
             System.out.print("Enter the value of constant : ");
             int c=sc.nextInt();
             int d=b*b-4*a*c;
             if(d>0)
             {
                   System.out.println("The roots of the quadratic equation are real and distinct");
                   double root1=((-b)+Math.sqrt(d))/(2*a);
                   double root2=((-b)-Math.sqrt(d))/(2*a);
                   System.out.println("The roots are : root1 is :"+root1+" and root2 is : "+root2);
             }
             else if(d==0)
             {
                   System.out.println("The roots of the quadratic equation are real and equal");
                   double root1=(-b)/(2*a);
                   System.out.println("The roots are : root1 = root2 = "+root1);
             }
             else
             {
                   System.out.println("The roots of the quadratic equation are imaginary and distinct");
                   System.out.println("The roots are root1 = "+((-b/(2*a))+"+i"+(Math.sqrt(-d))/(2*a)));
                   System.out.print(" and root2 = "+((-b/(2*a))+"-i"+(Math.sqrt(-d))/(2*a)));
             }
        }
}
class QuadraticEquation
{
      public static void main(String Vk[])
      {
         Quadratic h=new Quadratic();
         h.input();
      }
}