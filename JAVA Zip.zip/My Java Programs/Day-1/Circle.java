//Calculate area of circle using scanner classes
import java.lang.*;
import java.util.Scanner;
class Area
{
   void input()
   {
      System.out.print("Enter radius of circle :");
      Scanner sc=new Scanner(System.in);
      float r=sc.nextFloat();
      ar(r);
   }
    void ar(float r)
    {
       System.out.print("The area of circle of radius "+r+" is "+3.14*r*r);
    }   
}
class Circle
{
   public static void main(String Vk[])
{
   Area a=new Area();
   a.input();
}
}

