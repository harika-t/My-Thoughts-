//To calculate the distance travelled in a given number of days
import java.lang.*;
class Distance
{
   public static void main(String Vk[])
   {
    //186000 miles
      long day=Integer.parseInt(Vk[0]);
      long dist=day*24*60*60*186000;
      System.out.print("Distance travelled by light in "+day+" days is "+dist+" miles");
   }
}