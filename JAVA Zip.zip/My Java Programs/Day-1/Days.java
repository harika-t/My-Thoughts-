//To print number of days in a month in a year
import java.lang.*;
class Cal
{ 
   void calculate(int month,int year)
   {
     if(month==2)
     {
        if(((year%4)==0&&(year%100)!=0)||(year%400)==0)
        {
          System.out.print("Number of days in month "+month+ " in "+year+" is 29");  
        }
        else
        {
           System.out.print("Number of days in month "+month+ " in "+year+" is 28");
        }
     }
      else
      {
         if((month==1)||(month==3)||(month==5)||(month==7)||(month==8)||(month==10)||(month==12))
         {
            System.out.print("Number of days in month "+month+ " in "+year+" is 31");
         }
         else if((month==4)||(month==6)||(month==9)||(month==11))
         {
            System.out.print("Number of days in month "+month+ " in "+year+" is 30");
         }
         else
         {
             System.out.print("Number of days in month "+month+ " in "+year+" is 28");
         }
      }
   }
}
class Days
{
   public static void main(String Vk[])
   {
      if(Vk.length!=2)
      {
         System.out.print("Enter two parameters only....Month and year");
      }
      else
      {
         int month=Integer.parseInt(Vk[0]);
         int year=Integer.parseInt(Vk[1]);
         Cal c=new Cal();
         if(month>=1&&month<=12&&year>0)
         c.calculate(month,year);
         else
         System.out.print("Enter valid years and month");
      }
   }
}