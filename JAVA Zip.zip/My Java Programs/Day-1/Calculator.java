//To implement a simple calculator
import java.lang.*;
import java.util.*;
class Calc
{
       void input()
       {
            System.out.println("1.Addition 2.Subtraction 3.Multiplication 4.Division 5.Modulo Division 6.Exit");
              while(true)
              {
                Scanner sc=new Scanner(System.in);
                System.out.print("Enter first operand : ");
                int op1=sc.nextInt();
                System.out.print("Enter second operand : ");
                int op2=sc.nextInt();
                System.out.print("Enter your choice:");
                int ch=sc.nextInt();
                switch(ch)
                {
                    case 1:System.out.println("Addition of numbers is : "+(op1+op2));
                           break;
                    case 2:System.out.println("Difference(Subtraction) between numbers is : "+(op1-op2));
                           break;
                    case 3:System.out.println("Product of numbers(Multiplication) is : "+(op1*op2));
                           break;
                    case 4:
                          if(op2==0)
                          System.out.println("Division by zero leads to undefined value");
                          else
                          System.out.println("Division of numbers is : "+(op1/op2));
                          break;
                    case 5:if(op2==0)
                          System.out.println("Division by zero leads to undefined value");
                          else
                          System.out.println("Division of numbers is : "+(op1%op2));
                          break;
                    case 6:System.exit(1);
                    default:System.out.println("Invalid choice");
                }
             }
      }
}
class Calculator
{
     public static void main(String Vk[])
     {
           Calc h=new Calc();
           h.input();
     }
}