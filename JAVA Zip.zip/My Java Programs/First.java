import java.lang.*;
class Mul
{
  int a,b,c;
  void assign()
  { 
    a=3;b=4;
  }
  void multiply()
  {
    c=a*b;
  }
  void display()
  {
    System.out.println("Multiplication of two numbers is:"+c);
  }
}
class Add
{
  static int a=10;
  int b=20;
  static void sum()
  {
    System.out.println("Static 'a' value :"+a);
    Add l=new Add();//Rule 3
    System.out.println("Instance 'b' value :"+l.b);
  }
  void imul()
  {
    Add.sum();//Rule 4
  }
  static void sub()
  {
    sum();//Rule 1
  }
  void jmul()
  { 
    imul();//Rule 2
    sub();
  }
}
class First
{ 
 public static void main(String vk[])
 {
    System.out.println("From main method");
    Mul m=new Mul();
    m.assign();
    m.multiply();
    m.display();
    System.out.println("End of main method");
    // Add.sum();
    Add j=new Add();
    j.imul();
    Add.sub();
    System.out.println("Calling instance to instance within class");
    j.jmul();
 }
 
}
