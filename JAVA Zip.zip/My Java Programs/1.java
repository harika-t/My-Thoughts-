import java.util.*;
class nextToken
{
   public static void main(String args[])
   {
       StringTokenizer st=new StringTokenizer("computer,is,electronic,device.");
       System.out.println(st.nextToken(","));
   }
}