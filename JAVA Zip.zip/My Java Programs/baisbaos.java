import java.io.*;
class baisbaos
{
   public static void main(String JK[]) throws Exception
   {
        byte[] array={1,2,3,4,5,6,7,8,9};
     /*   ByteArrayInputStream bais=new ByteArrayInputStream(array);
        for(int i=0;i<array.length;i++)
        {
           int data=bais.read();
           bais.skip(2);
           if(data==-1)
              break;
           System.out.println(data);
        }  */

        

        FileOutputStream fos1=new FileOutputStream("f1.txt"); 
        FileOutputStream fos2=new FileOutputStream("f2.txt"); 
        FileOutputStream fos3=new FileOutputStream("f3.txt");         
        ByteArrayOutputStream baos=new ByteArrayOutputStream();
        baos.write('H');
        baos.writeTo(fos1);
        baos.writeTo(fos2);
        baos.writeTo(fos3);
        baos.flush();
        System.out.println("Success");
        baos.close();
   }
}