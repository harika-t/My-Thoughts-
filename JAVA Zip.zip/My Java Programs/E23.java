import java.lang.*;
class Bc
{
   public String s;
   public static Bc b=null;
   private Bc()
   {
      s="cse";
   }
   public static Bc m()
   {
      if(b==null)
         b=new Bc();
      return b;
   }
}
class E23
{
   public static void main(String Jk[])//Program driver
   {
      Bc a=Bc.m();
      Bc b=Bc.m();
      Bc c=Bc.m();
      System.out.println("Address is"+a);
      System.out.println("Address is"+b);
      System.out.println("Address is"+c);
    }
}