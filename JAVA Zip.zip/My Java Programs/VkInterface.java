interface Vehicle
{
   void seatcapacity();
   void ac();
}
class lorry implements Vehicle
{
   public void seatcapacity()
   {
      System.out.println("Seat capacity is 3");
   }
  public void ac()
   {
      System.out.println("AC is not required for lorry");
   }
}
class car implements Vehicle
{
   public void seatcapacity()
   {
      System.out.println("Seat capacity is 6");
   }
   public void ac()
   {
      System.out.println("AC is required for car");
   }
}
abstract class bus implements Vehicle
{
   public void seatcapacity()
   {
      System.out.println("Seat capacity is 46");
   }
   abstract public void ac();
}
class acbus extends bus
{
   public void ac()
   {
       System.out.println("AC is required for AC buses");
   }
}
class nonac extends bus
{
   public void ac()
   {
       System.out.println("AC is not required for Non-AC buses");
   }
}
class VkInterface
{
   public static void main(String Vk[])
   {
       //lorry l=new lorry();
       Vehicle l=new lorry();
       l.seatcapacity();
       l.ac();
       Vehicle c=new car();
       c.seatcapacity();
       c.ac();
       bus n=new nonac();
       n.seatcapacity();
       n.ac();
       bus a=new acbus();
       a.seatcapacity();
       a.ac();
   }
}