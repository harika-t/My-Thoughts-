import java.io.*;
public class BufferedFile
{
    public static void main(String Jk[]) throws Exception
    {
      //   FileReader fr=new FileReader("Add.java");
      //   BufferedReader br=new BufferedReader(fr); //Passing reader object
         /*int i=0;
         while((i=br.read())!=-1)
            System.out.print((char)i);
         */
         /*String line=br.readLine();
         while(line!=null)
         {
             System.out.println(line);
             line=br.readLine();
         }
        br.close();
        fr.close();*/


       /* FileWriter fw=new FileWriter("abc.txt");
        BufferedWriter bw=new BufferedWriter(fw);
        bw.write(100);
        bw.write("\nVirat Kohli Jeon JungKook"); //This data is appended to d 
        //  \n is not supported here..so we go for newLine()
        bw.newLine();
        bw.write("Virat Kohli Jeon JungKook");
        char[] ch={'r','g','u','k','t'};
        bw.write(ch);//rgukt is appended
        bw.flush();  */


      /*  PrintWriter pw=new PrintWriter("abc.txt");
        pw.write(100);  //d
        pw.print(100);  //100
        pw.println(100);
        pw.println(100); 
        pw.println(100); //Appends in the next line
        pw.flush();  */


        FileWriter fw=new FileWriter("abc.txt",true); //Appends data
        PrintWriter pw=new PrintWriter(fw);
        pw.print("Cse");
        pw.print("Cse");
        pw.flush();
        System.out.println("Completed successfully");
    }
}