import java.util.*;
class C1
{
   int a=5;
   int b=6;
   void show()
   {
      System.out.println("Values of a and b from Base class are : "+a+" and "+b);
   }
};
class C2 extends C1
{
   int c=10;
   void display()
   {
      System.out.println("Values of a and b from Derived class are : "+a+" and "+b);
      System.out.println("Value of c from Derived class is : "+c);
   }
};
class A4
{
   public static void main(String Jk[])
   {  
      System.out.println("Main method starts execution");
      C2 c=new C2();
      c.show();
      c.display();
   }
}