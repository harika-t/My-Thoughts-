//A Java class to test the encapsulated class.  
//package pack;  
import pack.*;
class B82
{  
    public static void main(String[] args)
    {  
    //creating instance of the encapsulated class  
    B81 s=new B81();  
    //setting value in the name member  
    s.setName("Harika");  
    //getting value of the name member  
    System.out.println(s.getName());  
    }  
}  
