package com.javatpoint;  
class LAB8B{  
public static void main(String[] args){   
Student s=new Student();   
s.setName("Harika");   
System.out.println(s.getName());  
}  
}
