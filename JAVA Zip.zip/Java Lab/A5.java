import java.lang.*;
abstract class Animal
{
    public abstract void sound();
};
class Dog extends Animal
{
    public void sound()
    {
       System.out.println("Dog sound");
    }
};
class Cat extends Animal
{
    public void sound()
    {
       System.out.println("Cat sound");
    }
};
class A5
{
     public static void main(String k[])
     {
         System.out.println("main method starts execution");
         //Animal a=new Animal();
         //object creation is not allowed directly
         Animal a;
         a=new Dog();
         a.sound();
         a=new Cat();
         a.sound();
     }
}