interface Vehicle
{
    void seatcapacity();
    void ac();// public abstract
}
class lorry implements Vehicle
{
    public void seatcapacity()
    {
       System.out.println(" seat capacity is 3");
    }
    public void ac()
    {
       System.out.println(" Ac not required for lorry");
    }
};
class car implements Vehicle
{
    public void seatcapacity()
    {
       System.out.println(" seat capacity is 6");
    }
    public void ac()
    {
       System.out.println(" Ac is required for Car");
    }
};
abstract class bus implements Vehicle
{
    public void seatcapacity()
    {
       System.out.println(" seat capacity is 46");
    }
    public abstract void ac();
};
class nonac extends bus
{
     public void ac()
     {
        System.out.println(" Ac not required for Non ac buses");
     }
};
class acbus extends bus
{
     public void ac()
     {
        System.out.println(" Ac required to ac buses");
     }
};
class B5
{
     public static void main(String args[])
     {
          //lorry l=new lorry();
          Vehicle l=new lorry();
          l.seatcapacity();
          l.ac();
          Vehicle c=new car();
          c.seatcapacity();
          c.ac();
          bus n=new nonac();
          n.seatcapacity();
          n.ac();
          bus a=new acbus();
          a.seatcapacity();
          a.ac();
     }
};