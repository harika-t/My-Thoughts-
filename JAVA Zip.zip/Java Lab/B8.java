package com.java;  
class B8{  
public static void main(String[] args){   
Student s=new Student();   
s.setName("Harika");   
System.out.println(s.getName());  
}  
}
