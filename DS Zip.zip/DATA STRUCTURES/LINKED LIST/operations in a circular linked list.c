#include<stdio.h>
#include<stdlib.h>
struct node 
{
	int data;
	struct node *link;
};
struct node *root=NULL;
void append()
{
	struct node *temp;
	temp=(struct node*)malloc(sizeof(struct node));
	printf("Enter node data:");
	scanf("%d",&temp->data);
	temp->link=NULL;
	if(root==NULL)
	{
		root=temp;
		temp->link=root;
	}
	else
	{
		struct node *h;
		h=root;
		while(h->link!=root)
		{
			h=h->link;
		}
		h->link=temp;
		temp->link=root;
	}
}
void addatbegin()
{
	struct node *temp;
	temp=(struct node*)malloc(sizeof(struct node));
	printf("Enter node data:");
	scanf("%d",&temp->data);
	temp->link=NULL;
	if(root==NULL)
	{
		root=temp;
		temp->link=root;
	}
	else
	{
		struct node *h=root;
		while(h->link!=root)
		{
			h=h->link;
		}
		h->link=temp;
		temp->link=root;
		root=temp;
	}
}
int length()
{
	struct node *temp;
	int count=0;
	temp=root;
	if(root==NULL)
	{
		printf("No elements are there in the circular linked list\n");
	}
	else
	{
		while(temp->link!=root)
		{
			count++;
			temp=temp->link;
		}
		count++;
		return count;
	}
}
void display()
{
	struct node *temp;
	temp=root;
	if(root==NULL)
	{
		printf("No nodes to display\n");
	}
	else
	{
		while(temp->link!=root)
		{
			printf("%d\n",temp->data);
			temp=temp->link;
		}
		printf("%d\n",temp->data);
	}
}
void addatafter()
{
	struct node *temp,*h;
	int loc,i=1;
	printf("Enter location:");
	scanf("%d",&loc);
	if(loc>length())
	{
		printf("Invalid location\n");
	}
	else
	{
		h=root;
		while(i<loc)
		{
			h=h->link;
			i++;
		}
		temp=(struct node*)malloc(sizeof(struct node));
		printf("Enter node data:");
		scanf("%d",&temp->data);
		temp->link=NULL;
		temp->link=h->link;
		h->link=temp;
	}
}
void delete()
{
	struct node *temp;
	int loc,i=1;
	printf("Enter location:");
	scanf("%d",&loc);
	if(loc>length())
	{
		printf("Invalid location\n");
	}
	else if(loc==1)
	{
		struct node *h=root;
		temp=root;
		while(h->link!=root)
		{
			h=h->link;
		}
		root=temp->link;
		temp->link=NULL;
		h->link=root;
		free(temp);
	}
	else
	{
		struct node *h=root,*v;
		while(i<loc-1)
		{
			h=h->link;
			i++;
		}
		v=h->link;
		h->link=v->link;
		v->link=NULL;
		free(v);
	}
}
main()
{
	int ch;
	while(1)
	{
		printf("Circular linked list operations:\n");
		printf("1.Append\n");
		printf("2.Add at begin\n");
		printf("3.Add at after\n");
		printf("4.Length\n");
		printf("5.Display\n");
		printf("6.Delete\n");
		printf("7.Quit\n");
		printf("Enter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:append();
			break;
			case 2:addatbegin();
			break;
			case 3:addatafter();
			break;
			case 4:printf("Length of the circular linked list is %d\n",length());
			break;
			case 5:display();
			break;
			case 6:delete();
			break;
			case 7:exit(1);
			break;
		}
	}
}
