#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *right;
	struct node *left;
};
struct node *root=NULL;
void display()
{
	struct node *temp=root;
	if(temp==NULL)
	{
		printf("List is empty\n");
	}
	else
	{
		while(temp!=NULL)
		{
			printf("%d\n",temp->data);
			temp=temp->right;
		}
	}
}
void append()
{
	struct node *temp;
	temp=(struct node*)malloc(sizeof(struct node));
	printf("Enter node data:");
	scanf("%d",&temp->data);
	temp->right=NULL;
	temp->left=NULL;
	if(root==NULL)
	{
		root=temp;
	}
	else
	{
		struct node *p;
		p=root;
		while(p->right!=NULL)
		{
			p=p->right;
		}
		p->right=temp;
		temp->left=p;
	}
	display();
}
void addbegin()
{
	struct node *temp;
	temp=(struct node*)malloc(sizeof(struct node));
	printf("Enter node data:");
	scanf("%d",&temp->data);
	temp->left=NULL;
	temp->right=NULL;
	if(root==NULL)
	{
		root=temp;
	}
	else
	{
		temp->right=root;
		root->left=temp;
		root=temp;
	}
	display();
}
int length()
{
	struct node *temp=root;
	int count=0;
	while(temp!=NULL)
	{
		count++;
		temp=temp->right;
	}
	return count;
}
void addafter()
{
	struct node *temp,*p;
	p=root;
	int loc,i=1;
	printf("Enter location:");
	scanf("%d",&loc);
	if(loc>length())
	{
		printf("Invalid location\n");
	}
	else
	{
		temp=(struct node*)malloc(sizeof(struct node));
		printf("Enter node data:");
		scanf("%d",&temp->data);
		temp->left=NULL;
		temp->right=NULL;
		while(i<loc)
		{
			p=p->right;
			i++;
		}
		temp->right=p->right;
		p->right->left=temp;
		p->right=temp;
		temp->left=p;
	}
	display();
}
void delete()
{
	struct node *temp;
	int loc;
	printf("Enter the location:");
	scanf("%d",&loc);
	if(loc>length())
	{
		printf("Invalid location\n");
	}
	else if(loc==1)
	{
		temp=root;
		root=temp->right;
		root->left=NULL;
		free(temp);
	}
	else if(loc==length())
	{
		temp=root;
		while(temp->right!=NULL)
		{
			temp=temp->right;
		}
		temp->left->right=NULL;
		temp->left=NULL;
		free(temp);
	}
	else
	{
		struct node *p=root,*q;
		int i=1;
		while(i<loc-1)
		{
			p=p->right;
			i++;
		}
		q=p->right;
		p->right=q->right;
		q->right->left=p;
		free(q);
	}
	display();
}
void main()
{
	int ch,len;
	while(1)
	{
		printf("Double linked list operations:\n");
		printf("1-Append\n2-Add at begin\n3-Add at after\n4-Length\n5-Display\n6-Delete\n7-Quit\n");
		printf("Enter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:append();
			break;
			case 2:addbegin();
			break;
			case 3:addafter();
			break;
			case 4:len=length();
			printf("Length of the list=%d\n",len);
			break;
			case 5:display();
			break;
			case 6:delete();
			break;
			case 7:exit(1);
			break;
			default :printf("Invalid choice!");
		}
	}
}
