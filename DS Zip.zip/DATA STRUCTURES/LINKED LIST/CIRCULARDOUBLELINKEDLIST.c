#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *left;
	struct node *right;
};
struct node *root=NULL;
void display()
{
	struct node *temp;
	temp=root;
	if(temp==NULL)
	{
		printf("No nodes to display!\n");
	}
	else
	{
		while(temp->right!=root)
		{
			printf("%d\n",temp->data);
			temp=temp->right;
		}
		printf("%d\n",temp->data);
	}
}
void append()
{
	struct node *temp,*p;
	temp=(struct node*)malloc(sizeof(struct node));
	printf("Enter node data:");
	scanf("%d",&temp->data);
	temp->left=NULL;
	temp->right=NULL;
	if(root==NULL)
	{
		root=temp;
		temp->right=root;
		temp->left=root;
	}
	else
	{
		p=root;
		while(p->right!=root)
		{
			p=p->right;
	    }
		temp->right=root;
		root->left=temp;
		p->right=temp;
		temp->left=p;
	}
	display();
}
void addbegin()
{
	struct node *temp,*p;
	temp=(struct node*)malloc(sizeof(struct node));
	printf("Enter node data:");
	scanf("%d",&temp->data);
	temp->right=NULL;
	temp->left=NULL;
	if(root==NULL)
	{
		root=temp;
		temp->right=root;
		temp->left=root;
	}
	else
	{
		p=root;
		while(p->right!=root)
		{
			p=p->right;
	    }
		p->right=temp;
		temp->left=p;
		temp->right=root;
		root->left=temp;
		root=temp;	
	}
	display();
}
int length()
{
	struct node *temp;
	int count=0;
	temp=root;
	while(temp->right!=root)
	{
		count++;
		temp=temp->right;
	}
	count++;
	return count;
}
void addafter()
{
	struct node *temp,*p;
	int loc,len,i=1;
	printf("Enter location:");
	scanf("%d",&loc);
	if(loc>length())
	{
		printf("Invalid location!");
	}
	else
	{
		temp=(struct node*)malloc(sizeof(struct node));
		printf("Enter node data:");
		scanf("%d",&temp->data);
		temp->right=NULL;
		temp->left=NULL;
		p=root;
		while(i<loc)
		{
			p=p->right;
			i++;
		}
		temp->right=p->right;
		p->right->left=temp;
		temp->left=p;
		p->right=temp;
	}
	display();
}
void delete()
{
	struct node *q;
	int loc,i=1;
	printf("Enter location:");
	scanf("%d",&loc);
	if(loc>length())
	{
		printf("Invalid location!\n");
	}
	else if(loc==1)
	{
		struct node *p=root;
		q=root;
		while(q->right!=root)
		{
			q=q->right;
		}
		q->right=p->right;
		p->right->left=q;
		root=p->right;
		free(p);
	}
	else if(loc==length())
	{
		struct node *p=root;
		while(p->right!=root)
		{
			p=p->right;
		}
		p->left->right=root;
		root->left=p->left;
		free(p);
	}
	else
	{
	    struct node *q=root,*p;
		while(i<loc-1)
		{
			q=q->right;
			i++;
		}	
		p=q->right;
		q->right=p->right;
		p->right->left=q;
		free(p);
	}
	display();
}
void main()
{
	int ch,len;
	while(1)
	{
		printf("Circular double linked list operations:\n");
		printf("1-Append\n");
		printf("2-Add at begin\n");
		printf("3-Add at after\n");
		printf("4-Length\n");
		printf("5-Display\n");
		printf("6-Delete\n");
		printf("7-Quit\n");
		printf("Enter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:append();
			break;
			case 2:addbegin();
			break;
			case 3:addafter();
			break;
			case 4:len=length();
			printf("Length of the list=%d\n",len);
			break;
			case 5:display();
			break;
			case 6:delete();
			break;
			case 7:exit(1);
			break;
			default:printf("Invalid choice\n");
		}
	}
}
