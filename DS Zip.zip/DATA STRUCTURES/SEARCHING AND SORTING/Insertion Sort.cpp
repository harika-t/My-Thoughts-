#include<stdio.h>
main()
{
	int i,j,temp,n,arr[50];
	printf("Enter number of elements:");
	scanf("%d",&n);
	printf("Enter elements:\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	}
	for(i=1;i<n;i++)
	{
		temp=arr[i];
		j=i-1;
		while((j>=0)&&(temp<arr[j]))
		{
			arr[j+1]=arr[j];
			j--;
		}
		arr[j+1]=temp;
	}
	printf("Sorted elements are:\n");
	for(i=0;i<n;i++)
	{
		printf("%d\t",arr[i]);
	}
}
