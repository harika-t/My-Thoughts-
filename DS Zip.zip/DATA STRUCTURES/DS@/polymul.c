#include<stdio.h>
#include<stdlib.h>
struct node
{
	int coef;
	int expo;
	struct node*next;
};
struct node*start,*start1,*start2,*temp,*ptr;
int g=0;
int sort(struct node *start)
{
	struct node*ptr1,*ptr2;
	int c=0;
	ptr1=start;ptr2=start;
while(ptr1->next!=NULL)
{
	ptr2=ptr1->next;
	while(ptr2!=NULL)
	{
		if(ptr1->expo<ptr2->expo)
		{
			c=ptr1->expo;
			ptr1->expo=ptr2->expo;
			ptr2->expo=c;c=0;
			c=ptr1->coef;
			ptr1->coef=ptr2->coef;
			ptr2->coef=c;
		}
		ptr2=ptr2->next;
	}
	ptr1=ptr1->next;
}
}
int create1()
{
	int n,i,f=0,m,c=0,x=1;
   do{
       temp=(struct node*)malloc(sizeof(struct node));
       printf("enter the coefficient into node,or -1 to exit:\n");
          scanf("%d",&temp->coef);
     if(temp->coef==-1)
     {
       x=0;
         }
          else
        {
       printf("enter the exponential into node\n");
         scanf("%d",&temp->expo);
       temp->next=NULL;
         if(start==NULL)
        {
          start=temp;
         }
          else
      {
	ptr=start;
	while(ptr->next!=NULL)
	{
		ptr=ptr->next;
	}
	ptr->next=temp;
        }
       }
}while(x);
}
int create2()
{
	int n,i,f=0,m,c=0,x=1;
   do{
       temp=(struct node*)malloc(sizeof(struct node));
       printf("enter the coefficient into node,or -1 to exit:\n");
          scanf("%d",&temp->coef);
     if(temp->coef==-1)
     {
       x=0;
         }
          else
        {
       printf("enter the exponential into node\n");
         scanf("%d",&temp->expo);
       temp->next=NULL;
         if(start1==NULL)
        {
          start1=temp;
         }
          else
      {
	ptr=start1;
	while(ptr->next!=NULL)
	{
		ptr=ptr->next;
	}
	ptr->next=temp;
        }
       }
}while(x);
}
display(struct node *start)
{
	struct node*ptr1;
	ptr1=start;
	while(ptr1!=NULL)
	{
	    printf("%dx^%d+",ptr1->coef,ptr1->expo);
		ptr1=ptr1->next;
	}
	printf("\n");
}
void inneradd(struct node *start2 )
{
	struct node *ptr1,*ptr2,*q;
	ptr1=start2;
	ptr2=start2;
	 while(ptr1!=NULL)
	 {
	 	ptr2=ptr1->next;
	 	while(ptr2!=NULL)
	 	{
	 		if(ptr1->expo==ptr2->expo)
	 		{
	 			ptr1->coef=ptr1->coef+ptr2->coef;
	 			ptr1->next=ptr2->next;
	 			q=ptr2;
	 			ptr2=ptr2->next;
	 			free(q);
	 		}
	 		else
	 		{
	 	     ptr2=ptr2->next;
	        }
	    }
	    ptr1=ptr1->next;
     }
}
main()
{
	struct node*ptr1,*ptr2;
	printf("enter the first ploynomial :\n");
	create1();
	printf("\nenter the second second ploynomial :\n");
	create2();
	printf("first polynomial is\n");
	display(start);
	printf("second polynomial is\n");
	display(start1);
	sort(start);
	sort(start1);
	ptr1=start;
	ptr2=start1;
	temp=(struct node*)malloc(sizeof(struct node));
	start2=temp;
	ptr=start2;
	 while(ptr1!=NULL)
	 {    
		while (ptr2!=NULL)
		{
		   ptr->coef=ptr1->coef*ptr2->coef;
		   ptr->expo=ptr1->expo+ptr2->expo;
		   ptr2=ptr2->next;
		   temp=(struct node*)malloc(sizeof(struct node));
		   ptr->next=temp;
		   ptr=ptr->next;
	    }
	    ptr1=ptr1->next;
	    ptr2=start1;
	}
	sort(start2);
	display(start2);
    inneradd(start2);
    display(start2);
}
