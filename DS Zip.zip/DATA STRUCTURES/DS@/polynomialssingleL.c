#include<stdio.h>
#include<stdlib.h>
struct node
{
	int coef;
	int expo;
	struct node*next;
};
struct node*start1,*start2,*temp1,*temp2,*ptr1,*ptr2;
main()
{
	int n,i,f=0,m,c=0,x=1;
	printf("enter the data of first polynomial\n");
   do{
temp1=(struct node*)malloc(sizeof(struct node));
printf("enter the coefficient into node,or -1 to exit:\n");
scanf("%d",&temp1->coef);
if(temp1->coef==-1)
{
x=0;
}
else
{
printf("enter the exponential into node\n");
scanf("%d",&temp1->expo);
temp1->next=NULL;
if(start1==NULL)
{
start1=temp1;
}
else
{
	ptr1=start1;
	while(ptr1->next!=NULL)
	{
		ptr1=ptr1->next;
	}
	ptr1->next=temp1;
}
}
}while(x);x=1;
printf("enter the data of second polynomial\n");
do{
temp2=(struct node*)malloc(sizeof(struct node));
printf("enter the coefficient into node,or -1 to exit:\n");
scanf("%d",&temp2->coef);
if(temp2->coef==-1)
{
	x=0;
}
else
{
printf("enter the exponential into node\n");
scanf("%d",&temp2->expo);
temp2->next=NULL;
if(start2==NULL)
{
start2=temp2;
}
else
{
	ptr2=start2;
	while(ptr2->next!=NULL)
	{
		f++;
		ptr2=ptr2->next;
	}
	ptr2->next=temp2;
}
}
}while(x);
	ptr1=start1;
	ptr2=start2;
	 while(ptr1!=NULL&&ptr2!=NULL)
	 {
	 	
	 		if(ptr1->expo==ptr2->expo)
	 		{
	 			ptr1->coef=ptr1->coef+ptr2->coef;
	 			printf("%dx^%d + ",ptr1->coef,ptr1->expo);
	 			ptr1=ptr1->next;
	 		    ptr2=ptr2->next;
	 				
		    }
		    else if(ptr1->expo>ptr2->expo)
		    {
		    	printf("%dx^%d + ",ptr1->coef,ptr1->expo);
		    	ptr1=ptr1->next;
			}
			else
			{
				printf("%dx^%d + ",ptr2->coef,ptr2->expo);
				ptr2=ptr2->next;
			}	
		 }
		 while(ptr1!=NULL)
		 {
		 	printf("%dx^%d + ",ptr1->coef,ptr2->coef);
		 	ptr1=ptr1->next;
		 }
		 while(ptr2!=NULL)
		 {
		 	printf("%dx^%d + ",ptr2->coef,ptr2->coef);
		 	ptr2=ptr2->next;
		 }
}
	    
