#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node*next;
};
struct node*start,*temp,*ptr;
main()
{
	int n=1,i,m,c=0;
	do{
temp=(struct node*)malloc(sizeof(struct node));
printf("enter the data into node:\n");
scanf("%d",&temp->data);
temp->next=NULL;
if(temp->data==-1)
{
n=0;
}
else
{
if(start==NULL)
{
start=temp;
}
else
{
	ptr=start;
	while(ptr->next!=NULL)
	{
		ptr=ptr->next;
	}
	ptr->next=temp;
}
}
}while(n);
printf("enter the number to get its frequency\n");
scanf("%d",&m);
	ptr=start;
	while(ptr!=NULL)
	{
	   if(ptr->data==m)
	   c++;
	   ptr=ptr->next;
	}
	printf("the frequency of given data is %d",m);
}
