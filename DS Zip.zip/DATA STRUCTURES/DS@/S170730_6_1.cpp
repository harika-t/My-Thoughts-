#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node*next;
};
struct node*start,*temp,*ptr,*ptr1;
main()
{
	int n=1,c=0,l=0,t,j,k;
	do{
temp=(struct node*)malloc(sizeof(struct node));
printf("enter the data into node:\n");
scanf("%d",&temp->data);
temp->next=NULL;
if(temp->data==-1)
{
n=0;
}
else
{
if(start==NULL)
{
start=temp;
}
else
{
	ptr=start;
	while(ptr->next!=NULL)
	{
		ptr=ptr->next;
	}
	ptr->next=temp;
}
}
}while(n);
printf("enter the position j\n");
scanf("%d",&j);
printf("enter the position k\n");
scanf("%d",&k);
ptr1=start;
while(ptr1!=NULL)
{
	c++;
	if(c==j)
	{
		ptr=start;
		while(ptr!=NULL)
		{
			l++;
			if(l==k)
			{
				t=ptr1->data;
				ptr1->data=ptr->data;
				ptr->data=t;
			}
			ptr=ptr->next;
		}
	}
	ptr1=ptr1->next;
}
printf("data present in nodes\n");
	ptr=start;
	while(ptr!=NULL)
	{
		printf("%d->",ptr->data);
		ptr=ptr->next;
	}
}
