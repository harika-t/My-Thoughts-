#include<stdio.h>
main()
{
	int n,v,b,c;
	char *a[150]={"one","two","three","four","five","six","seven","eight","nine","ten","eleven","twelve","thirteen","fourteen","fifteen","sxteen","seventeen","eighteen","nineteen","twenty",a[29]="thirty",a[39]="fourty",a[49]="fifty",a[59]="sixty",a[69]="seventy",a[79]="eighty",a[89]="ninety"};
	int count1,count2,count,count3;
	count1=count2=count=count3=0;
	printf("Enter The Number\n");
	scanf("%d",&n);
	while(n>=10000000)
	{
		n=n-10000000;
		count3++;
	}
	if(n<10000000&&count3!=0)
	{
		c=count3%10;
		count3=count3/10;
		count3*=10;
		printf("%s%scrore ",*(a+(count3-1)),*(a+(c-1)));
	}
	while(n>=100000)
	{
		n=n-100000;
		count++;
	}
	if(n<100000&&count!=0)
	{
		b=count%10;
		count=count/10;
		count*=10;
		printf("%s%slakh ",*(a+(count-1)),*(a+(b-1)));
	}
	while(n>=1000)
	{
		n=n-1000;
		count1++;
	}
	if(n<1000&&count1!=0)
	{
		v=count1%10;
		count1=count1/10;
		count1*=10;
		printf("%s%sthousand ",*(a+(count1-1)),*(a+(v-1)));
	}
	while(n>=100)
	{
			n=n-100;
			count2++;
	}
	if(n<100&&count2!=0)
	{
			printf("%shundread and\n",*(a+(count2-1)));
	}
	while(n>=90)
	{
		n=n-90;
		printf("ninety ");
	}
	while(n>=80)
	{
		n=n-80;
		printf("eighty");
	}	
	while(n>=70)
	{
		n=n-70;
		printf("seventy");
	}
	while(n>=60)
	{
		n=n-60;
		printf("sixty");
	}
	while(n>=50)
	{
		n=n-50;
		printf("fifty");
	}
	while(n>=40)
	{
		n=n-40;
		printf("fourty");
	}	
	while(n>=30)
	{
		n=n-30;
		printf("thirty");
	}
	while(n>=20)
	{
		n=n-20;
		printf("twenty");
	}
	printf("%s",*(a+(n-1)));			
	}
