#include<stdio.h>
#include<stdlib.h>
struct node
{
	int coef;
	int expo;
	struct node*next;
};
struct node*start,*start1,*temp,*ptr,*temp1;
int sort(struct node *start)
{
	struct node*ptr1,*ptr2;
	int c=0;
	ptr1=start;ptr2=start;
while(ptr1->next!=NULL)
{
	ptr2=ptr1->next;
	while(ptr2!=NULL)
	{
		if(ptr1->expo<ptr2->expo)
		{
			c=ptr1->expo;
			ptr1->expo=ptr2->expo;
			ptr2->expo=c;c=0;
			c=ptr1->coef;
			ptr1->coef=ptr2->coef;
			ptr2->coef=c;
		}
		ptr2=ptr2->next;
	}
	ptr1=ptr1->next;
}
}
inneradd(struct node *start )
{
	struct node*ptr1,*ptr2,*q;
	ptr1=start;
	ptr2=start;
	 while(ptr1->next!=NULL)
	 {
	 	ptr2=ptr1->next;
	 	while(ptr2!=NULL)
	 	{
	 		if(ptr1->expo==ptr2->expo)
	 		{
	 			ptr1->coef=ptr1->coef+ptr2->coef;
	 			ptr1->next=ptr2->next;
	 			q=ptr2;
	 			ptr2=ptr2->next;
	 			free(q);
	 		}
	 		else
	 		{
	 	  ptr2=ptr2->next;
	        }
	    }
	    ptr1=ptr1->next;
     }
}
int create1()
{
	int n,i,f=0,m,c=0,x=1;
   do{
       temp=(struct node*)malloc(sizeof(struct node));
       printf("enter the coefficient into node,or -1 to exit:\n");
          scanf("%d",&temp->coef);
     if(temp->coef==-1)
     {
       x=0;
         }
          else
        {
       printf("enter the exponential into node\n");
         scanf("%d",&temp->expo);
       temp->next=NULL;
         if(start==NULL)
        {
          start=temp;
         }
          else
      {
	ptr=start;
	while(ptr->next!=NULL)
	{
		ptr=ptr->next;
	}
	ptr->next=temp;
        }
       }
}while(x);
}
int create2()
{
	int n,i,f=0,m,c=0,x=1;
   do{
       temp=(struct node*)malloc(sizeof(struct node));
       printf("enter the coefficient into node,or -1 to exit:\n");
          scanf("%d",&temp->coef);
     if(temp->coef==-1)
     {
       x=0;
         }
          else
        {
       printf("enter the exponential into node\n");
         scanf("%d",&temp->expo);
       temp->next=NULL;
         if(start1==NULL)
        {
          start1=temp;
         }
          else
      {
	ptr=start1;
	while(ptr->next!=NULL)
	{
		ptr=ptr->next;
	}
	ptr->next=temp;
        }
       }
}while(x);
}
int main()
{
	struct node*ptr1,*ptr2;
	printf("enter 1st equation\n");
	create1();
	printf("enter 2nd equation\n");
	create2();
	sort(start);
	sort(start1);
	inneradd(start);
	inneradd(start1);
	ptr1=start;
	ptr2=start1;
	 while(ptr1!=NULL&&ptr2!=NULL)
	 {
	 	
	 		if(ptr1->expo==ptr2->expo)
	 		{
	 			ptr1->coef=ptr1->coef+ptr2->coef;
	 			printf("%dx^%d + ",ptr1->coef,ptr1->expo);
	 			ptr1=ptr1->next;
	 		    ptr2=ptr2->next;
	 				
		    }
		    else if(ptr1->expo>ptr2->expo)
		    {
		    	printf("%dx^%d + ",ptr1->coef,ptr1->expo);
		    	ptr1=ptr1->next;
			}
			else
			{
				printf("%dx^%d + ",ptr2->coef,ptr2->expo);
				ptr2=ptr2->next;
			}	
		 }
		 return 0;

}
	    
