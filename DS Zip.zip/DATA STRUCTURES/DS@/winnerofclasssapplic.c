#include<stdio.h>
#include<stdlib.h>
struct node
{
	int id;
	struct node*next;
};
struct node*start,*temp,*ptr,*q;
main()
{
	int n=0,x=1,k;
	do{
temp=(struct node*)malloc(sizeof(struct node));
printf("enter the data into node:\n");
scanf("%d",&temp->id);
if(temp->id==-1)
{
	x=0;
	
}
else
{
if(start==NULL)
{
	start=temp;
	temp->next=start;
}
else
{
	ptr=start;
	while(ptr->next!=start)
	{
		ptr=ptr->next;
	}
	ptr->next=temp;
	temp->next=start;
}
}
}while(x);
printf("enter the number of person you want to eliminate continuesly\n");
scanf("%d",&k);
	ptr=start;
	while(ptr->next!=start)
	{
		n++;
		if(n==k-1)
		{
			q=ptr->next;
			ptr->next=ptr->next->next;
			q->next=NULL;
			free(q);
			start=ptr;
			n=0;
		}
		ptr=ptr->next;
	}
	printf("the winner of class is %d",ptr->id);
	
}
