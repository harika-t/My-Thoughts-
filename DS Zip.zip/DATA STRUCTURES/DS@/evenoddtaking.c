#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node*next;
};struct node*temp,*start,*ptr,*ptr1;
main()
{
int n=1,i,c1=0,c2=0;
	do{
temp=(struct node*)malloc(sizeof(struct node));
printf("enter the data into node:\n");
scanf("%d",&temp->data);
temp->next=NULL;
if(temp->data==-1)
{
n=0;
}
else
{
if(start==NULL)
{
start=temp;
}
else
{
	ptr=start;
	while(ptr->next!=NULL)
	{
		ptr=ptr->next;
	}
	ptr->next=temp;
}
}
}while(n);
ptr=start;
while(ptr!=NULL)
{
	if(ptr->data%2==0)
	c1++;
	else
	c2++;
	ptr=ptr->next;
}
if(c1%2==0)
{
	ptr=start;
	while(ptr!=NULL)
	{
		if(ptr->data%2!=0)
		printf("%d->",ptr->data);
		ptr=ptr->next;
	}
}
else
{
	ptr=start;
	while(ptr!=NULL)
	{
		if(ptr->data%2!=0)
		  {

			c1=0;
			for(i=2;i<ptr->data;i++)
			{
				if(ptr->data%i==0)
				c1++;
			}
			if(c1==0)
			ptr->data=ptr->data+1;
			else
			printf("%d->",ptr->data);
	      }
	      ptr=ptr->next;
	}
		
}
}
