#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct node
{
	struct node*lp;
	char song[20];
	char movie[30];
	struct node*rp;
};
struct node*start,*temp,*ptr;
int display()
{
	printf("data present in nodes\n");
     struct node*ptr=start;
	while(ptr->rp!=start)
	{
		printf("%s %s->",ptr->song,ptr->movie);
		ptr=ptr->rp;
	}
	printf("%s %s->",ptr->song,ptr->movie);
}
int next()
{
	ptr=ptr->rp;
	printf("curren song is %s",ptr->song);
}
int current()
{
	printf("currrnt song is %s",ptr->song);
}
int previous()
{
	ptr=ptr->lp;
	printf("current song is %s",ptr->song);
}
int add()
{
	temp=(struct node*)malloc(sizeof(struct node));
	printf("enter the song name\n");
	scanf("%s",&temp->song);
	printf("enter the movie name\n");
	scanf("%s",&temp->movie);
		while(ptr->rp!=start)
		{
			ptr=ptr->rp;
		}
		temp->lp=ptr;
		ptr->rp=temp;
		temp->rp=start;
		display();
}
int search()
{
   struct node*ptr1=start;
   char str[20];int f=0;
   printf("enter song name or movie name\n");
   scanf("%s",str);
   	while(ptr1->rp!=start)
   	{
   		if(strcmp(ptr1->song,str)==0||strcmp(ptr1->movie,str)==0)
   		{
   			f=1;
   			printf("song found\n");
   			break;
		}
		ptr1=ptr1->rp;
	}
	if(f==0)
	printf("song not found\n");
}
int count()
{
	struct node*ptr2=start;
	int c=0;
	while(ptr2->rp!=start)
	{
		c++;
		ptr2=ptr2->rp;
	}
	c=c+1;
	printf("the number of songs that the movie have are %d",c);
}
void Rename()
{
	char str[20];
	char str1[20];
	printf("enter which song you want to rename\n");
	scanf("%s",str);
	struct node*ptr1=start;
	while(ptr1->rp!=start)
	{
		if(strcmp(ptr1->song,str)==0)
		{
			printf("enter the new name\n");
			scanf("%s",str1);
			strcpy(ptr1->song,str1);
			break;
		}	
		ptr1=ptr1->rp;
	}
	display();
}
int del()
{
	char str[30];
	printf("enter the song name which you want to del\n");
	scanf("%s",str);
	struct node*ptr1=start;
	while(ptr1->rp!=start)
	{
		if(strcmp(ptr1->song,str)==0)
			break;
			ptr1=ptr1->rp;
	}
	ptr1->lp->rp=ptr1->rp;
	ptr1->rp->lp=ptr1->lp;
	ptr1->rp=NULL;
	ptr1->lp=NULL;
	free(ptr1);
	display();
}
int sort()
{
	char c[20],t[20];
	struct node*ptr1,*ptr2;
	ptr1=start;ptr2=start;
while(ptr1->rp!=start)
{
	ptr2=ptr1->rp;
	while(ptr2!=start)
	{
		if(strcmp(ptr1->song,ptr2->song)>0)
		{
			strcpy(c,ptr1->song);
			strcpy(t,ptr1->movie);
			strcpy(ptr1->song,ptr2->song);
			strcpy(ptr1->movie,ptr2->movie);
			strcpy(ptr2->song,c);
			strcpy(ptr2->movie,t);
		}
		ptr2=ptr2->rp;
	}
	ptr1=ptr1->rp;
}
display(); 
}
main()
{
	int x=1,m=0;
	char a;
		temp=(struct node*)malloc(sizeof(struct node));
	start=temp;
	temp->rp=temp;
	ptr=start;
	strcpy(temp->song,"hello");
	strcpy(temp->movie,"hello");
	while(m<=4){
		m++;
	temp=(struct node*)malloc(sizeof(struct node));
	switch(m)
	{
		case 1:strcpy(temp->song,"hoyna");
		       strcpy(temp->movie,"gld");
		       break;
		case 2:strcpy(temp->song,"buttabomma");
		       strcpy(temp->movie,"avlp");
		       break;
		case 3:strcpy(temp->song,"mindblock");
		       strcpy(temp->movie,"slnkv");
		       break;
		case 4:strcpy(temp->song,"neeve");
		       strcpy(temp->movie,"neeve");
		       break;
		default:strcpy(temp->song,"ramulo");
		       strcpy(temp->movie,"avlp");
		       break;
	}
	temp->lp=ptr;
	ptr->rp=temp;
	temp->rp=start;
	start->lp=temp;
	ptr=ptr->rp;
}
	printf("n.next\np.previous\na.add\ns.search\nc.count\nm.currentsong\nr.rename\nd.delete\nS.sort\ne.exit from musicplayer\n");
	while(1)
	{
	printf("\nenter the character\n");
	scanf("%c",&a);
	switch(a)
	{
		case 'n':next();
		break;
		case 'p':previous();
		break;
		case 'a':add();
		break;
		case 's':search();
		break;
		case 'c':count();
		break;
		case 'm':current();
		break;
		case 'r':Rename();
		break;
		case 'd':del();
		break;
		case 'S':sort();
		break;
		case 'e':exit(1);
		break;
		default:printf("invalid\n");
		break;
	}
   }
}
