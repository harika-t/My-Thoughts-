#include<stdio.h>
#include<string.h>
int top=-1,j=0,max=20;
char infix[20],a[40],post[30];
int push(char infix)
{
	if(top==max-1)
	printf("stack overflow");
	else
	{
	top++;
	post[top]=infix;
    }
}
int pop()
{
   if(top==-1)
   printf("stack underflow\n");
   else
   {
   	return a[top--];
	}	
}
int checkprec(char infixx,char infix1)
{
      if(infixx=='+'&&(infix1=='*'||infix1=='/'||infix1=='^'))
      {
      a[j]=pop();j++;
       }
      else //if(infixx=='+'&&infix1=='-')
      push(infixx);
      if(infixx=='-'&&(infix1=='*'||infix1=='/'||infix1=='^'))
      {
      a[j]=pop();j++;
      }
      if(infixx=='-'&&infix1=='+')
      push(infixx);
      if(infixx=='*'&&(infix1=='^'||infix1=='/'))
      {
	   a[j]=pop();
	   j++;
        }
      else //if(infixx=='*'&&(infix1=='+'||infix1=='-'))
      push(infixx);
       if(infixx=='/'&&(infix1=='^'||infix1=='*'))
       {
      a[j]=pop();
      j++;
      }
      if(infixx=='/'&&(infix1=='+'||infix1=='-'))
       push(infixx);
      if(infixx=='^')
      push(infixx);
}
main()
{
	int i=1,m=0;
	printf("enter the infix expression\n");
	gets(infix)	;
	a[j]=infix[0];j++;
	while(i<strlen(infix))
	{
		if(infix[i]=='('||infix[i]=='['||infix[i]=='{')
		push(infix[i]);
		else if(infix[i]=='*'||infix[i]=='-'||infix[i]=='+'||infix[i]=='/')
		{
			checkprec(infix[i],post[top]);
		}
		else
		{
			a[j]=infix[i];
			j++;
		}
		i++;
	}
	while(top>-1)
	{
		a[j]=pop();
		j++;
	}
	m=0;
	puts(a);
	//printf("%s",a);
	/*while(m<strlen(a))
	{
		printf("%c",a[m]);
		m++;
	}*/
}
