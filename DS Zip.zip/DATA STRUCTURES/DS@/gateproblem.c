#include<stdio.h>
int c;
int total(v)
{
	while(v)
	{
		c+=v&1;
		v>>=1;
	}
	return c;
}
main()
{
	static int x=0;
	int i=5;
	for(;i>0;i--)
	{
		x=x+total(i);
	}
	printf("%d",x);
}
