#include<stdio.h>
main()
{
	int amount;
	printf("Enter The Amount\n");
	scanf("%d",&amount);
	fun(amount);
}
int fun(int amount)
{
	int count1,count2,count3,count4;
	count1=count2=count3=count4=0;
	if(amount%100==0)
	{
		printf("take:\n");
		while(amount>=2000)
		{
			amount=amount-2000;
		count1++;
		}
		if(amount<2000&&count1!=0)
		{
			printf("%d-2000s\n",count1);
		}
		while(amount>=1000)
		{
			amount=amount-1000;
		   count2++;
		}
		if(amount<1000&&count2!=0)
		{
			printf("%d-1000s\n",count2);
		}
		while(amount>=500)
		{
			amount=amount-500;
			count3++;
		}
		if(amount<500&&count3!=0)
		{
			printf("%d-500s\n",count3);
		}
		while(amount>=100)
		{
			amount=amount-100;
			count4++;
		}
		if(amount<100&&count4!=0)
		{
			printf("%d-100s\n",count4);
		}
	}
	else
	{
		printf("!Invalid Amount\n");
		printf("please enter valid amount:\n");
		scanf("%d",&amount);
		fun(amount);
	}
}
