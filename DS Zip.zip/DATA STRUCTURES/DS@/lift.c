#include<stdio.h>
#include<stdlib.h>
#include<time.h>
struct node
{
	int data;
	struct node*lp;
	struct node*rp;
};
struct node*start,*temp,*ptr;
main()
{
	char str[30];
	struct tm *pt;
	time_t lt=time(NULL);
	pt=localtime(&lt);
	strcpy(str,asctime(pt));
	int n,t,c=0;
	int x=1,m=0,f=0;
	do{
		m++;
	temp=(struct node*)malloc(sizeof(struct node));
	temp->lp=NULL;
	temp->rp=NULL;
	if(start==NULL)
	{
		start=temp;
	}
	else
	{
		ptr=start;
		while(ptr->rp!=NULL)
		{
			ptr=ptr->rp;
		}
		temp->lp=ptr;
		ptr->rp=temp;
		temp->rp=NULL;
	}
}while(m<=20);
while(1)
{
switch(f)
{
	case 0:printf("you are in ground floor\n");
	     printf("you cant move down\n");
	     break;
	case 1:printf("you reached first floor\n");
	     break;
	break;
	case 2:printf("you reached second floor\n");
	break;
	case 3:printf("you reached third floor\n");
	break;
	case 4:printf("you reached fourth floor\n");
	break;
	case 5:printf("you reached fifth floor\n");
	break;
	case 6:printf("you reached sixthfloor\n");
	break;
	case 7:printf("you reached 7thfloor\n");
	break;
	case 8:printf("you reached 8th floor\n");
	break;
	case 9:printf("you reached 9th floor\n");
	break;
	case 10:printf("you reached  10th floor\n");
	break;
	case 11:printf("you reached 11th floor\n");
	break;
	case 12:printf("you reached 12th floor\n");
	break;
	case 13:printf("you reached 13th floor\n");
	break;
	case 14:printf("you reached 14th floor\n");
	break;
	case 15:printf("you reached 15th floor\n");
	break;
	case 16:printf("you reached 16th floor\n");
	break;
	case 17:printf("you reached 17th floor\n");
	break;
	case 18:printf("you reached 18th floor\n");
	break;
	case 19:printf("you reached 19th floor\n");
	break;
	case 20:printf("you reached 20thfloor\n");
	printf("you cant move upward\n");
	break;
	default:printf("invalid choice\n");
	break;
}
printf("which floor you want to move \n");
scanf("%d",&f);
if((str[11]==50&&str[12]>48)||(str[11]==48&&str[12]<52))
	   {
	   	printf("time up\n");
	      ptr=start;
	      f=0;
       }
else if(f>m)
{
	ptr=start;
	while(ptr!=NULL)
	{
		c++;
		if(c==f)
			break;
		ptr=ptr->rp;
	}
}
else
{
	ptr=start;
	while(ptr!=NULL)
	{
		c++;
		if(c==f)
			break;
		ptr=ptr->lp;
	}
}
	m=f;
}
}


