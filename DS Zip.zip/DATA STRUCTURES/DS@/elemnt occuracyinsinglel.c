#include<stdio.h>
#include<stdlib.h>
struct node
{
 int data;
 struct node*next;
};
struct node*start,*temp,*ptr;
main()
{
	int n,i,m,c=0;
	label2:temp=(struct node*)malloc(sizeof(struct node));
printf("enter the data into node:\n");
scanf("%d",&temp->data);
if(temp->data==-1)
{
	goto label1;
}
temp->next=NULL;
if(start==NULL)
{
start=temp;
goto label2;
}
else
{
	ptr=start;
	while(ptr->next!=NULL)
	{
		ptr=ptr->next;
	}
	ptr->next=temp;
	goto label2;
}
label1:	printf("enter the element to calculate its occurance\n");
	scanf("%d",&m);
	ptr=start;
	while(ptr!=NULL)
	{
		if(ptr->data==m)
		{
			c++;
		}
	   ptr=ptr->next;
	}
	printf("the numberof times the element is repeated is %d",c);
}
