#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node*next;
};
struct node*start,*temp,*ptr,*ptr1,*ptr2,*q,*q1;
main()
{
	int n=1,i;
	do{
temp=(struct node*)malloc(sizeof(struct node));
printf("enter the data into node:\n");
scanf("%d",&temp->data);
temp->next=NULL;
if(temp->data==-1)
{
n=0;
}
else
{
if(start==NULL)
{
start=temp;
}
else
{
	ptr=start;
	while(ptr->next!=NULL)
	{
		ptr=ptr->next;
	}
	ptr->next=temp;
}
}
}while(n);
ptr1=start;
ptr2=start;
while(ptr1->next!=NULL)
{
	ptr2=ptr1->next;
	while(ptr2!=NULL)
	{
		if(ptr1->data==ptr2->data)
		{
			q->next=ptr2->next;
			q1=ptr2;
			ptr2=q;
			ptr2=ptr2->next;
			q1->next=NULL;
			free(q1);
		}
		else
		{
			q=ptr2;
		ptr2=ptr2->next;
	   }
	}
	ptr1=ptr1->next;
}
printf("data present in nodes\n");
	ptr=start;
	while(ptr!=NULL)
	{
		printf("%d->",ptr->data);
		ptr=ptr->next;
	}
}
