#include<stdio.h>
#include<stdlib.h>
struct node
{
	 char alpha;
	struct node*next;
};
struct node*start,*temp,*ptr,*temp1,*ptr1,*start1,*temp2,*start2,*ptr2;
main()
{ 
	int x=1,c=0;
	do{
		temp=(struct node*)malloc(sizeof(struct node));
		printf("enter the alphabet or z to exit:\n");
		scanf("%s",&temp->alpha);
		temp->next=NULL;
		if(temp->alpha=='z')
		{
		x=0;
	    }
		else
		{
			if(start==NULL)
			{
				start=temp;
			}
			else
			{
				ptr=start;
				while(ptr->next!=NULL)
				{
					ptr=ptr->next;
				}
				ptr->next=temp;
			}
		}
	}while(x);
	ptr=start;
	while(ptr!=NULL)
	{
		if((ptr->alpha>='A')&&(ptr->alpha<='Z'))
		{
             printf("uppercase\n");
			temp1=(struct node*)malloc(sizeof(struct node));
			temp1->alpha=ptr->alpha;
			temp1->next=NULL;
			if(start1==NULL)
			start1=temp1;
			else
			{
				ptr1=start1;
				while(ptr1->next!=NULL)
				{
					ptr1=ptr1->next;
				}
				ptr1->next=temp1;
			}
		}
		else 
		{
			temp2=(struct node*)malloc(sizeof(struct node));
			temp2->alpha=ptr->alpha;
			temp2->next=NULL;
			if(start2==NULL)
			start2=temp2;
			else
			{
				ptr2=start2;
				while(ptr2->next!=NULL)
				{
					ptr2=ptr2->next;
				}
				ptr2->next=temp2;
			}
		}
		ptr=ptr->next;
	}
	printf("list of uppercase letters\n");
	ptr1=start1;
	while(ptr1!=NULL)
	{
		c++;
		printf("%c->",ptr1->alpha);
		ptr1=ptr1->next;
	}
	printf("\nthe number of uppercase letters are %d\n",c);
	printf("\nlist of lowercase letters\n");
	ptr2=start2;
	c=0;
	while(ptr2!=NULL)
	{
		c++;
		printf("%c->",ptr2->alpha);
		ptr2=ptr2->next;
	}
	printf("\nthe number of lowercase letters are %d",c);
}
