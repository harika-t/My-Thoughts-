#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	int priority;
	struct node *link;
};
struct node *front=NULL,*rear=NULL;
void display()
{
	struct node *q=front;
	if(front==NULL&&rear==NULL)
	{
		printf("No nodes to display\n");
	}
	else
	{
		while(q!=NULL)
		{
			printf("%d\t",q->data);
			printf("%d\n",q->priority);
			q=q->link;
		}
	}
}
void create()
{
	struct node *temp,*q;
	temp=(struct node *)malloc(sizeof(struct node));
	printf("Enter node data:");
	scanf("%d",&temp->data);
	printf("Enter node priority:");
	scanf("%d",&temp->priority);
	temp->link=NULL;
	if(front==NULL||temp->priority<front->priority)
	{
		temp->link=front;
		front=temp;
		display();
	}
	else
	{
		q=front;
		while(q->link!=NULL&&q->link->priority<=temp->priority)
		{
			q=q->link;
		}
		temp->link=q->link;
		q->link=temp;
		display();
	}
}
void del()
{
	struct node *temp;
	if(front==NULL)
	{
		printf("Queue underflow\n");
	}
	else
	{
		temp=front;
		printf("Deleted item is %d\n",temp->data);
		front=front->link;
		free(temp);
		display();
	}
}

main()
{
	int ch,n,i;
	while(1)
	{
		printf("1.Insert\n2.Delete\n3.Display\n4.Exit\n");
		printf("Enter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:printf("How many nodes do you want to create:");
			       scanf("%d",&n);
			       for(i=1;i<=n;i++)
			       {
			       	   create();
				   }
				   break;
			case 2:del();
			       break;
			case 3:display();
			       break;
			case 4:exit(0);
			       break;
		}
	}
}
