#include<stdio.h>
#include<stdlib.h>
#define MAX 5
int dequeue[MAX],front=-1,rear=-1;
void display()
{
	if(front==-1&&rear==-1)
	printf("Double ended queue is empty\n");
	else
	{
		for(int i=front;i<=rear;i++)
		printf("%d\t",dequeue[i]);
	}
}
void insert(int ele)
{
	if((front==0&&rear==MAX-1)||(front==rear+1))
	printf("Double ended queue is full");
	else if(front==-1&&rear==-1)
	{
		front++;
		rear++;
		dequeue[rear]=ele;
		display();
	}
	else if(front==0)
	{
		rear++;
		dequeue[rear]=ele;
		display();
	}
	else if(rear==MAX-1)
	{
		front--;
		dequeue[front]=ele;
		display();
	}
	else
	{
		int ch;
		printf("1.Left Side Insertion\n2.Right Side Insertion\nEnter your choice:");
		scanf("%d",&ch);
		if(ch==1)
		{
			front--;
			dequeue[front]=ele;
			display();
		}
		else if(ch==2)
		{
			rear++;
			dequeue[rear]=ele;
			display();
		}
		else
		printf("Invalid Choice\n");
	}
}
void delete1()
{
	if(front==-1&&rear==-1)
	printf("Double ended queue is empty\n");
	else if(front==rear)
	{
		printf("Element deleted is %d\n",dequeue[front]);
		front=rear=-1;
		display();
	}
	else
	{
		int ch;
		printf("1.Left Side Deletion\n2.Right Side Deletion\nEnter your choice:");
		scanf("%d",&ch);
		if(ch==1)
		{
			printf("Element deleted is %d\n",dequeue[front]);
			front++;
			display();
		}
		else if(ch==2)
		{
			printf("Element deleted is %d\n",dequeue[rear]);
			rear--;
			display();
		}
		else
		printf("Invalid Choice\n");
	}
}
main()
{
	int ch,ele;
	while(1)
	{
		printf("\n1.Insert\n2.Delete\n3.Display\n4.Exit\n");
		printf("Enter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:printf("Enter element:");
			scanf("%d",&ele);
			insert(ele);
			break;
		    case 2:delete1();
		    break;
		    case 3:display();
		    break;
		    case 4:exit(0);
		    break;
		}
	}
}
