def avg(start,end):
    s=0
    c=0
    for i in range(start,end+1):
        s=s+i
        c=c+1
    print("Average is ",s/c)

    
def unique(l):
    l1=[]
    for i in l:
        if l.count(i)==1:
            l1.append(i)
    print(l1)